There are two main functions in the 'Code' folder, one is for the simulation cases while another one for the experiments, which are introduced in the following paper,

Zemin Cai, David M. Salazar, Tao Chen, and Tianshu Liu, ��Determining surface pressure from skin friction,�� Experiments in Fluids, (2022)63:152. 
DOI: 10.1007/s00348-022-03500-y.

The program can be run directly if the data has been prepared in the 'Data' folder. Then the results will be saved in the 'Results' directory.





%Code to read appropriate frames from the multi-tif files from PCO-camera, 
%apply 2-D filter, find Temperature, and trace temperature in time for a given point 

clear all
close all


LoFVideo = VideoReader('LoF.wmv');


%workingDir = tempname;
%mkdir(workingDir)
%mkdir(workingDir,'images')


ii = 1;

while hasFrame(LoFVideo)
   img = readFrame(LoFVideo);
   filename = [sprintf('%03d',ii) '.jpg'];
   %fullname = fullfile(workingDir,'images',filename);
   imwrite(img,filename)    % Write out to a JPEG file (img1.jpg, img2.jpg, etc.)
   ii = ii+1;
end





load('data.mat')
figure(1)
plot(data(:,1), data(:,2),'o')
axis ij
hold on
for i=1:size(data,1)
    text(data(i,1), data(i,2), num2str(i))
end
% rsqr = data(:,1).^2 + data(:,2).^2;
% ind = find(rsqr(:) == min(rsqr))
% % ind = find(rsqr(:) == max(rsqr))
% rsqr2 =[ [1:121]' (data(:,1) - data(ind,1)).^2 + (data(:,2) - data(ind,2)).^2];
% ang = atand((data(:,2) - data(ind,2)) ./ (data(:,1) - data(ind,1))); 
% rsqr2 = [rsqr2 ang];
% % ind = find(rsqr2(:) == min(rsqr2) & rsqr2 > 0)
% sr = sortrows(rsqr2,3)
% ang2 = [[1:121]' atand((data(:,2) - data(11,2)) ./ (data(:,1) - data(11,1)))]; 
% rsqr3 =(data(:,1) - data(11,1)).^2 + (data(:,2) - data(11,2)).^2;
% q = [ang2 rsqr3];
% qs = sortrows(q, 3)

% numTargs = size(data,1);
% targNum = 11;
% rsqr =(data(:,1) - data(targNum,1)).^2 + (data(:,2) - data(targNum,2)).^2;
% ang = [[1:numTargs]' atand((data(:,2) - data(targNum,2)) ./ (data(:,1) - data(targNum,1)))]; 
% q = [ang rsqr];
% qSort = sortrows(q, 3);
% ind2 = find(abs(qSort(1:4,2)) == min(abs(qSort(1:4,2))));
% qSort(ind2,1)
% 
% targNum = 22;
% rsqr =(data(:,1) - data(targNum,1)).^2 + (data(:,2) - data(targNum,2)).^2;
% ang = [[1:numTargs]' atand((data(:,2) - data(targNum,2)) ./ (data(:,1) - data(targNum,1)))]; 
% q = [ang rsqr];
% qSort = sortrows(q, 3);
% ind2 = find(abs(qSort(1:4,2)) == min(abs(qSort(1:4,2))));
% qSort(ind2,1)

targNum = [11 22 33 44 55 66 67 78 89 100 111];
qq =[];
numTargs = size(data,1);
for j = 1:11
    rsqr =[(data(:,1) - data(targNum(j),1)).^2 + (data(:,2) - data(targNum(j),2)).^2  data(:,1) - data(targNum(j),1) data(:,2) - data(targNum(j),2)];
    ang = [[1:numTargs]' atan2((data(:,2) - data(targNum(j),2)) , (data(:,1) - data(targNum(j),1)))*180/pi];
    q = [ang rsqr];
    qSort = sortrows(q, 3);
   ind2 = find(abs(qSort(1:4,2)) == min(abs(qSort(1:4,2))));
%    ind2 = find(abs(qSort(1:4,5)) < max(abs(qSort(1:4,5))) & qSort(1:4,4) > 0);
    qq = [qq; [j qSort(ind2,1)]];
end
qq

targNum = [10 21 32 43 54 65 68 79 90 101 112];
qq =[];
numTargs = size(data,1);
for j = 1:11
    rsqr =[(data(:,1) - data(targNum(j),1)).^2 + (data(:,2) - data(targNum(j),2)).^2  data(:,1) - data(targNum(j),1) data(:,2) - data(targNum(j),2)];
    ang = [[1:numTargs]' atan2((data(:,2) - data(targNum(j),2)) , (data(:,1) - data(targNum(j),1)))*180/pi];
    q = [ang rsqr];
    qSort = sortrows(q, 3);
   ind2 = find(abs(qSort(1:4,2)) == min(abs(qSort(1:4,2))));
%    ind2 = find(abs(qSort(1:4,5)) < max(abs(qSort(1:4,5))) & qSort(1:4,4) > 0);
    qq = [qq; [j qSort(ind2,1)]];
end
qq

% targNum = [7 18 29 40 51 56 70 82 93 104 115];
% horizontal
 targNum = [11 10 9 8 6 4 3 1 2 5 7];
qq =[];
numTargs = size(data,1);
for j = 1:11
    rsqr =[(data(:,1) - data(targNum(j),1)).^2 + (data(:,2) - data(targNum(j),2)).^2  data(:,1) - data(targNum(j),1) data(:,2) - data(targNum(j),2)];
    ang = [[1:numTargs]' atan2((data(:,2) - data(targNum(j),2)) , (data(:,1) - data(targNum(j),1)))*180/pi];
    q = [ang rsqr];
    qSort = sortrows(q, 3);
   ind2 = find(abs(qSort(2:4,2)) == min(abs(qSort(2:4,2))));
%    ind2 = find(abs(qSort(1:4,5)) < max(abs(qSort(1:4,5))) & qSort(1:4,4) > 0);
    qq = [qq; [j qSort(ind2+1,1)]];
end
qq

% vertical
targNum = [11 10 9 8 6 4 3 1 2 5];
qq =[];
numTargs = size(data,1);
for j = 1:10
    rsqr =[(data(:,1) - data(targNum(j),1)).^2 + (data(:,2) - data(targNum(j),2)).^2  data(:,1) - data(targNum(j),1) data(:,2) - data(targNum(j),2)];
    ang = [[1:numTargs]' atan2((data(:,2) - data(targNum(j),2)) , (data(:,1) - data(targNum(j),1)))*180/pi];
    q = [ang rsqr];
    qSort = sortrows(q, 3);
   ind2 = find(qSort(2:4,2) == min(qSort(2:4,2)));
%    ind2 = find(abs(qSort(1:4,5)) < max(abs(qSort(1:4,5))) & qSort(1:4,4) > 0);
    qq = [qq; [j qSort(ind2+1,1)]];
end
qq


% qq =[];
% numTargs = size(data,1);
% j = 11;
%     rsqr =[(data(:,1) - data(j,1)).^2 + (data(:,2) - data(j,2)).^2  data(:,1) - data(j,1) data(:,2) - data(j,2)];
%     ang = [[1:numTargs]' atan2((data(:,2) - data(j,2)) , (data(:,1) - data(j,1)))*180/pi];
%     q = [ang rsqr];
%     qSort = sortrows(q, 3);
%    ind2 = find(abs(qSort(2:5,2)) == min(abs(qSort(2:5,2))));
% %    ind2 = find(abs(qSort(1:4,5)) < max(abs(qSort(1:4,5))) & qSort(1:4,4) > 0);
% %     qq = [qq; [j qSort(ind2,1)]];
% % qq
% qSort(ind2+1,1)
% 

left = min(data(:,3));
right = max(data(:,3) + data(:,5));
top = min(data(:,4));
bottom = max(data(:,4) + data(:,6));
plot([left right right left left], [top top bottom bottom top],'r')
leftMost = find(data(:,1) == min(data(:,1)))
j = leftMost;
j = 18;
rsqr =[(data(:,1) - data(j,1)).^2 + (data(:,2) - data(j,2)).^2  data(:,1) - data(j,1) data(:,2) - data(j,2)];
ang = [[1:size(data,1)]' atan2((data(:,2) - data(j,2)) , (data(:,1) - data(j,1)))*180/pi];
q = [ang rsqr];
qSort = sortrows(q, 3);
ind2 = find(abs(qSort(2:5,2)) == min(abs(qSort(2:5,2))));
qSort(ind2+1,1)
qSort(1:8,:)

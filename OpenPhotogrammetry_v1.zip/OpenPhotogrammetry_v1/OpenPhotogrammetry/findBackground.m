function Gback = findBackground(img, x, y, delx, dely)

% finds max gray scale, Gback, on perimeter of region of interest (roi) of a digital image
% Gback = findBackground(img, x, y, delx, dely)
% where img is an image matrix
% already loaded into MATLAB with img = imread(filename)
% x, y are the horizontal and veritcal pixel central location
% delx and dely are approximately the half-width and half-height of the roi respectively
% pixels interogated at columns x - delx and x + delx
% pixels interogated at rows y - dely to y + dely
% width of roi = 2 * delx
% height of roi = 2 * dely

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: July 23, 2007
% primary author: A. W. Burner

% use row, column designations below to reduce confusion when dealing with
% 2D matrices of images which are row, column order (or y, x order)
delCol = round(delx);   % columns are associated with x
delRow = round(dely);   % rows are associated with y
colMid = round(x);      % central column is at x-value of pixel location
rowMid = round(y);      % central row is at y-value of pixel location

delRowTop = delRow;      % initialize variables used for near edge test
delRowBottom = delRow;
delColLeft = delCol;
delColRight = delCol;

% image edge checks and adjustment to input parameters to accomodate target very near edge of image
rowimg = size(img, 1);
colimg = size(img, 2);
if rowMid - delRow < 1; delRowTop = rowMid - 1; end
if rowMid + delRow > rowimg; delRowBottom = rowimg - rowMid; end
if colMid - delCol < 1; delColLeft = colMid - 1; end
if colMid + delCol > colimg; delColRight = colimg - colMid; end

rowStart = rowMid - delRowTop; % start of rows defining pixel area roi
rowEnd = rowMid + delRowBottom;   % end of rows defining pixel area roi
colStart = colMid - delColLeft; % start of columns defining pixel area roi
colEnd = colMid + delColRight;   % end of columns defining pixel area roi

roiTopBottom = img([rowStart rowEnd], colStart : colEnd); % get top and bottom rows of roi
roiLeftRight = img(rowStart:rowEnd, [colStart colEnd]);   % get left and right columns of roi

Gback = max(max([roiTopBottom roiLeftRight']));  % roiLeftRight' transposes to give 4 'rows' for max function; max(max needed to find max of max of columns
Gback = double(Gback);  % convert from uint8 to double so math (subtraction) will work when Gback is outputted


function [dx,xxp]=lleast3(angles,XYZc,interior,format,xyimagd,xyimagu,xyzobj)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% linear least squares determines only omega, phi, kappa when other parameters known
% This program is used for the DLT (dlt.m) to obtain the 
% true (omega,phi,kappa). 
%
% Inputs: (1) angles, three Euler angles (omega,phi,kappa) in degrees
%         (2) XYZc, (Xc,Yc,Zc) in inches
%         (2) interior, the interior orientation parameters (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (3) format, the camera format file, 
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%         (4) xyimagd, distorted image coordinates (in pixels)
%         (5) xyimagu, undistorted image coordinates (in pixels)
%         (6) xyzobj, the object space coordinates (in inches)
%
% Outputs: (1) dx, the residual of the least squares estimation
%          (2) xxp, the distorted xp
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xm=xyzobj(:,1)*25.4;
ym=xyzobj(:,2)*25.4;
zm=xyzobj(:,3)*25.4;

hv_ratio=interior(4);
x_range=format(1);
y_range=format(2);
Sv=format(4);
Sh=Sv*hv_ratio;

ximd=(xyimagd(:,1)-x_range/2)*Sh;
yimd=-(xyimagd(:,2)-y_range/2)*Sv;

ximu=(xyimagu(:,1)-x_range/2)*Sh;
yimu=-(xyimagu(:,2)-y_range/2)*Sv;

% set initial values for the parameters
omaga=angles(1)*pi/180;
phi=angles(2)*pi/180;
kappa=angles(3)*pi/180;
xc=XYZc(1)*25.4;
yc=XYZc(2)*25.4;
zc=XYZc(3)*25.4;
c=interior(1); %mm
xp=interior(2); %mm
yp=interior(3); %mm
k1=interior(5);
k2=0;
p1=0;
p2=0;

% evaluate the elements of the matrix
m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);
w=m31*(xm-xc)+m32*(ym-yc)+m33*(zm-zc);
u=m11*(xm-xc)+m12*(ym-yc)+m13*(zm-zc);
v=m21*(xm-xc)+m22*(ym-yc)+m23*(zm-zc);

r2=(ximu-xp).^2+(yimu-yp).^2;
xx=ximu-xp;
yy=yimu-yp;
deltaxr=k1*xx.*r2+k2*xx.*(r2.*r2);
deltayr=k1*yy.*r2+k2*yy.*(r2.*r2);
deltaxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
deltayd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
deltax=deltaxr+deltaxd;
deltay=deltayr+deltayd;

f1=ximd-xp+deltax+c*(u./w);
f2=yimd-yp+deltay+c*(v./w);
a11=-1*ones(length(v),1);
a12=0*ones(length(v),1);
a13=u./w;
a14=c*(m12*(zm-zc)-m13*(ym-yc)-(u./w).*(m32*(zm-zc)-m33*(ym-yc)))./w;
a15=c*(-cos(kappa)*w-(u./w).*(cos(kappa)*u-sin(kappa)*v))./w;
a16=c*v./w;
a17=c*(-m11+m31*(u./w))./w;
a18=c*(-m12+m32*(u./w))./w;
a19=c*(-m13+m33*(u./w))./w;
a21=0*ones(length(v),1);
a22=-1*ones(length(v),1);
a23=v./w;
a24=c*(m22*(zm-zc)-m23*(ym-yc)-(v./w).*(m32*(zm-zc)-m33*(ym-yc)))./w;
a25=c*(sin(kappa)*w-(v./w).*(cos(kappa)*u-sin(kappa)*v))./w;
a26=-c*u./w;
a27=c*(-m21+m31*(v./w))./w;
a28=c*(-m22+m32*(v./w))./w;
a29=c*(-m23+m33*(v./w))./w;
a=[a14 a15 a16;
   a24 a25 a26];
l=[-f1;-f2];
b=a'*a;
rhs=(a'*l);

% use the singular value decomposition to solve the linear equations
[uu,ss,vv]=svd(b);
ww=diag(ss);

for i=1:length(ww)
    if ww(i)<10^(-5)
       ww(i)=10^20;
    end
end

coef=(uu'*rhs)./ww;
dx=vv*coef;

xxp=ximd+deltax+c*u./w;















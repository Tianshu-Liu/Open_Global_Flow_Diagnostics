function camOut = resection(camIn, XYZ)
% function [camOut A L] = resection(camIn, XYZ)

% nonlinear least squares (NLLS) to determine omega, phi, kappa, Xc, Yc, Zc
% camOut = resection(camIn, XYZ)
% and estimates of the standard deviation of these parameters
% given camera interior parameters (c, xp, yp), image data, and X, Y, Z
% data; input arguments are the structure camIn and the numeric N X 4 array
% XYZ with format [pnt X Y Z];  The fields of the input structure camIn must include at least:
% camIn.c
% camIn.xp
% camIn.yp
% camIn.omega
% camIn.phi
% camIn.kappa
% camIn.Xc
% camIn.Yc
% camIn.Zc
% camIn.xymm
% output is the structure camOut with the following fields
% camOut.c
% camOut.xp
% camOut.yp
% camOut.omega
% camOut.phi
% camOut.kappa
% camOut.Xc
% camOut.Yc
% camOut.Zc
% camOut.xymm
% camOut.m
% camOut.omegastd
% camOut.phistd
% camOut.kappastd
% camOut.Xcstd
% camOut.Ycstd
% camOut.Zcstd
% camOut.So    standard deviation of unit weight
% camOut.xstd 
% camOut.ystd
% last 2 terms are the standard deviation of difference between input image
% coordinates and output computed coordinates based on resection output
% parameters
% function resection uses the notation of Wolf's Elements of Photogrammetry
% 2nd edition, pages 606 - 609, but with the opposite sign for coefficients
% b11 - b13 and b21 - b23 
%
%   See also intersection

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 24, 2006
% primary author: A. W. Burner

c = camIn.c;   % set local variables from input structure camIn
xp = camIn.xp;
yp = camIn.yp;
omega = camIn.omega * pi / 180;  % convert to radians for NLLS reduction
phi = camIn.phi * pi / 180;
kappa = camIn.kappa * pi / 180;
Xc = camIn.Xc;
Yc = camIn.Yc;
Zc = camIn.Zc;
xymm = camIn.xymm;

[XYZ xymm] = commonTargetNumbers(XYZ, xymm); % subfunction to redefine XYZ and xymm with only common target numbers
Npoints = size(XYZ,1);   % number of rows of XYZ (or xymm) equals number of points

for iterations = 1:20  % use 20 interations
    A = [];   % initialize A array
    L = [];   % initialize L array
    m = rotationMatrix(omega, phi, kappa, 'radians');  % compute rotation matrix anew for each iteration (in radians)
    for i = 1:Npoints  % step through each point commonto both xymm and XYZ
        x = xymm(i, 2) - xp;  % set local variables (see Wolf's Elements of Photogrammetry)
        y = xymm(i, 3) - yp;
        delX = XYZ(i,2) - Xc;
        delY = XYZ(i,3) - Yc;
        delZ = XYZ(i,4) - Zc;
        q = m(3,1) * delX + m(3,2) * delY + m(3,3) * delZ;
        r = m(1,1) * delX + m(1,2) * delY + m(1,3) * delZ;
        s = m(2,1) * delX + m(2,2) * delY + m(2,3) * delZ;
        b11 = x * (m(3,3) * delY - m(3,2) * delZ) / q + c * (m(1,3) * delY - m(1,2) * delZ) / q;
        b12 = x * (-delX * cos(phi) - delY * (sin(omega) * sin(phi)) + delZ * (cos(omega) * sin(phi))) / q...
            + c * (delX * (sin(phi) * cos(kappa)) - delY * (sin(omega) * cos(phi) * cos(kappa)) + delZ * (cos(omega) * cos(phi) * cos(kappa))) / q;
        b13 = -c * (m(2,1) * delX + m(2,2) * delY + m(2,3) * delZ) / q;
        b14 = x * m(3,1) / q + c * m(1,1) / q;
        b15 = x * m(3,2) / q + c * m(1,2) / q;
        b16 = x * m(3,3) / q + c * m(1,3) / q;
        J = (q * x + r * c) / q;
        b21 = y * (m(3,3) * delY - m(3,2) * delZ) / q + c * (m(2,3) * delY - m(2,2) * delZ) / q;
        b22 = y * (-delX * cos(phi) - delY * (sin(omega) * sin(phi)) + delZ * (cos(omega) * sin(phi))) / q...
            + c * (-delX * (sin(phi) * sin(kappa)) - delY * (sin(omega) * cos(phi) * sin(kappa)) + delZ * (cos(omega) * cos(phi) * sin(kappa))) / q;
        b23 = c * (m(1,1) * delX + m(1,2) * delY + m(1,3) * delZ) / q;
        b24 = y * m(3,1) / q + c * m(2,1) / q;
        b25 = y * m(3,2) / q + c * m(2,2) / q;
        b26 = y * m(3,3) / q + c * m(2,3) / q;
        K = (q * y + s * c) / q;
        j = 2 * i - 1;   % for i = 1 2 3 4..., j = 1 3 5 7...
        A(j, 1) = b11;
        A(j, 2) = b12;
        A(j, 3) = b13;
        A(j, 4) = b14;
        A(j, 5) = b15;
        A(j, 6) = b16;
        A(j + 1, 1) = b21;
        A(j + 1, 2) = b22;
        A(j + 1, 3) = b23;
        A(j + 1, 4) = b24;
        A(j + 1, 5) = b25;
        A(j + 1, 6) = b26;
        L(j) = J;
        L(j + 1) = K;
    end      % end of stepping through points loop
    % disp([norm(A) cond(A) norm(inv(A'*A)) cond(inv(A'*A))])
    L = L';  % make L a column vector for matrix solution next 
    % disp(A)
    % disp(L)
    solution = A\L;                % LLS for correction terms to the desired parameters
    % solution = lscov(A,L)
    omega = omega + solution(1);   % add corrections to start values of parameters
    phi   = phi   + solution(2);
    kappa = kappa + solution(3);
    Xc    = Xc    + solution(4);
    Yc    = Yc    + solution(5);
    Zc    = Zc    + solution(6);
end  % end of 20 interations loop
camOut = camIn;   % populate output structure camOut with any fields in input structure camIn 
camOut.omega = omega * 180 / pi;  % populate output structure camOut with new results just found
camOut.phi = phi * 180 / pi;
camOut.kappa = kappa * 180 / pi;
camOut.Xc = Xc;
camOut.Yc = Yc;
camOut.Zc = Zc;
camOut.m = rotationMatrix(camOut.omega, camOut.phi, camOut.kappa);  % recompute .m output field to match new omega, phi, kappa
df = (size(A, 1) - length(solution)); % compute degrees of freedom = number of equations - number of unknowns
V = A * solution  - L;                % compute residuals
So = sqrt(V' * V / df);               % compute standard deviation of unit weight
covar = inv(A' * A);                  % compute covariance matrix
stdsolution = So * sqrt(diag(covar)); % standard deviation estimates = square root of diagonals of covariance times So
camOut.omegastd = stdsolution(1) * 180 / pi;
camOut.phistd = stdsolution(2) * 180 / pi;
camOut.kappastd = stdsolution(3) * 180 / pi;
camOut.Xcstd = stdsolution(4);
camOut.Ycstd = stdsolution(5);
camOut.Zcstd = stdsolution(6);
camOut.So = So;

xymm2 = collinearity(camOut, XYZ);  % create image data using newly found exterior orientation for comparison to input image data
[xymmTemp xymm2] = commonTargetNumbers(camIn.xymm, xymm2); % for the case where canIn.xymm has points not in xymm2 (and not in XYZ) 
xystd = std(xymm2(:, [2 3]) - xymmTemp(:, [2 3]));  % compute standard deviation of difference between just created image data and input image data
% xystd = std(xymm2(:, [2 3]) - camIn.xymm(:, [2 3]));  % compute standard deviation of difference between just created image data and input image data
camOut.xstd = xystd(1);
camOut.ystd = xystd(2);
return   % end of main function resection

function [XYZ xymm] = commonTargetNumbers(XYZin, xymmin) % subfunction to redefine XYZin and xymmin with only common target numbers
commonNum = intersect(XYZin(:,1), xymmin(:,1));  % find target numbers common to both XYZin and xymmin arrays
XYZinindex  = []; % initialize index for XYZin array
xymminindex = []; % initialize index for xymmin structure
for i=1:length(commonNum)  % step through common set of target numbers found above
    XYZinindex  = [XYZinindex; find(XYZin(:,1)   == commonNum(i))];  % create index of XYZin containing common target numbers
    xymminindex = [xymminindex; find(xymmin(:,1) == commonNum(i))];  % create index of xymmin containing common target numbers
end    % end of loop stepping through common target numbers
XYZ  = XYZin(XYZinindex, :);   % redefine XYZin with common target numbers only
xymm = xymmin(xymminindex, :); % redefine xymmin with common target numbers only
return % end of subfunction commonTargetNumbers

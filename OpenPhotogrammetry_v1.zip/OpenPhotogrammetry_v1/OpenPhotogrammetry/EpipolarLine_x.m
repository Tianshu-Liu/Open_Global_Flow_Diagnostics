function [x_epipo1,y_epipo1,normG_x]=EpipolarLine_x(ximag2,yimag2,orientation1,orientation2,camformat1,camformat2,x_bound0,x_bound1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% determines the epipolar line (x) in the image 1 for a given point (ximag2,yimag2) in pixels in the image 2
% when the camera orientation parameters and formats are known. 
% Search the minimum point of normG along ximag1 in a range [x_bound0,x_bound1].  
%
% Inputs:
%       (1) 'ximag2', x-coordinate in pixels in image 2 
%       (2) 'yimgg2', y-coordinate in pixels in image 2 
%       (3) 'orientation1', the orientation perameters for camera 1, (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%       (4) 'orientation2', the orientation perameters for camera 2, (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%       (5) 'camformat1', the camera format for camera 1, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (6) 'camformat2', the camera format for camera 2, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (7) [x_bound0,x_bound1], range of ximag1 in image 1 for minimization search 
%
%  Outputs:
%       (1) [x_epipo1,y_epipo1], (x,y) coordinates of the epipolar line in pixels in image 1. 
%                            This is a linear relation (straight line).
%       (2) normG_x, norm(G)
%
%  Note: This is convenient for an epipolar line that is not too vertical
%        in the (x,y) plane (in most cases).  Thus, minimization can be done along the x-axis. 

% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% give several points in the y-axis
y_range=camformat1(1);
y_epipo_0=[1:y_range/50:y_range];

% minimization along the x-axis over the range [x_bound0,x_bound1]
for j=1:length(y_epipo_0)
    [x_epipo_0(j),normG_x_0(j)]=fminbnd('EpipolarRelation_x',x_bound0,x_bound1,[],y_epipo_0(j),ximag2,yimag2,orientation1,orientation2,camformat1,camformat2);
end

% chose the coordinates for the epipolar line in image 1, on which norm(G) is small
ii=find((x_epipo_0>=(x_bound0+1))&(x_epipo_0<=(x_bound1-1))&(normG_x_0<=0.1));
for i=1:length(ii)
    x_epipo1(i)=x_epipo_0(ii(i));
    y_epipo1(i)=y_epipo_0(ii(i));
    normG_x(i)=normG_x_0(ii(i));
end



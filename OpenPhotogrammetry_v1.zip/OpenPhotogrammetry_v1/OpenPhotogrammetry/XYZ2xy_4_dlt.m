function [xyimag]=XYZ2xy_4_dlt(ori,xyzobj,camformat)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generates target coordinates (in pixels) in the image plane
% given a set of the target coordinates in the object space when the camera orientation parameters and
% format are known. This is useful for simulation.
%
% Inputs: (1) xyzobj, (X,Y,Z) object space coordinates of a target, the units are consistent with (Xc,Yc,Zc) (typically in inches)
%         (2) ori, the camera exterior and interior orientation parameters
%             (omega,phi,kappa,Xc,Yc,Zc), (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (3) camformat, the camera format file,
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%
% Outputs: xyimag, (x,y) image coordinates of a target in pixels
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xm=xyzobj(:,1);
ym=xyzobj(:,2);
zm=xyzobj(:,3);

omaga=ori(1)*pi/180;
phi=ori(2)*pi/180;
kappa=ori(3)*pi/180;
xc=ori(4);
yc=ori(5);
zc=ori(6);
c=ori(7); %mm
xp=ori(8); %mm
yp=ori(9); %mm
ratio_pixel=ori(10);
k1=ori(11);
k2=ori(12);
p1=ori(13);
p2=ori(14);

% calculate the rotational matrix
m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);
w=m31*(xm-xc)+m32*(ym-yc)+m33*(zm-zc);
wx=m11*(xm-xc)+m12*(ym-yc)+m13*(zm-zc);
wy=m21*(xm-xc)+m22*(ym-yc)+m23*(zm-zc);
x_image=xp-c*wx./w;
y_image=yp-c*wy./w;

r2=(x_image-xp).^2+(y_image-yp).^2;
xx=x_image-xp;
yy=y_image-yp;
deltaxr=k1*xx.*r2+k2*xx.*(r2.*r2);
deltayr=k1*yy.*r2+k2*yy.*(r2.*r2);
deltaxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
deltayd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
deltax=deltaxr+deltaxd;
deltay=deltayr+deltayd;

x_imaged=xp-deltax-c*wx./w;
y_imaged=yp-deltay-c*wy./w;

Sh=camformat(3);
Sv=camformat(4);
x_range=camformat(1);
y_range=camformat(2);
x_pixel=x_imaged/Sh+x_range/2;
y_pixel=-y_imaged/Sv+y_range/2;

% figure(1)
% clf
% plot(x_imaged,y_imaged,'*');
% xlabel('x (mm)');
% ylabel('y (mm)');
% title('Targets on image plane');
xyimag=[x_pixel y_pixel];


function X2 = conformal3D(X1, m, Txyz, s)

% 3D conformal transformation [Xtrans] = s * [m] * [Xin] + [Txyz]
% X2 = conformal3D(X1, m, Txyz, s)
% represents [Xtrans] = s * [m] * [Xin] + [Txyz]
% X1 is N X 4 (1st column contains target numbers); m is 3 X 3 from rotationMatrix function
% Txyz is a row or column vector of translations in X, Y, and Z order
% s is scale (scalar)
% output array X2 is N X 4

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: Septermber 15, 2006
% primary author: A. W. Burner

Nrows = size(X1, 1);      % find number of rows (# of target) of X1 for next 'for loop'
X2 = [];                  % initialize output array X2
T = [Txyz(1); Txyz(2); Txyz(3)]; % create 3 X 1 column vector for matrix calculation below (in case Txyz passed as a row vector)
for i = 1:Nrows           % step through rows of X2 (1 row = 1 target number)
    XYZ2 = X1(i,2:4)';    % create column vector from row of XYZ in X1 (for matrix calculation below)
    X2(i,:) = s * m * XYZ2 + T; % column vector of transformed XYZ stored as row vector in X2
end                       % end of loop steping through input array X1
X2 = [X1(:,1) X2];        % attach target numbers to 1st column of output array X2


function xymm = collinearity(cam, XYZ)

% creates ideal image plane data
% function xymm = collinearity(cam, XYZ)
% cam is a structure with at least the following fields
% cam.c
% cam.xp
% cam.yp
% cam.m  rotation matrix from function rotationMatrix
% cam.Xc
% cam.Yc
% cam.Zc
% XYZ is a filename string for a file, like 'fileName', containing N X 4 array
% [pt1 X1 Y2 Z3; pt2 X2 Y2 Z2;...ptN XN YN ZN] or the N X 4 array itself
% xymm output array is an N X 3 of image coordinates [pt1 x1 y2; pt2 x2
% y2;...ptN xN yN] 

% c = principal distance (camera constant, mm)
% xp, yp locates the photogrammetric principal point, mm
% m = 3 X 3 rotation matrix (use function rotationMatrix)
% Xc, Yc, Zc = location of perspective center
% X, Y, Z = location of object point
% Xc, Yc, Zc and X, Y, Z should normally be in same units (for example inches)
% units of ouput array xymm same as units of c (usually mm)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

 c = cam.c;  % get values from input structure cam
xp = cam.xp;
yp = cam.yp;
 m = cam.m;
Xc = cam.Xc;
Yc = cam.Yc;
Zc = cam.Zc;

if ischar(XYZ)            % test to see if XYZ is a char (filename) or N X 4 array
    XYZdata = load(XYZ);  % load XYZ data from file if XYZ = filename like 'fileName'
else
    XYZdata = XYZ;        % get XYZdata from XYZ N X 4 array if XYZ not = filename
end

xymm=[];                  % initialize output array (which will become N X 3 upon population in for loop
for i = 1:size(XYZdata,1) % step through XYZ data for the number of rows of XYZdata (size(XYZdata,1))
    X = XYZdata(i,2);
    Y = XYZdata(i,3);
    Z = XYZdata(i,4);
    xnum = m(1,1) * (X - Xc) + m(1,2) * (Y - Yc) + m(1,3) * (Z - Zc);  % x-numerator of collinearity equations
    dnom = m(3,1) * (X - Xc) + m(3,2) * (Y - Yc) + m(3,3) * (Z - Zc);  % denominator of collinearity equations
    ynum = m(2,1) * (X - Xc) + m(2,2) * (Y - Yc) + m(2,3) * (Z - Zc);  % y-numerator of collinearity equations
    xymm(i,1) = XYZdata(i,1);   % set point number to value in column 1 of XYZdata array
    if dnom == 0                % test for denominator = 0 (divide by 0) and print to screen denom values
        fprintf(1, 'For point # %g denominator of collinearity equations = 0 (divide by 0)\n', xymm(i,1))
        fprintf(1, '%s\n', 'dnom = m(3,1) * (X - Xc) + m(3,2) * (Y - Yc) + m(3,3) * (Z - Zc);')
        fprintf(1, 'm(3,1) * (X - Xc) = %g * (%g - %g) = %g\n', m(3,1), X, Xc, m(3,1) * (X - Xc))
        fprintf(1, 'm(3,2) * (Y - Yc) = %g * (%g - %g) = %g\n', m(3,2), Y, Yc, m(3,2) * (Y - Yc))
        fprintf(1, 'm(3,3) * (Z - Zc) = %g * (%g - %g) = %g\n', m(3,3), Z, Zc, m(3,3) * (Z - Zc))
    end
    xymm(i,2) = xp - c * (xnum / dnom);    % populate the output array x-value of image coordinates
    xymm(i,3) = yp - c * (ynum / dnom);    % populate the output array y-value of image coordinates
end
return

function [angleOut angleOut2] = limitPlusMinus180(angle)   % subfunction to limit range of angles to +- 180 deg

angleOut = angle;
if angle > 180 || angle < -180              % test for angle being out of range +-180 deg
    disp([inputname(1) ' input modified to stay within +- 180 deg range']) % if out of range display statement on Command Window
    if angle > 180       % test for angle greater than 180
        angleOut = angle - fix((angle - 180) / 360 + 1) * 360;  % redefine angle within +-180
    elseif angle < -180  % test for angle less than 180
        angleOut = angle - fix((angle - 180) / 360) * 360;      % redefine angle within +-180
    end
end        % end of out of +-180 range test
% end of subfunction limitPlusMinus180

angle = angle * pi / 180;
if abs(angle) > pi                 % routine to get angle in lowest form (pi >= theta >= -pi)
    ratio = angle / (2 * pi);      % get # of 2pi's in angle
    fraction = ratio - fix(ratio); % isolate fractional portion
    if abs(fraction) > .5          % test for greater than pi
        angleOut2 = fraction * 2 * pi -sign(fraction) * 2 * pi; % for example set -181 -> +179 if > 180
    else
        angleOut2 = fraction * 2 * pi;  % reset angle to lowest form if less or = pi (180)
    end
else
    angleOut2 = angle;
end

angleOut2 = angleOut2 * 180 / pi;
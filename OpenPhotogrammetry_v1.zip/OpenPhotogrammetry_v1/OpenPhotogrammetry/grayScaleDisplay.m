function grayScaleDisplay(img)

% grayscale display (interactive) with image in a figure window
% grayscaleDisplay(img) to invoke, where img is an image in the workspace
% or a valid image file name (either a character string or character variable)
% a get-file dialog box opens to select image file if no input argument
% image is displayed in top half of figure with interactive Pixel Region tool
% in lower half;  X, Y pixel and intensitity are shown as the cursor is moved
% either in the image or the Pixel Region tool area; slider bars on the Pixel
% Region tool allow for movement about the image to examine grayscale;
% a small rectangular box ovelay that represents the coverage of the Pixel
% Region tool can also be moved around the image to change the coverage

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: April 22, 2009
% primary author: A. W. Burner

sep = filesep;   % get platform dependent file separator 
if ~nargin   % test for no input argument
    [img userCancel] = imgetfile;  % open image file dialog box
    if userCancel   % if the user cancels out of the image file dialog box, exit function
        return
    end
    if exist(img, 'file')  % check for existence of file
        strInd = strfind(img, sep);  % find all file separators (sep) in string file name 'img'
        lastBackSlash = strInd(end); % last file separator location in 'img'
        imgString = img(lastBackSlash + 1: end); % create a character string with image file name only
        NameStr = ['Grayscale Display for file: ' imgString];  % create string for figure label
        imgArray = imread(img);  % needed for imshow below since imshow with fileName as input
                                 % does not except [] necessary to see 10 bit images stored as 16-bit                                 
    else
        fprintf(1, '%s file not found\n', img)
        fprintf(1, 'function grayScaleDisplay exited\n')
        return    % exit function if file does not exist
    end
elseif ischar(img)   % if 1 input argument and it is a string (file name)
    imgString = img; % create string from input argument file name for use in figure label
    if exist(img, 'file')  % check for existence of file
        NameStr = ['Grayscale Display for file: ' imgString];  % create string for figure label
        imgArray = imread(img);  % needed for imshow in line 54 since imshow with fileName as input
        % does not except [] necessary to see 10 bit images stored as 16-bit
    else
        fprintf(1, '%s file not found; function grayScaleDisplay exited\n', img)
        return    % exit function if file does not exist
    end
elseif ~ischar(img)  % if not a character string or character string variable
    NameStr = ['Grayscale Display for workspace variable: ' inputname(1)];  % create string for figure label
    imgArray = img;
end

% Create figure, turning some properties off that conflict with Pixel Region tool below
hfig = figure('Toolbar','none', 'Menubar', 'none', 'Name', NameStr,...
    'NumberTitle','off', 'IntegerHandle','off');
% Create axes and reposition the axes for the image to accommodate the Pixel Region tool panel
axes('Units','normalized', 'Position',[0 .5 1 .5]);
% Display image in the axes and get a handle to the image
himage = imshow(imgArray,[]);   % [] maps display to [min max] of image = [0 255] necessary for 10-bit images (stored as 16-bit) 
% Add Pixel Information tool, specifying image as parent
hinfo = impixelinfoval(gcf, himage);
% position pixel X,Y, intensity info for image (with larger font size)
set(hinfo, 'units', 'normalized', 'Position',[0 .49 .16 .04],'FontSize',10);
% Add Display Range tool, specifying image as parent
imdisplayrange(himage);
% Add Pixel Region tool panel, specifying figure as parent and image as target
hpixreg = impixelregionpanel(hfig, himage);
% Reposition the Pixel Region tool to fit in the figure window
% leaving room for the Pixel Information and Display Range tools
set(hpixreg, 'units','normalized','position',[0 .08 1 .4])
% Add Pixel Information tool, specifying Pixel Region tool as parent
impixelinfo(hpixreg);
return    % end of function grayscaleDisplay


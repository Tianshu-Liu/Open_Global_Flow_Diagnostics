function xy = centroid(img, x, y, delx, dely, Gback)

% gray scale centroid for a region of interest (roi)
% xy = centroid(img, x, y, delx, dely, Gback)
% where img is an image matrix
% already loaded into MATLAB with img = imread(filename)
% x, y are the horizontal and vertical pixel central location
% delx and dely are the half-width and half-height of the roi respectively
% pixels centroided from x - delx to x + delx and y - dely to y + dely
% width of roi = 2 * delx
% height of roi = 2 * dely
% Gback = gray scale to be subtracted before centroiding (optional argument)
% can be determined with Gback = FindBackground(img, x, y, delx, dely)
% negative gray scale values due to subtracting Gback are set to 0
% negative values of Gback will add gray scale before centroiding (for testing)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: July 23, 2007
% primary author: A. W. Burner

if nargin == 5   % if only 5 arguments set the optional argument Gback = 0
    Gback = 0;   % default for Gback (amount to be subtracted from each pixel)
end

% use row, column designations below to reduce confusion when dealing with
% 2D matrices of images which are row, column order (or y, x order)
delCol = round(delx);   % columns are associated with x 
delRow = round(dely);   % rows are associated with y
colMid = round(x);      % central column is at x-value of pixel location
rowMid = round(y);      % central row is at y-value of pixel location

delRowTop = delRow;      % initialize variables used for near edge test
delRowBottom = delRow;
delColLeft = delCol;
delColRight = delCol;

% image edge checks and adjustment to input parameters to accomodate target very near edge of image
rowimg = size(img, 1);
colimg = size(img, 2);
if rowMid - delRow < 1; delRowTop = rowMid - 1; end
if rowMid + delRow > rowimg; delRowBottom = rowimg - rowMid; end
if colMid - delCol < 1; delColLeft = colMid - 1; end
if colMid + delCol > colimg; delColRight = colimg - colMid; end

rowStart = rowMid - delRowTop; % start of rows defining pixel area roi
rowEnd = rowMid + delRowBottom;   % end of rows defining pixel area roi
colStart = colMid - delColLeft; % start of columns defining pixel area roi
colEnd = colMid + delColRight;   % end of columns defining pixel area roi

roi = img(rowStart : rowEnd, colStart : colEnd); % establish the roi
Nrows = size(roi,1); % get number of rows of roi
Ncols = size(roi,2); % get number of columns of roi

G = double(roi);  % use a double precision variable so math will work
G = G - Gback;    % subtract out designated background gray scale
G(G < 0) = 0;     % set any negative gray scale after subtraction to 0

% sum(sum(G)) needed in next line since sum(G) is a row vector of sum of columns
Gtot = sum(sum(G)); % scalar total of gray scale needed for centroid below

xindex = colStart : colStart + Ncols - 1; % get column values as a 'row vector' for matrix multiplication in next line
xsum = sum(G * xindex');                      % summation of the product of column # and gray scale; transpose needed for matrix multiplication
if Gtot > 0
    xcent = xsum / Gtot;                         % centroid computation for x (columns)
else
    xcent = NaN;
end
% xcent2 = sum(G * [colStart : colStart + Ncols - 1]') / Gtot   % 1 line x-centroid

yindex = rowStart : rowStart + Nrows - 1; % get row values as a 'row vector' for matrix multiplication in next line
ysum = sum(yindex * G);                     % summation of the product of row # and gray scale
if Gtot > 0
    ycent = ysum / Gtot;                        % centroid computation for y (rows)
else
    ycent = NaN;
end
xy = [xcent ycent];                         % set 1 X 2 variable containing x- and y-centroid for output as xy
return                                      % end of function


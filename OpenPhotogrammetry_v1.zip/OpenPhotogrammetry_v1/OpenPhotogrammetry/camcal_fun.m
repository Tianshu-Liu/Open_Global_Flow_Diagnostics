function [orien]=camcal_fun(camformat,approrien,xyimag,xyzobj,corr_no)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% camera calibration by optimization 
% parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1), where an optimization algorithm is used.
%
% Inputs:
%       (1) 'xyzobj', the object space coordinates of a number of known targets in inches, which is a three-colunm file. 
%       (2) 'xyimag', the corresponding image centroids in pixels, which is a two-colunm file.
%       (3) 'camformat', the camera format, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (4) 'approrien', the approximate camera orientation perameters for optimization, in which the higher-order
%           lens distortion parameters K2, P1 and P2 are set at zero, because the topology in these dimensions are
%           'weak' for the Matlab optimization scheme used here.
%       (5) 'corr_no', the iteration number for lens distortion correction. Normally, corr_no=1 when the lens distortion is small.
%
%  Outputs:
%       The camera orientation parameters:
%       For example, typical values of the orientation parameters:
%       Omega: -56 deg.
%       Phi: -9 deg.
%       Kappa: -80 deg.
%       Xc: -2 in
%       Yc: 56 in
%       Zc: 36 in
%       c: 28 mm
%       xp: 0.2 mm
%       yp: 0.08 mm
%       Sh/Sv: 0.923
%       K1 (mm^-2): 0.0005    
%       K2=0
%       P1=0
%       P2=0
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% give the initial approximation of the orientation parameters
exter=approrien(1:6);
inter=approrien(7:11);
inter(6)=0.00;
inter(7)=0.00;
inter(8)=0.00;

% optimization and distortion corrections

%%input the number of iteration for distortion correction
xyimagd=xyimag;
xyimagu=xyimag;

n=1;
while n<=corr_no 
    [x,out]=fminsearch('resec',inter,[],exter,camformat,xyimagd,xyimagu,xyzobj,n);
      
	%%distortion correction
	c=x(1);
	xp=x(2);
	yp=x(3);
	hv_ratio=x(4);
	k1=x(5);
	k2=0;
	p1=0;
	p2=0;

	x_range=camformat(1);
	y_range=camformat(2);
	Sv=camformat(4);
	Sh=hv_ratio*Sv;

	ximd=(xyimagd(:,1)-x_range/2)*Sh;
	yimd=-(xyimagd(:,2)-y_range/2)*Sv;

	ximu=(xyimagu(:,1)-x_range/2)*Sh;
	yimu=-(xyimagu(:,2)-y_range/2)*Sv;

	xx=ximu-xp;
	yy=yimu-yp;

	r2=xx.^2+yy.^2;
	deltaxr=k1*xx.*r2+k2*xx.*(r2.*r2);
	deltayr=k1*yy.*r2+k2*yy.*(r2.*r2);
	deltaxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
	deltayd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
	deltax=deltaxr+deltaxd;
	deltay=deltayr+deltayd;

	xyimagu(:,1)=(ximd+deltax)/Sh+x_range/2;
	xyimagu(:,2)=-(yimd+deltay)/Sv+y_range/2;

	inter=[x(1:5);0;0;0];
	n=n+1;
	[residual,exterior]=resecA(inter,exter,camformat,xyimagd,xyimagu,xyzobj);
    orien=[exterior;inter];
end

fprintf('\nFinal Orientation Parameters:\n');
fprintf('Omega (deg): %g\n',orien(1));
fprintf('Phi (deg): %g\n',orien(2));
fprintf('Kappa (deg): %g\n',orien(3));
fprintf('Xc (in): %g\n',orien(4));
fprintf('Yc (in): %g\n',orien(5));
fprintf('Zc (in): %g\n',orien(6));
fprintf('c(mm): %g\n',orien(7));
fprintf('xp(mm): %g\n',orien(8));
fprintf('yp(mm): %g\n',orien(9));
fprintf('Sh/Sv: %g\n',orien(10));
fprintf('K1 (mm^-2): %g\n',orien(11));
fprintf('K2 (mm^-2): %g\n',orien(12));
fprintf('P1 (mm^-2): %g\n',orien(13));
fprintf('P2 (mm^-2): %g\n',orien(14));
fprintf('Residual (mm): %g\n',residual);

xyplot(camformat,orien,xyimag,xyzobj,2);
title('Improvement by Optimization');
     
     
     
function camLocalMin = resectionLocalMin(cam, Zmean)

% determines 3 alternate sets of exterior orientation for resection on near planar objects
% which are possible local minima
% cal-plate primary lateral dimensions are assumed to be X, Y with Z ~= constant (depth)
% camLocalMin = resectionLocalMin(cam, Zmean)
% angles must be in degrees
% cam is an input structure with at least the following fields
% cam.omega
% cam.phi  
% cam.kappa
% cam.Xc
% cam.Yc  
% cam.Zc
% Zmean is an optional input scalar that is the mean of the Z-coordinates of the cal-plate
% if the mean of the Z-values are not 0
% camLocalMin is an ouput structure with the following fields
% camLocalMin.omega
% camLocalMin.phi  
% camLocalMin.kappa
% camLocalMin.Xc
% camLocalMin.Yc  
% camLocalMin.Zc
% the 1st value of each output field is the input (except all angles are restricted to +-180 deg)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: February 11, 2007
% primary author: A. W. Burner

if nargin == 1  % test for 1 argument and set Zmean to default
    Zmean = 0;  % default Zmean = 0 if optional input argument not used
end             % end of 1 argument test
camLocalMin.omega = limitPlusMinus180(cam.omega); % restrict input angles to +-180 deg
cam.phi   = limitPlusMinus180(cam.phi);           % restrict input angles to +-180 deg
cam.kappa = limitPlusMinus180(cam.kappa);         % restrict input angles to +-180 deg

camLocalMin.omega = [cam.omega -cam.omega -cam.omega cam.omega]; % echo input and compute 3 sets of minima
camLocalMin.phi   = [cam.phi   -cam.phi   -cam.phi   cam.phi];   % echo input and compute 3 sets of minima
if abs(cam.kappa + 180) <= abs(cam.kappa - 180)                  % test for which choice of +-180 gives value within +-180
    camLocalMin.kappa = [cam.kappa (cam.kappa + 180) cam.kappa (cam.kappa + 180)]; % add 180 to kappa (elements 2, 4) if pass test
else   % if abs(cam.kappa + 180) > abs(cam.kappa - 180)
    camLocalMin.kappa = [cam.kappa (cam.kappa - 180) cam.kappa (cam.kappa - 180)]; % subtract 180 from kappa (elements 2, 4) if fail test
end   % end of kappa +-180 test
camLocalMin.Xc = [cam.Xc cam.Xc -cam.Xc -cam.Xc]; % echo input and compute 3 sets of minima
camLocalMin.Yc = [cam.Yc cam.Yc -cam.Yc -cam.Yc]; % echo input and compute 3 sets of minima
camLocalMin.Zc = [cam.Zc (2*Zmean - cam.Zc) cam.Zc (2*Zmean - cam.Zc)]; % echo input and compute 3 sets of minima (with Zmean correction)
% end of main function resectionLocalMin

function angle = limitPlusMinus180(angle)   % subfunction to limit range of angles to +- 180 deg
if angle > 180 || angle < -180              % test for angle being out of range +-180 deg
    disp([inputname(1) ' input modified to stay within +- 180 deg range']) % if out of range display statement on Command Window
    if angle > 180       % test for angle greater than 180
        angle = angle - fix((angle - 180) / 360 + 1) * 360;  % redefine angle within +-180
    elseif angle < -180  % test for angle less than 180
        angle = angle - fix((angle - 180) / 360) * 360;      % redefine angle within +-180
    end
end        % end of out of +-180 range test
% end of subfunction limitPlusMinus180

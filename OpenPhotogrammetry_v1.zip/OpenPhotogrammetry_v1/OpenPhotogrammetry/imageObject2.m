function camOut = imageObject2(camIn)

% calculates focal length, object distance, or image distance
% given 2 of the 3 variables passed to the function via
% structure camIn with the following fields (all must be in same units)
% camIn.f - focal length
% camIn.obj - object distance
% camIn.img - image distance
% output structure camOut with the following fields (2 echoed from camIn and 1 computed)
% camOut.f - focal length
% camOut.obj - object distance
% camOut.img - image distance
% camOut has same units as camIn

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date:October 27, 2006
% primary author: A. W. Burner

% test to determine if required input fields are present in input argument structure
if ~isfield(camIn, 'f') || ~isfield(camIn, 'obj') || ~isfield(camIn, 'img') % check for missing required fields
    disp('function imageObject2 exited')
    disp('required fields are .f, .obj, .img of input structure')
    camOut = camIn;  % set output structure to input structure to avoid output argument error
    return  % exit function if required fields not present
end  % end of required fields test

if camIn.f & camIn.obj & camIn.img;  % test and exit if none of fields = [] (must use only 1 '&' since argument not strictly logical)
    disp('function imageObject2 exited')
    disp('1 field (f, obj, or img) of input structure must be []')
    camOut = camIn;  % set output structure to input structure to avoid output argument error
    return  % exit function
end % end of test for at least 1 field entry = []
if camIn.f; f = camIn.f; end       % if not = [], set value for focal length f
if camIn.obj; obj = camIn.obj; end % if not = [], set value for object distance obj
if camIn.img; img = camIn.img; end % if not = [], set value for image distance img

% test to make sure that if f is solved for, that obj and img exist
if ~exist('f', 'var') && exist('obj', 'var') && exist('img', 'var')
    f = (1/obj + 1/img)^-1;  % calculate f
elseif ~exist('f', 'var')    % don't try to solve for f if either obj or img don't exist
    disp('function imageObject2 exited')
    disp('only 1 field (f, obj, or img) of input structure can be = []')
    camOut = camIn;  % set output structure to input structure to avoid output argument error
    return % exit function
end        % end of f solve, test for obj and img existance
% test to make sure that if obj is solved for, that f and img exist
if ~exist('obj', 'var') && exist('f', 'var') && exist('img', 'var')
    obj = (1/f - 1/img)^-1;  % calculate obj
elseif ~exist('obj', 'var')  % don't try to solve for obj if either f or img don't exist
    disp('function imageObject2 exited')
    disp('only 1 field (f, obj, or img) of input structure can be = []')
    camOut = camIn;  % set output structure to input structure to avoid output argument error
    return % exit function
end        % end of obj solve, test for f and img existance
% test to make sure that if img is solved for, that f and obj exist
if ~exist('img', 'var') && exist('f', 'var') && exist('obj', 'var')
    img = (1/f - 1/obj)^-1;  % calculate img
elseif ~exist('img', 'var')  % don't try to solve for img if either f or obj don't exist
    disp('function imageObject2 exited')
    disp('only 1 field (f, obj, or img) of input structure can be = []')
    camOut = camIn;  % set output structure to input structure to avoid output argument error
    return % exit function
end        % end of img solve, test for f and obj existance

% populate output structure camOut with either calculated or echoed value (from  input argument) of variable
camOut.f = f;     
camOut.obj = obj;
camOut.img = img;
return  % end of function imageObject2




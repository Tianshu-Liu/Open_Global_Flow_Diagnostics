function [orien]=dlt(camformat,xyimag,xyzobj)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DLT to determine initial approximations for the camera orientation parameters 
%
% Inputs: (1) 'camformat' is the camera format file,
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%         (2) 'xyimag' is the target coordinate file in the image plane in pixels 
%         (3) 'xyzobj' is the target coordinate file in the object space in inches.
%
% Outputs: orien, The orientation parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp)
%
%  Note that xp and yp given by the DLT are very sensitive to small errors, and they may not be accurate.
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% convert the target coordinates to 'mm' in both the image plane and object space 
x_range=camformat(1);
y_range=camformat(2);
Sv=camformat(4);
Sh=camformat(3);

xim=(xyimag(:,1)-x_range/2)*Sh;
yim=-(xyimag(:,2)-y_range/2)*Sv;

% convert inch to mm for the object space coordinates
xm=xyzobj(:,1)*25.4;
ym=xyzobj(:,2)*25.4;
zm=xyzobj(:,3)*25.4;

% obtain the DLT solution
a11=xm;
a12=ym;
a13=zm;
a14=1*ones(length(xm),1);
a15=0*ones(length(xm),1);
a16=0*ones(length(xm),1);
a17=0*ones(length(xm),1);
a18=0*ones(length(xm),1);
a19=-xim.*xm;
a110=-xim.*ym;
a111=-xim.*zm;
a21=0*ones(length(xm),1);
a22=0*ones(length(xm),1);
a23=0*ones(length(xm),1);
a24=0*ones(length(xm),1);
a25=xm;
a26=ym;
a27=zm;
a28=1*ones(length(xm),1);
a29=-yim.*xm;
a210=-yim.*ym;
a211=-yim.*zm;
a=[a11 a12 a13 a14 a15 a16 a17 a18 a19 a110 a111;
   a21 a22 a23 a24 a25 a26 a27 a28 a29 a210 a211];
b1=xim;
b2=yim;
b=[b1;b2];
neq=a'*a;
rhs=a'*b;
L=neq\rhs; % DLT parameters

% convert the DLT parameters to the camera orientation parameters
e1=[L(1) L(2) L(3);
    L(5) L(6) L(7);
    L(9) L(10) L(11)];
e2=-[L(4);L(8);1];
XYZc=(e1\e2)/25.4;
LL=-1/(L(9)^2+L(10)^2+L(11)^2)^0.5;
xp=(L(1)*L(9)+L(2)*L(10)+L(3)*L(11))*LL^2;
yp=(L(5)*L(9)+L(6)*L(10)+L(7)*L(11))*LL^2;
c=(LL^2*(L(1)^2+L(2)^2+L(3)^2)-xp^2)^0.5;
%omega=atan(-L(10)/L(11))*180/pi;
omega=atan2(-L(10),L(11))*180/pi;
phi=asin(L(9)*LL)*180/pi;
m11=LL*(xp*L(9)-L(1))/c;
kappa=acos(m11/cos(phi*pi/180))*180/pi;
interior=[c;0;0;Sh/Sv;0];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% list the possible valus of omega, phi and kappa based on the DLT results
domega=2;
dphi=2;
dkappa=2;

N=64;
k=1;
for i=1:N
    omegatest=90*(i-N/2)+omega;
    if (omegatest<180) && (omegatest>-180)
       omega_v(k)=omegatest;
	k=k+1;
    end   
end
omega_v=[-omega;omega_v']+domega;

k=1;
for i=1:N
    phitest=90*(i-N/2)+phi;
    if (phitest<180) && (phitest>-180)
       phi_v(k)=phitest;
	k=k+1;
    end   
end

phi_v=[-phi;phi_v']+dphi;

k=1;
for i=1:N
    kappatest=90*(i-N/2)+kappa;
    if (kappatest<180) && (kappatest>-180)
       kappa_v(k)=kappatest;
	k=k+1;
    end   
end

kappa_v=[-kappa;kappa_v']+dkappa;

% find omega, phi, and kappa that have a minimum the standard deviation
exterior=[omega_v(1);phi_v(1);kappa_v(1);XYZc];
[dxp,exterior]=resec3(0.0001,interior,exterior,camformat,xyimag,xyimag,xyzobj);
ori_esti=[exterior;interior;[0;0;0]];
[xyimag_esti]=XYZ2xy_4_dlt(ori_esti,xyzobj,camformat);
%dxp=abs(abs(xyimag-xyimag_esti));

lowestCost=dxp;
besti=1;bestj=1;bestk=1;

fprintf('\n Estimate initial approximations of the orientation parameters.\n Please Wait!');
for i=1:length(omega_v)
    for j=1:length(phi_v)
        for k=1:length(kappa_v)
        	exterior=[omega_v(i);phi_v(j);kappa_v(k);XYZc];
            [dxp,exterior]=resec3(0.0001,interior,exterior,camformat,xyimag,xyimag,xyzobj);
            ori_esti=[exterior;interior;[0;0;0]];
            [xyimag_esti]=XYZ2xy_4_dlt(ori_esti,xyzobj,camformat);
            %dxp=abs(abs(xyimag-xyimag_esti));
            
            cost=dxp;
            if cost<lowestCost
                besti=i;bestj=j;bestk=k;
                lowestCost=cost;
            end
        end
    end
	fprintf('\n Running. Please Wait!');
end	

exterior=[omega_v(besti);phi_v(bestj);kappa_v(bestk);XYZc];
[dxp,exterior]=resec3(0.0001,interior,exterior,camformat,xyimag,xyimag,xyzobj);

% convert to the ranges of -180<omega<180, -90<phi<90, -180<kappa<180.
for i=1:10
	omega_up=(i-1)*360+exterior(1);
	if (omega_up>-180) && (omega_up<180)
   	omega=omega_up;
	break;
        end
	omega_down=-(i-1)*360+exterior(1);
	if (omega_down>-180) && (omega_down<180)
   	omega=omega_down;
	break;
        end
end

for i=1:10
	phi_up=(i-1)*180+exterior(2);
	if (phi_up>-90) && (phi_up<90)
   	phi=phi_up;
	break;
        end
	phi_down=-(i-1)*180+exterior(2);
	if (phi_down>-90) && (phi_down<90)
   	phi=phi_down;
	break;
        end
end

for i=1:10
	kappa_up=(i-1)*360+exterior(3);
	if (kappa_up>-180) && (kappa_up<180)
   	kappa=kappa_up;
	break;
        end
	kappa_down=-(i-1)*360+exterior(3);
	if (kappa_down>-180) && (kappa_down<180)
   	kappa=kappa_down;
	break;
        end
end

exterior=[omega;phi;kappa;XYZc];

orien=[exterior;interior];

fprintf('\n\nApproximate Orientation Parameters:\n');
fprintf('%g\t\n',orien);
fprintf('Standard deviation: %g\n',dxp);

% plot the results
xyplot(camformat,orien,xyimag,xyzobj,1);
title('Initial Estimation by DLT');












function XYZsv = singleView(cam, xymm, XYZ)

% single view photogrammetry computing 1 or 2 coordinates if 2 or 1 known
% XYZsv =  singleView(cam, xymm, XYZ)
% cam is a structure with fields as follows
% cam.c
% cam.xp
% cam.yp
% cam.m  rotation matrix from function rotationMatrix
% cam.Xc
% cam.Yc
% cam.Zc
% where c = principal distance (camera constant, mm)
% xp, yp locates the photogrammetric principal point, mm
% m = 3 X 3 rotation matrix (use function rotationMatrix)
% Xc, Yc, Zc = location of perspective center
% Xc, Yc, Zc and XYZ should normally be in same units (for example inches)
% xymm input array is an N X 3 of image coordinates [pt1 x1 y2; pt2 x2
% y2;...ptN xN yN]
% XYZ input argument is a structure with the following 4 fields
% XYZ.pnt (target number)
% XYZ.X   (X-value in object space)
% XYZ.Y   (Y-value in object space)
% XYZ.Z   (Z-value in object space)
% the coordinate to be solved for should be set to [] in XYZ structure
% as, for instance, XYZ.Y = [];  The other coordinates not solved for
% are echoed in the output array XYZsv along with the coordinates solved for
% units of ouput array XYZsv same as units of XYZ (and Xc, Yc, Zc)
% XYZsv is an N X 4 array for solutions for X,Y or X,Z, or Y,Z pairs
% [pt1 X1 Y2 Z3; pt2 X2 Y2 Z2;...ptN XN YN ZN]
% for single coordinate solutions for X, Y, or Z, a 5th column is ouputted
% so that the output array XYZsvwhich contains the least squares computed standard deviation of the coordinate
% but note that there is only 1 degree of freedom for this computation
% only target numbers common to both xymm and XYZ.pnt are evaluated
% output array XYZsv does not have the missing target numbers

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

% error test and exit function for argument structure XYZ with no entries (all = []:)
if ~length(XYZ.X) && ~length(XYZ.Y) && ~length(XYZ.Z);   % if all lengths == 0 ('~' indicates 'NOT')
    fprintf(1,'function singleView exited\nargument XYZ.X, XYZ.Y, XYZ.Z all = []; need 2 views to solve for X, Y, and Z\n')
    return   % exit function if XYZ.X, XYZ.Y, XYZ.Z all = []
end

% error test and exit function for argument structure XYZ with all entries populated
if length(XYZ.X) && length(XYZ.Y) && length(XYZ.Z);  % if all lengths > 0
    fprintf(1,'function singleView exited\nno unknowns specified (at least one of XYZ.X, XYZ.Y, or XYZ.Z must = [])\n')
    return   % exit function if XYZ.X, XYZ.Y, XYZ.Z all contain data (no unknowns specified)
end

print2CommandWindow = 0;
c  = cam.c;    % get values from input structure cam for use below
xp = cam.xp;
yp = cam.yp;
m  = cam.m;
Xc = cam.Xc;
Yc = cam.Yc;
Zc = cam.Zc;

commonNum = intersect(xymm(:,1), XYZ.pnt);  % find target numbers common to both xymm and XYZ.pnt
xymmIndex = []; % initialize index for xymm array
XYZIndex  = []; % initialize index for XYZ structure
for i=1:length(commonNum)  % step through common set of target numbers found above
    xymmIndex = [xymmIndex; find(xymm(:,1) == commonNum(i))];  % create index of xymm containing common target numbers
    XYZIndex  = [XYZIndex;  find(XYZ.pnt   == commonNum(i))];  % create index of XYZ containing common target numbers
end
xymm    = xymm(xymmIndex,:); % redefine xymm with common target numbers only
XYZ.pnt = XYZ.pnt(XYZIndex); % redefine XYZ.pnt with common target numbers only
if length(XYZ.X); XYZ.X = XYZ.X(XYZIndex); end % if not [], redefine XYZ.X with data from common target numbers only
if length(XYZ.Y); XYZ.Y = XYZ.Y(XYZIndex); end % if not [], redefine XYZ.Y with data from common target numbers only
if length(XYZ.Z); XYZ.Z = XYZ.Z(XYZIndex); end % if not [], redefine XYZ.Z with data from common target numbers only

solve4X  = 0; solve4Y  = 0; solve4Z  = 0;  % initialize solve4 indicator variables to no solve
solve4XY = 0; solve4XZ = 0; solve4YZ = 0;  % initialize solve4 indicator variables to no solve
if     ~length(XYZ.X) && ~length(XYZ.Y); solve4XY = 1; % if no data for X & Y, solve for X, Y  ('~' indicates 'NOT')
elseif ~length(XYZ.X) && ~length(XYZ.Z); solve4XZ = 1; % if no data for X & Z, solve for X, Z
elseif ~length(XYZ.Y) && ~length(XYZ.Z); solve4YZ = 1; % if no data for y & Z, solve for Y, Z
elseif ~length(XYZ.X); solve4X = 1; % if no data for X only, solve for X
elseif ~length(XYZ.Y); solve4Y = 1; % if no data for Y only, solve for Y
elseif ~length(XYZ.Z); solve4Z = 1; % if no data for Z only, solve for Z
end

XYZsv = [];             % initialize single view photogrammetry output array
Sx    = [];             % intialize standard deviation for solutions for single coordinates
Nrows = size(xymm,1);   % determine number of rows (image coordinate pairs) in xymm with common target numbers
for i = 1:Nrows         % step through image and object coordinates for each common target
    x = xymm(i,2) - xp; % subtract xp and define new image x-coordinate for further computations
    y = xymm(i,3) - yp; % subtract yp and define new image y-coordinate for further computations
    XYZsv(i,1) = XYZ.pnt(i); % set target number for output array XYZsv from common target numbers in XYZ.pnt

    a1 = x * m(3,1) + c * m(1,1); % coefficients from collinearity equations next 6 lines
    a2 = x * m(3,2) + c * m(1,2);
    a3 = x * m(3,3) + c * m(1,3);
    a4 = y * m(3,1) + c * m(2,1);
    a5 = y * m(3,2) + c * m(2,2);
    a6 = y * m(3,3) + c * m(2,3);

    if solve4XY           % solving for X and Y
        Z = XYZ.Z(i);          % set Z from XYZ.Z field of structure XYZ
        A = [a1 a2; a4 a5];    % create 2 X 2 matrix A for 2 equations in 2 unknowns
        B = [a1 * Xc + a2 *Yc + a3 * Zc - a3 * Z; a4 * Xc + a5 *Yc + a6 * Zc - a6 * Z];  % create 2 X 1 matrix B for 2 equations in 2 unknowns
        solut = A\B;           % MATLAB Gausian elimination
        XYZsv(i,2) = solut(1); % X-solution is 1st element of 2 X 1 matrix solut
        XYZsv(i,3) = solut(2); % Y-solution is 2nd element of 2 X 1 matrix solut
        XYZsv(i,4) = Z;        % echo input Z-value into output array XYZsv
    elseif solve4XZ 
        Y = XYZ.Y(i);
        A = [a1 a3; a4 a6];
        B = [a1 * Xc + a2 *Yc + a3 * Zc - a2 * Y; a4 * Xc + a5 *Yc + a6 * Zc - a5 * Y];
        solut = A\B;    % MATLAB Gausian elimination
        XYZsv(i,2) = solut(1);
        XYZsv(i,3) = Y;
        XYZsv(i,4) = solut(2);
    elseif solve4YZ
        X = XYZ.X(i);
        A = [a2 a3; a5 a6];
        B = [a1 * Xc + a2 *Yc + a3 * Zc - a1 * X; a4 * Xc + a5 *Yc + a6 * Zc - a4 * X];
        solut = A\B;    % MATLAB Gausian elimination
        XYZsv(i,2) = X;
        XYZsv(i,3) = solut(1);
        XYZsv(i,4) = solut(2);
    elseif solve4X
        Y = XYZ.Y(i);
        Z = XYZ.Z(i);
        A =  [a1; a4];
        B =  [a1 * Xc + a2 *Yc + a3 * Zc - a2 * Y - a3 * Z; a4 * Xc + a5 *Yc + a6 * Zc - a5 * Y - a6 * Z];
        solut = A\B;    % MATLAB Gausian elimination
        XYZsv(i,2) = solut;
        XYZsv(i,3) = Y;
        XYZsv(i,4) = Z;
    elseif solve4Y
        X = XYZ.X(i);
        Z = XYZ.Z(i);
        A =  [a2; a5];
        B =  [a1 * Xc + a2 *Yc + a3 * Zc - a1 * X - a3 * Z; a4 * Xc + a5 *Yc + a6 * Zc - a4 * X - a6 * Z];
        solut = A\B;    % MATLAB Gausian elimination
        XYZsv(i,2) = X;
        XYZsv(i,3) = solut;
        XYZsv(i,4) = Z;
    elseif solve4Z
        X = XYZ.X(i);
        Y = XYZ.Y(i);
        A =  [a3; a6];
        B =  [a1 * Xc + a2 *Yc + a3 * Zc - a1 * X - a2 * Y; a4 * Xc + a5 *Yc + a6 * Zc - a4 * X - a5 * Y];
        solut = A\B;    % MATLAB Gausian elimination
        XYZsv(i,2) = X;
        XYZsv(i,3) = Y;
        XYZsv(i,4) = solut;
    end   % end of solve4 loop
    if solve4X || solve4Y || solve4Z   % test for solving for any single coordinate 
        % Elements of Photogrammetry 2nd ed. Wolf p 571...
        % degrees of freedom df = 1
        V = A * solut - B;             % B is designated by L in Wolf
        So = sqrt((V' * V));           % standard deviation of unit weight (with df = 1)
        covariance = inv(A' * A);      % compute covariance matrix
        Sx(i) = So * sqrt(covariance); % equivalent to So * sqrt(diag(covariance)) to compute standard deviation of X
        XYZsv(i,5) = Sx(i);
    end    % end of test for single coordinate solves
end
% info to Command Window regarding which coordinates solved for in next 6 statements
if print2CommandWindow
if solve4XY;     fprintf(1,'X (2nd col) and Y (3rd col) coordinates solved for in XYZsv output file of function singleView\n');
elseif solve4XZ; fprintf(1,'X (2nd col) and Z (4th col) coordinates solved for in XYZsv output file of function singleView\n');
elseif solve4YZ; fprintf(1,'Y (3rd col) and Z (4th col) coordinates solved for in XYZsv output file of function singleView\n');
elseif solve4X;  fprintf(1,'X (2nd col) and Xsig (5th col) solved for in XYZsv output file of function singleView\n');
elseif solve4Y;  fprintf(1,'Y (3rd col) and Ysig (5th col) solved for in XYZsv output file of function singleView\n');
elseif solve4Z;  fprintf(1,'Z (4th col) and Zsig (5th col) solved for in XYZsv output file of function singleView\n');
end
end
return   % end of function singleView



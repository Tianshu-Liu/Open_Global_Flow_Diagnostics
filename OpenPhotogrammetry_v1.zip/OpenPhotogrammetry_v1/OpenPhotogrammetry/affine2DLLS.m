function [Thetaxy, Txy, Sxy, So] = affine2DLLS(xin, xtrans)

% linear least squares to determine affine transformation coefficients
% and estimates of their standard deviation for 2D coordinates
% [Thetaxy, Txy, Sxy, So] = affine2DLLS(xin, xtrans)
% the affine transfomation is of the form below
% xt = a1 * x + a2 * y + Tx =  Sx * cos(thetax) * x + Sy * sin(thetay) + Tx
% yt = b1 * x + b2 * y + Ty = -Sx * sin(thetax) * x + Sy * cos(thetay) + Ty
% input xin is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% input xtrans is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% output Thetaxy is a 2 X 2 array in which the 1st column contains the
% rotation angles of the x- and y-axis in degrees, + for CW and the 
% 2nd column contains the least squares estimate of their standard deviations 
% output Txy is a 2 X 2 array in which the 1st column contains the
% x, y translations Tx, Ty and the 2nd column contains the
% least squares estimate of their standard deviations 
% Sxy is a 2 X 2 array in which the 1st column contains the
% x- and y-axis scale factors and the 2nd column contains the
% least squares estimate of their standard deviations 
% So is a scalar which contains the least squares standard deviation of
% unit weight

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 11, 2006
% primary author: A. W. Burner

commonNum = intersect(xin(:,1), xtrans(:,1));  % find target numbers common to both xin and xtrans
xinIndex = []; % initialize index for xin array
xtransIndex  = []; % initialize index for xtrans array
for i=1:length(commonNum)  % step through common set of target numbers found above
    xinIndex    = [xinIndex;     find(xin(:,1)    == commonNum(i))];  % create index of xin containing common target numbers
    xtransIndex = [xtransIndex;  find(xtrans(:,1) == commonNum(i))];  % create index of xtrans containing common target numbers
end
xin    = xin(xinIndex, :);       % redefine xin with common target numbers only
xtrans = xtrans(xtransIndex, :); % redefine xtrans(:,1) with common target numbers only

Nrows = size(xin, 1);  % find number of rows (number of target point numbers) of the redefined xin (and xtrans)
A = [];   % initialize the array A that represents the right hand side of the affine transformation
L = [];   % initialize the column vector L which represents the left hand side of the affine transformation
for i = 1: Nrows      % step through each coordinate pair of the redefined xin (and xtrans) 
    x = xin(i,2);     % create x as a scalar containing the x-value of a coordinate pair from xin
    y = xin(i,3);     % create y as a scalar containing the y-value of a coordinate pair from xin
    xt = xtrans(i,2); % create xt as a scalar containing the x-value of a coordinate pair from xtrans
    yt = xtrans(i,3); % create yt as a scalar containing the y-value of a coordinate pair from xtrans
    j = 2*i - 1;      % j is intermediate index 1:2:2 * Nrows - 1 since there will 2 equations for each coordinate pair
    L(j)   = xt;      % populate L matrix (left hand side of trans) for x-equation
    L(j+1) = yt;      % populate L matrix (left hand side of trans) for y-equation      
    A(j,1) = x;       % populate A matrix (right hand side of trans), a1 term
    A(j,2) = y;       % j index is for the x-equation of the transformation, a2 term
    A(j,3) = 0;       % b1 term is 0 for x-equation
    A(j,4) = 0;       % b2 term is 0 for x-equation
    A(j,5) = 1;       % Tx term
    A(j,6) = 0;       % Ty term = 0 for x-equation
    A(j+1,1) = 0;     % j+1 index is for the y-equation of the transformation, a1 term = 0 for y-equation
    A(j+1,2) = 0;     % a2 = 0 for y-equation
    A(j+1,3) = x;     % b1 term for y-equation
    A(j+1,4) = y;     % b2 term
    A(j+1,5) = 0;     % Tx term = 0 for y-equation
    A(j+1,6) = 1;     % Ty term
end                   % end of loop stepping through coordinate pairs
L = L';               % make L a column vector for matrix math next line
X = A\L;              % MATLAB least squares solution column vector
a1 = X(1);            % put solutions into common variable names
a2 = X(2);            % put solutions into common variable names
b1 = X(3);            % put solutions into common variable names
b2 = X(4);            % put solutions into common variable names
Tx = X(5);            % put solutions into common variable names
Ty = X(6);            % put solutions into common variable names
Sx = sqrt(a1^2 + b1^2); % compute x-scale
Sy = sqrt(a2^2 + b2^2); % compute y-scale
thetax = atan2(-b1, a1) * 180 / pi; % compute thetax and convert to degrees
thetay = atan2(a2, b2) * 180 / pi;  % compute thetay and convert to degrees
Thetaxy = [thetax; thetay]; % create output column array for theta values
Txy = [Tx; Ty];             % create output column array for translation values
Sxy = [Sx; Sy];             % create output column array for scale values
df = (size(A, 1) - length(X)); % compute degrees of freedom = number of equations - number of unknowns
V = A * X  - L;                % compute residuals
So = sqrt(V' * V / df);        % compute standard deviation of unit weight
covar = inv(A' * A);           % compute covariance matrix
stdX = So * sqrt(diag(covar)); % standard deviation estimates = square root of diagonals of covariance X So
stda1 = stdX(1);               % put standard deviation in common name variable
stda2 = stdX(2);               % put standard deviation in common name variable
stdb1 = stdX(3);               % put standard deviation in common name variable
stdb2 = stdX(4);               % put standard deviation in common name variable
stdTx = stdX(5);               % put standard deviation in common name variable
stdTy = stdX(6);               % put standard deviation in common name variable
stdSx = sqrt(((a1 * stda1)^2 + (b1 * stdb1)^2) / (a1^2 + b1^2)); % error propagation for std of Sx
stdSy = sqrt(((a2 * stda2)^2 + (b2 * stdb2)^2) / (a2^2 + b2^2)); % error propagation for std of Sy
stdthetax = (sqrt(((a1 * stdb1)^2 + (b1 * stda1)^2)) / (a1^2 + b1^2)) *180 / pi; % error propagation for std of thetax
stdthetay = (sqrt(((b2 * stda2)^2 + (a2 * stdb2)^2)) / (b2^2 + a2^2)) *180 / pi; % error propagation for std of thetay
Thetaxy = [Thetaxy [stdthetax; stdthetay]]; % append 2nd column to Thetaxy containing standard deviations
Txy = [Txy [stdTx; stdTy]];                 % append 2nd column to Txy containing standard deviations
Sxy = [Sxy [stdSx; stdSy]];                 % append 2nd column to Sxy containing standard deviations
return                                      % end of function

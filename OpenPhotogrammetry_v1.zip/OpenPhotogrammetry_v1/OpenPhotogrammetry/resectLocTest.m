a1=[];
for ang =-1000:1:1000
    if ang>180
        ang = ang-fix((ang-180)/360 + 1) * 360;
    elseif ang<-180
        ang = ang-fix((ang-180)/360) * 360;
    end
    a1=[a1; ang];
end
figure(1)
clf
hold off
plot([-1000:1:1000],a1)

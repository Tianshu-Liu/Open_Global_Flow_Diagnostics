function m = rotationMatrix(omega, phi, kappa, AngleUnits)

% 3 X 3 rotation matrix omega, phi, kappa
% m = rotationMatrix(omega, phi, kappa) assumes input in degrees
% m = rotationMatrix(omega, phi, kappa, AngleUnits)
% if optional ainput argument AngleUnits = 'radians' (exactly) then 3 input angles assumed radians
% (if AngleUnits anything other than 'radians' then degrees are assumed)
% sign convention for angles: ccw is +

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: March 15, 2007
% primary author: A. W. Burner

n = nargin;   % determine number of input arguments
if n < 3     % test for 3 input arguments and exit function if not = 3
    disp '3 (or 4) arguments are necessary to invoke function m = RotationMatrix(omega, phi, kappa, AngleUnits)'
    disp 'Type ''help RotationMatrix'' to see argument definitions'
    return
else
    if n == 4 && size(AngleUnits,2) == 7 && strcmp(AngleUnits, 'radians') % strcmp is string compare
        W = omega;   % angles already in radians so no conversion necessary
        P = phi;
        K = kappa;
    else
        W = omega * pi / 180;  % convert angles from degrees to radians
        P = phi * pi / 180;
        K = kappa * pi / 180;
    end
    
    % reference: Manual of Photogrammetry, 4th edition, American Society of Photogrammetry,
    % Chester C. Slama, Editor-in-Chief, Falls Church, Virginia, 1980, p. 51.
    
    m = [];   % initialize output array
    m(1,1) = cos(P) * cos(K);
    m(1,2) = sin(W) * sin(P) * cos(K) + cos(W) * sin(K);
    m(1,3) = -cos(W) * sin(P) * cos(K) + sin(W) * sin(K);
    m(2,1) = -cos(P) * sin(K);
    m(2,2) = -sin(W) * sin(P) * sin(K) + cos(W) * cos(K);
    m(2,3) = cos(W) * sin(P) * sin(K) + sin(W) * cos(K);
    m(3,1) = sin(P);
    m(3,2) = -sin(W) * cos(P);
    m(3,3) = cos(W) * cos(P);
end
return
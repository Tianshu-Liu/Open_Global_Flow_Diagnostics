function [c V] = cameraConstant(cam, XYZ)

% finds camera constant given image data at 2 or more known Z-displacements
% c = cameraConstant(cam, XYZ)
% of a calibration plate (can be planar)
% cam is a structure array with at least the following fields
% cam(N).c
% cam(N).xp
% cam(N).yp
% cam(N).omega
% cam(N).phi
% cam(N).kappa
% cam(N).Xc
% cam(N).Yc
% cam(N).Zc
% cam(N).xymm
% elements N of the structure array cam represent the image data from
% each displaced location of the calibration plate.  Normally all fields
% but cam(N).Zc and cam(N).xymm would be identical for all elements
% cam(N).Zc should contain the approximate distance to the cal plate.  The
% actual values should reflect accurately the differential Z-displacement
% of the cal plate.  XYZ is an N X 4 [pnt X Y Z] file.
% output is a structure c with the following fields
% c.c - camera constant (principal distance)
% c.cstd - least squares estimate of standard deviation of error in c
% a special case allowed for is a 3-step cal plate with step heights of 
% 2-inches with targets 1-18, 19-36, 37-54 at each step height.  For this
% special case cam is only one element.

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 30, 2006
% primary author: A. W. Burner

Nviews = length(cam);  % get number of elements of input structure array cam (number of Z-displacements)
if Nviews > 1          % normal computation for 2 or more Z-displacements of cal plate
    Zm = [cam(1: Nviews).Zc]; % get relative displacement values from cam(:).Zc
    OneViewFlag = 0;          % set flag for more than 1 view
else                          % else special case of 1-image of 54 target 3 step plate
    Zm = [0 2 4];             % set Zm to assumed 3 step heights
    OneViewFlag = 1;          % set 1 view flag on
    Nviews = 3;               % set Nviews to 3 since image data from each of the 3-steps is treated separately
    cam(2:3) = cam(1);        % create 2 more elements of cam for 3-step computations below
    xymm = cam(1).xymm;       % temporary holder for all 54 image points
    cam(1).xymm = xymm(1:18,:);  % set cam(1) image data to targets in 1st step height
    cam(2).xymm = xymm(19:36,:); % set cam(1) image data to targets in 2nd step height
    cam(3).xymm = xymm(37:54,:); % set cam(1) image data to targets in 3rd step height
end                              % end 1-view separation loop

for iterations = 1:15            % iterate 15 times (well-behaved cases only require a few iterations, 15 iterations helps handle more troublesome cases)
    for i= 1: Nviews             % step through each Z-displacement data set
        camOut(i) = resection(cam(i), XYZ);  % do resection on each Z-displacement data set
    end                          % end of step through loop                                  
    Zr = [camOut(1: Nviews).Zc]; % collect Zc data from output of resection into array Zr
    if OneViewFlag               % special 3-step plate 1-view case
        delZr = Zm - Zr;         % Zm versus (Zm - Zr) for linear fit
    else                         % normal 2 or more Z-displacements
        delZr =Zr;               % Zm versus Zr for linear fit
    end                          % end of OneViewFlag if statement

    p = polyfit(delZr, Zm, 1); % 1st order fit 
    slope = p(1);                  % slope is 1st coefficient
    c.c = cam(1).c * slope;        % expression for computing camera constant c
    if Nviews > 2                  % if 3 or more views compute standard deviation from least squares
        L = Zm';                 % make left hand side a column vector
        A = [delZr' ones(length(delZr),1)]; % A matrix [L = A * sol or Zm = delZr * (slope) + intercept]
        sol = A\L;                    % least squares solution 
        df = (size(A, 1) - length(sol)); % compute degrees of freedom = number of equations - number of unknowns
        V = A * sol  - L;                % compute residuals
        So = sqrt(V' * V / df);          % compute standard deviation of unit weight
        covar = inv(A' * A);             % compute covariance matrix
        stdsol = So * sqrt(diag(covar)); % standard deviation estimates = square root of diagonals of covariance times So
        c.cstd = cam(1).c * stdsol(1);   % error propagation for computed standard deviation from least squares
    else                                 % otpion for only 2 views
        c.cstd = 0;                      % set standard deviation to 0 if 2 views
    end                                  % end of Nviews if statement
    % fprintf(1,'%7d %7.4f %7.4f\n', iterations, cam(1).c, c.cstd)  % use this print statement to test number of interations needed
    [cam.c] = deal(c.c);  % set field cam(N).c to c.c for all elements before next iteration
end % end of iterations loop
return % end of function cameraConstant

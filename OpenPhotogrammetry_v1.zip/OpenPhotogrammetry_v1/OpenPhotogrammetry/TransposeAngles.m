function Angle = TransposeAngles(Parameter)

% omega, phi, kappa for tanspose of rotation matrix
% Angle = TransposeAngles(Parameter)
% returns omega, phi, kappa for rotation matrix that is the transpose of
% the rotation matrix formed by the input arguments; input is structure
% Parameter containing at least the 3 following fields
% Parameter.omega, Parameter.phi, Parameter.kappa
% output is structure with the following 3 fields
% Angle.omega, Angle.phi, Angle.kappa
% computations use the transpose of normal angle relationships for omega, phi, kappa

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

m = rotationMatrix(Parameter.omega, Parameter.phi, Parameter.kappa); % compute rotation matrix for input angles
Angle.omega = -atan2(m(2,3), m(3,3)) * 180 / pi; % compute omega with 4 quadrant atan2
Angle.phi = asind(m(1, 3));                      % compute phi 
Angle.kappa = -atan2(m(1,2), m(1,1)) * 180 / pi; % compute kappa with 4 quadrant atan2
mNew = rotationMatrix(Angle.omega, Angle.phi, Angle.kappa); % compute rotation matrix for output angles
maxError = max(max(abs(mNew - m')));             % compute max error compared to m'
if maxError > 1e-12                              % test for non-significant error
    fprintf(1,'WARNING, may be errors in ouput angles\n')  % print error warning to Command Window
    fprintf(1,'maximum absolute error using output angles compared to input m'' is %g\n', maxError)
end
return                                           % end of function TransposeAngles

function displayGrayScale(img, x, y, delx, dely, Gback)

% displays gray scale for ROI
% displayGrayScale(img, x, y, delx, dely, Gback)
% where img is an image matrix
% already loaded into MATLAB with img = imread(filename);
% x, y are the horizontal and vertical pixel central location
% delx and dely are half-width and half-height of display pixel area 
% pixels displayed from x - delx to x + delx and y - dely to y + dely
% simple call is possible with delx = dely = 8; Gback = 0; displayGrayScale(img, x, y)
% Gback is an optional input argument that indicates the amount of gray
% scale to subtract before display (use function findBackground to determine Gback)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: June 13, 2009
% primary author: A. W. Burner

if nargin == 3   % test for 3 arguments and set remaining 3 optional arguments to default values
    delx = 8;    % default for half-width
    dely = 8;    % default for half-height
    Gback = 0;   % default fot Gback (gray scale to be subtracted from each pixel before displaying)
end

if nargin == 5   % test for 5 arguments and set Gback to default
    Gback = 0;   % default Gback
end

% use row, column designations below to reduce confusion when dealing with
% 2D matrices of images which are row, column order (or y, x order)
delCol = round(delx);   % columns are associated with x-value of pixel area to be diplayed
delRow = round(dely);   % rows are associated with y-value of pixel area to be diplayed
colMid = round(x);      % central column is at x-value of pixel location
rowMid = round(y);      % central row is at y-value of pixel location

delRowTop = delRow;      % initialize variables used for near edge test
delRowBottom = delRow;
delColLeft = delCol;
delColRight = delCol;

% image edge checks and adjustment to input parameters to accomodate target very near edge of image
rowimg = size(img, 1);
colimg = size(img, 2);
if rowMid - delRow < 1; delRowTop = rowMid - 1; end
if rowMid + delRow > rowimg; delRowBottom = rowimg - rowMid; end
if colMid - delCol < 1; delColLeft = colMid - 1; end
if colMid + delCol > colimg; delColRight = colimg - colMid; end

rowStart = rowMid - delRowTop; % start of rows defining pixel area roi
rowEnd = rowMid + delRowBottom;   % end of rows defining pixel area roi
colStart = colMid - delColLeft; % start of columns defining pixel area roi
colEnd = colMid + delColRight;   % end of columns defining pixel area roi

roi = img(rowStart : rowEnd, colStart : colEnd); % establish the roi
Nrows = size(roi,1);  % determine number of rows of roi

maxGray = max(max(roi)); % determine maximum gray scale in roi; max(roi) finds max of each column of roi
                         % max(max(roi)) then finds max (single number) from the row vector returned by max(roi)
if maxGray < 1000 && x + delx < 1000       % setup formating based on size of gray scale and x-location (horixontal pixel location at top)
    fmt = '%4d';         % 4 spaces wide for printing
    fprintf(1,'    ')    % print to Command Window 4 spaces to allow for pixel y-location down left of display
elseif maxGray > 999 && maxGray < 10000 || x + delx > 999 && x + delx < 10000 % setup formating based on size of gray scale and x-location (horixontal pixel location at top)
    fmt = '%5d';                        % 5 spaces wide
    fprintf(1,'     ')                  % print 5 spaces to allow for y-location down left of display
else
    fmt = '%6d';                        % for larger gray scale use 6 spaces
    fprintf(1,'      ')                 % print 6 spaces to allow for y-location down left of display
end

fprintf(1, fmt, colStart:colEnd)  % using format determined above, print out the column numbers (x-pixel values) at the top of the display
fprintf(1,'\n')                   % line feed
row = rowStart:rowEnd;            % define a vector with the rows (y-pixel values)
G = double(roi) - Gback;          % set new gray scale G by subtracting Gback from each pixel; double(roi) needed because roi is unit8
G(G < 0) = 0;                     % set all negative values in the gray scale G to 0

for i = 1:Nrows                     % step down (increasing downward) through the rows (y-pixel values)       
    fprintf(1,fmt,[row(i) G(i,:)])  % print out in proper format each row of G, preceded by the row # (y-pixel value)
    fprintf(1,'\n')                 % line feed
end
fprintf(1,'\n')                     % final line feed
return


function OmegaPhiKappa = Australis2PM(Azimuth, Elevation, Roll)

% returns omega, phi, kappa output in degrees from Australis Azimuth, Elevation, Roll input in degrees
% OmegaPhiKappa = Australis2PM(Azimuth, Elevation, Roll)
% ccw is + for omega, phi, kappa 
% output OmegaPhiKappa is 1 X 3 array of angles

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

Az = Azimuth * pi / 180;  % convert angles to radians
El = Elevation * pi / 180;
Rl = Roll * pi / 180;
m = [];     % initialize rotation matrix m
m(1,1) = sin(Az) * sin(El) * sin(Rl) + cos(Az) * cos(Rl);  % compute elements of rotation matrix using Az, El, Rl
m(1,2) = -cos(Az) * sin(El) * sin(Rl) + sin(Az) * cos(Rl);
m(1,3) = cos(El) * sin(Rl);
m(2,1) =  sin(Az) * sin(El) * cos(Rl) - cos(Az) * sin(Rl);
m(2,2) = -cos(Az) * sin(El) * cos(Rl) - sin(Az) * sin(Rl);
m(2,3) = cos(Az) * cos(Rl);
m(3,1) = sin(Az) * cos(El);
m(3,2) = -cos(Az) * cos(El);
m(3,3) = -sin(El);

% next line computes omega, phi, kappa
OmegaPhiKappa = [ atan2(-m(3,2), m(3,3))*180/pi asind(m(3,1)) atan2(-m(2,1), m(1,1))*180/pi];
% fprintf(1,'%s\n', ['  azim   elev     roll  omega   phi    kappa']);
% fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', Azimuth, Elevation, Roll, OmegaPhiKappa);
return  % end of function Australis2PM


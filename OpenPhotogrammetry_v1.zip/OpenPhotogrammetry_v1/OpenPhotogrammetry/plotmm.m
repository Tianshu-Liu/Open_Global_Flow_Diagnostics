function plotmm(xymm, plotColor, holdState, symbol)

titleStr = inputname(1);
if nargin == 1           % test for 1 argument and set plotColor and symbol to default
    symbol = 'o';        % default symbol
    plotColor = 'b';     % default plotColor if input argument not used
    holdState = 'off';   % default 'hold off' if input argument not used
elseif nargin == 2       % test for 2 arguments and set plotColor to default
    symbol = 'o';        % default symbol
    holdState = 'off';   % default 'hold off' if input argument not used
elseif nargin == 3       % test for 3 arguments and set plotColor to default
    symbol = 'o';        % default symbol
end

if strcmp(holdState, 'on')
    figure(gcf)
    titleStr = [inputname(1) ' overlaid on last mm plot'];
else
    figure
end
eval(['hold ' holdState])
plotSymbolColor = [symbol plotColor];  % set up symbol and plot color
plot(xymm(:,2), xymm(:,3), plotSymbolColor)
title(titleStr)
xlabel('x, mm')
ylabel('y, mm')



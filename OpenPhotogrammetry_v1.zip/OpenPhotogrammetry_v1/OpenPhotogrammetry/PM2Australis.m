function AzimuthElevationRoll=PM2Australis(omega, phi, kappa)

% returns Australis Azimuth, Elevation, Roll with omega, phi, kappa input in degrees
% AzimuthElevationRoll = PM2Australis(omega, phi, kappa)
% ccw is + for omega, phi, kappa

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

W = omega * pi / 180;  % convert angles to radians
P = phi * pi / 180;
K = kappa * pi / 180;
m = [];   % initialize rotation matrix m
m(1,1) = cos(P) * cos(K);      % compute 9 elements of rotation matrix
m(1,2) = sin(W) * sin(P) * cos(K) + cos(W) * sin(K);
m(1,3) = -cos(W) * sin(P) * cos(K) + sin(W) * sin(K);
m(2,1) = -cos(P) * sin(K);
m(2,2) = -sin(W) * sin(P) * sin(K) + cos(W) * cos(K);
m(2,3) = cos(W) * sin(P) * sin(K) + sin(W) * cos(K);
m(3,1) = sin(P);
m(3,2) = -sin(W) * cos(P);
m(3,3) = cos(W) * cos(P);

% next line outputs azimuth, elevation, roll
AzimuthElevationRoll = [atan2(m(3,1), -m(3,2))*180/pi asin(-m(3,3))*180/pi atan2(m(1,3), m(2,3))*180/pi];
% fprintf(1,'%s\n', ['  omega   phi    kappa    azim   elev     roll']);
% fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', omega, phi, kappa, AzimuthElevationRoll);

return  % end of function PM2Australis 
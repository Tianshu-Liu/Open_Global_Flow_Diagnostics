function [imgOut roi] = roiSelect(img, rejectFlag)

% select by mouse 1 or more regions of interest (roi) on an image; rest of image = 0
% [imgOut roi] = roiSelect(img) or [imgOut roi] = roiSelect(img, 'reject') 
% input argument img can be a character string or character string variable representing a
% valid image file; img can also be an image already loaded into the workspace
% a get-file dialog box opens to select image file if no input argument
% optional input argument rejectFlag is a character string = 'reject' if
% one desires an output image with the roi's set to 0 and the rest of the image
% to remain as is; any string other than 'reject' will be ignored
% output argument imgOut is an image (same size nad class as imput image)
% with roi data from img superimposed on a background of 0 (or if rejectFlag
% set to 'reject' img Out will be original image with roi's set to 0)
% output argument roi is a numeric N X 4 array containing [xmin ymin width height] for N roi's

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: October 1, 2006
% primary author: A. W. Burner

if ~nargin   % test for no input argument
    [img userCancel] = imgetfile;  % open image file dialog box
    if userCancel   % if the user cancels out of the image file dialog box, exit function
        return
    end
    strInd = strfind(img, '\');  % find all backslashes in string file name 'img'
    lastBackSlash = strInd(end); % last backslash location in 'img'
    imgString = img(lastBackSlash + 1: end); % create a character string with image file name only
elseif ischar(img)   % if 1 input argument and it is a string (file name)
    imgString = img; % create string from input argument file name for use in figure label
elseif ~ischar(img)  % if not a character string or character string variable
    NameStr = ['workspace variable: ' inputname(1)];  % create string for figure label
    widthImg = size(img,2);  % width is number of columns (2nd element of size)
    heightImg = size(img,1); % height is number of rows (1st element of size)
end  % end of no argument and img character string test
if ischar(img) && exist(img, 'file')  % test to see if img is a file name
    NameStr = ['file: ' imgString];  % create string for figure label
    info = imfinfo(img);     % get info structure for file
    widthImg = info.Width;   % width from field Width
    heightImg = info.Height; % height from field Height
elseif ischar(img) && ~exist(img, 'file')
    roi = [];       % create empty dummy output argument roi
    fprintf(1, '%s file not found\n', img)
    fprintf(1, 'function roiSelect exited\n')
    return    % exit function if file does not exist
end           % end of file name or workspace image test
if nargin == 2 && strcmp(rejectFlag, 'reject')  % check for existance of a 2nd input argument = 'reject' (exactly)
    rejectFlag = 1;  % set reject flag to 1
else
    rejectFlag = 0;  % set reject flag to 0 if 2nd input argument not 'reject'
end           % end of rejectFlag test and set
figure('Name', NameStr);  % put label at top of figure
imshow(img)  % display image in figure window
title('select roi''s; click ouside of image to exit');  % display title
hold on  % set hold to on for roi perimeter plots below
contFlag = 1;  % set continue flag to 1 to start while loop
roi = [];      % initialize roi array to null
while contFlag % execute loop while continue flag is on
    roiTemp = getrect;  % interactive rectangle on image
    % roiTemp = [xmin ymin width height] (ouput)
    % contFlag is 1 (true) if roi within image; = 0 (false) if 1 click outside image
    contFlag = all(roiTemp > 0) && all([roiTemp(1) roiTemp(3)+roiTemp(1)] < widthImg) && all([roiTemp(2) roiTemp(4)+roiTemp(2)] < heightImg);
    if contFlag % plot perimeter and append to output array roi if true ( = 1)
        plot([roiTemp(1) roiTemp(1) roiTemp(1)+roiTemp(3) roiTemp(1)+roiTemp(3) roiTemp(1)], [roiTemp(2) roiTemp(2)+roiTemp(4) roiTemp(2)+roiTemp(4) roiTemp(2) roiTemp(2)],'r')
        roi = [roi; roiTemp];
    end
end  % end of contFlag while loop
title('finished selecting rectangles');
hold off

if ischar(img); img = imread(img); end  % only need if img is a filename in order to get class of image in next line
classImg = class(img);  % string variable indicating class of img for next line
if rejectFlag     % test for reject flag
    imgOut = img; % create new image same size as img for overlay below
else              % if reject flag not set then do next line
    imgOut = eval([classImg '(zeros(size(img)))']); % create new image same size as img, but all 0's
end               % end of reject flag test
Nrois = size(roi,1); % number of rows of roi array (number of roi's)
for roiIndex = 1 : Nrois % step through each row of the roi array
    % round is used in next 4 lines to ensure that the new variables are integers (required for imgOut... line to surpress warning)
    colStart = round(roi(roiIndex,1)); % start column (x) is in 1st column of roi
    rowStart = round(roi(roiIndex,2)); % start row (y) is in 2nd column of roi
    colEnd = round(roi(roiIndex,1) + roi(roiIndex,3)); % delta columns (delta-x) is in 3rd column of roi
    rowEnd = round(roi(roiIndex,2) + roi(roiIndex,4)); % delta rows (delta-y) is in 4th column of roi
    if rejectFlag    % test for reject flag set
        imgOut(rowStart:rowEnd, colStart:colEnd) = 0;   % set roi's to 0 if reject flag set
    else             % reject flag not set
        imgOut(rowStart:rowEnd, colStart:colEnd) = img(rowStart:rowEnd, colStart:colEnd);  % put roi data from img in imgOut (rest of image = 0)
    end              % end of test for rejectFlag
end  % end of loop stepping through roi array
figure  % create new figure
imshow(imgOut)  % display newly created image with background 0 + roi portions of img
if rejectFlag   % test for reject flag set
    title('output image = input image with roi''s set to 0')
else            % if reject flag not set
    title('output image (same size as input) = roi''s of input image superimposed on a background of 0')
end             % end of reject flag test
return   % end of function roiSelect
function Parameter = conformal3DNLLS(XYZ1, XYZ2, Start)

% non-linear least squares (NLLS) to determine conformal transformation coefficients and
% estimates of their standard deviations for 3D coordinates
% Parameter = conformal3DNLLS(XYZ1, XYZ2, Start)
% represents [XYZ2] = s * [m] * [XYZ1] + [Txyz]
% input XYZ1 is an N X 4 array [pt1 X1 Y1 Z1; pt2 X2 Y2 Z2; ...ptN XN YN ZN];
% input XYZ2 is an N X 4 array [pt1 X1 Y1 Z1; pt2 X2 Y2 Z2; ...ptN XN YN ZN];
% Start is an input structure with the following fields
% Start.omega - start value for omega (degrees)
% Start.omegaTol - tolerance for omega, angle about X + CCW, within NLLS; for all tolerances [] indicates no tolerance,
% or free to vary, 0 indicates treat the parameter as a constant (do not solve for parameter), and a finite value
% sets a hard clip range of parameter +- tolerance for variation range within non-linear least squares
% Start.phi; Start.phiTol angle about Y, + CCW
% Start.kappa; Start.kappaTol angle about Z, + CCW
% Start.Tx; Start.TxTol tranlation in X-direction and tolerance
% Start.Ty; Start.TyTol tranlation in Y-direction and tolerance
% Start.Tz; Start.TzTol tranlation in Z-direction and tolerance
% Start.s; Start.sTol scale and tolerance
% ouput is the structure Parameter with the following fields
% Parameter.omega - rotation angle in degrees, + for CCW
% Parameter.phi - rotation angle in degrees, + for CCW
% Parameter.kappa - rotation angle in degrees, + for CCW
% Parameter.Tx - X translation of transformation Tx
% Parameter.Ty - Y translation of transformation Ty
% Parameter.Tz - Z translation of transformation Ty
% Parameter.s- scale
% Parameter.omegastd - estimated standard deviation from NLLS
% Parameter.phistd - estimated standard deviation from NLLS
% Parameter.kappastd - estimated standard deviation from NLLS
% Parameter.Txstd - estimated standard deviation from NLLS
% Parameter.Tystd - estimated standard deviation from NLLS
% Parameter.Tzstd - estimated standard deviation from NLLS
% Parameter.sstd - estimated standard deviation from NLLS
% Parameter.So - scalar containing least squares standard deviation of unit weight

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: June 23, 2009
% primary author: A. W. Burner

% June 23, 2009:  previous version
% March 12, 2011: omega.Tol -> omegaTol; phi.Tol - phiTol

% test for all Start.parameterTol = 0 and exit function if so
if ~Start.omegaTol & ~Start.phiTol & ~Start.kappaTol & ~Start.TxTol & ~Start.TyTol & ~Start.TzTol & ~Start.sTol
    Parameter = test4allStartTolEqual0(Start); % subfunction to setup output structure Parameter
    return  % exit function
end  % end of test if segment

[omega phi kappa Tx Ty Tz s] = setStartValues(Start); % subfunction to setup start values

i = find(isnan(XYZ1(:,2)) | isnan(XYZ1(:,3)) | isnan(XYZ1(:,4)));  % find NaN's in XYZ1
XYZ1(i, :) = [];  % remove NaNs from XYZ1
i = find(isnan(XYZ2(:,2)) | isnan(XYZ2(:,3)) | isnan(XYZ2(:,4)));  % find NaN's in XYZ2
XYZ2(i, :) = [];  % remove NaNs from XYZ2

[XYZ1 XYZ2] = commonTargetNumbers(XYZ1, XYZ2); % subfunction to redefine XYZ1 and XYZ2 with only common target numbers

[solve4omega solve4phi solve4kappa solve4Tx solve4Ty solve4Tz solve4s...
    omegaTol phiTol kappaTol TxTol TyTol TzTol sTol] = setSolve4andTol(Start); % subfunction to setup solve4 and parameterTol variables

Nrows=size(XYZ1,1);
% from Wolf p.596 +- a few pages 2nd ed.
for iterations = 1:20      % 20 iterations for NLLS
    A = [];   % initialize the array A that represents the right hand side of the conformal transformation
    L = [];   % initialize the column vector L which represents the left hand side of the conformal transformation
    m = rotationMatrix(omega, phi, kappa, 'radians');  % pass as radians
                 % since angles in computations below are in radians until final output
    for i = 1:Nrows
        x = XYZ1(i,2); % next 6 lines sets up local xyz variables for calculations below
        y = XYZ1(i,3);
        z = XYZ1(i,4);
        X = XYZ2(i,2);
        Y = XYZ2(i,3);
        Z = XYZ2(i,4);
        j = 3*i - 2; % set up 1 2 3 for 1st point (i=1) 4 5 6 for 2nd (i=2), etc.
        k = 0;       % set k = 0; k is index for column of A matrix
        if solve4s; k = k + 1; A(j, k) = m(1,1) * x + m(1,2) * y + m(1,3) * z; end % dels term for X-equation
        if solve4omega; k = k + 1; A(j, k) = (-m(1,3) * y + m(1,2) * z) * s; end % delomega term
        if solve4phi; k = k + 1; A(j, k) = (-sin(phi) * cos(kappa) * x + sin(omega) * cos(phi) * cos(kappa) * y + cos(kappa) * z) * s; end % delphi term
        if solve4kappa; k = k + 1; A(j, k) = (m(2,1) * x + m(2,2) * y + m(2,3) * z) * s; end % delkappa term
        if solve4Tx; k = k + 1; A(j, k) = 1; end  % delTx term
        if solve4Ty; k = k + 1; A(j, k) = 0; end  % delTy term
        if solve4Tz; k = k + 1; A(j, k) = 0; end  % delTz term
        k = 0;   % set k = 0; k is index for column of A matrix
        if solve4s; k = k + 1;  A(j + 1, k) = m(2,1) * x + m(2,2) * y + m(2,3) * z; end % dels term for Y-equation
        if solve4omega; k = k + 1; A(j + 1, k) = (- m(2,3) * y + m(2,2) * z) * s; end % delomega
        if solve4phi; k = k + 1; A(j + 1, k) = (sin(phi) * sin(kappa) * x - sin(omega) * cos(phi) * sin(kappa) * y + cos(omega) * cos(phi) * sin(kappa) * z) * s; end % delphi
        if solve4kappa; k = k + 1; A(j + 1, k) = (-m(1,1) * x - m(1,2) * y - m(1,3) * z) * s; end % delkappa
        if solve4Tx; k = k + 1; A(j + 1, k) = 0; end % delTx
        if solve4Ty; k = k + 1; A(j + 1, k) = 1; end % delTy
        if solve4Tz; k = k + 1; A(j + 1, k) = 0; end % delTz
        k = 0;   % set k = 0; k is index for column of A matrix
        if solve4s; k = k + 1; A(j + 2, k) = m(3,1) * x + m(3,2) * y + m(3,3) * z; end % dels term for Z-equation
        if solve4omega; k = k + 1; A(j + 2, k) = (-m(3,3) * y + m(3,2) * z) * s; end % delomega
        if solve4phi; k = k + 1; A(j + 2, k) = (cos(phi) * x + sin(omega) * sin(phi) * y - cos(omega) * sin(phi) * z) * s; end % delphi
        if solve4kappa; k = k + 1; A(j + 2, k) = 0; end % delkappa
        if solve4Tx; k = k + 1; A(j + 2, k) = 0; end % delTx
        if solve4Ty; k = k + 1; A(j + 2, k) = 0; end % delTy
        if solve4Tz; k = k + 1; A(j + 2, k) = 1; end % delTz
        L(j, 1) = X - s*(m(1,1) * x + m(1,2) * y + m(1,3) * z) - Tx;     % left hand side X-equation
        L(j + 1, 1) = Y - s*(m(2,1) * x + m(2,2) * y + m(2,3) * z) - Ty; % left hand side Y-equation
        L(j + 2, 1) = Z - s*(m(3,1) * x + m(3,2) * y + m(3,3) * z) - Tz; % left hand side Z-equation
    end  % end of for loop to populate A and L matrices for NNLS iteration

    Solution = A\L; % MATLAB least squared solution to L = A * Solution
    k = 0;   % index for solution vector Solution for delparameter terms
    if solve4s; k = k + 1; s = s + Solution(k); end             % pick scale s out of solution vector Solution if not entered as a constant (Tol = 0)
    if solve4omega; k = k + 1; omega = omega + Solution(k); end % pick omega out of solution vector Solution if not entered as a constant (Tol = 0)
    if solve4phi; k = k + 1; phi = phi + Solution(k); end       % pick phi out of solution vector Solution if not entered as a constant (Tol = 0)
    if solve4kappa; k = k + 1; kappa = kappa + Solution(k); end % pick kappa out of solution vector Solution if not entered as a constant (Tol = 0)
    if solve4Tx; k = k + 1; Tx = Tx + Solution(k); end          % pick Tx out of solution vector Solution if not entered as a constant (Tol = 0)
    if solve4Ty; k = k + 1; Ty = Ty + Solution(k); end          % pick Ty out of solution vector Solution if not entered as a constant (Tol = 0)
    if solve4Tz; k = k + 1; Tz = Tz + Solution(k); end          % pick Tz out of solution vector Solution if not entered as a constant (Tol = 0)

    if Start.sTol    % test for tolerance > 0 and not []
        if s > Start.s + sTol; s = Start.s + sTol;         % hard clip parameter to +- tolerance
        elseif s < Start.s - sTol; s = Start.s - sTol; end % hard clip parameter to +- tolerance
    end              % end of tolerance 'if segment' for scale s
    if Start.omegaTol % test for tolerance > 0 and not []
        if omega > Start.omega + omegaTol; omega = Start.omega + omegaTol;         % hard clip parameter to +- tolerance
        elseif omega < Start.omega - omegaTol; omega = Start.omega - omegaTol; end % hard clip parameter to +- tolerance
    end              % end of tolerance if segment for omega
    if Start.phiTol % test for tolerance > 0 and not []          
        if phi > Start.phi + phiTol; phi = Start.phi + phiTol;         % hard clip parameter to +- tolerance
        elseif phi < Start.phi - phiTol; phi = Start.phi - phiTol; end % hard clip parameter to +- tolerance
    end              % end of tolerance if segment for phi
    if Start.kappaTol % test for tolerance > 0 and not []
        if kappa > Start.kappa + kappaTol; kappa = Start.kappa + kappaTol;         % hard clip parameter to +- tolerance
        elseif kappa < Start.kappa - kappaTol; kappa = Start.kappa - kappaTol; end % hard clip parameter to +- tolerance
    end              % end of tolerance if segment for kappa
    if Start.TxTol % test for tolerance > 0 and not []
        if Tx > Start.Tx + TxTol; Tx = Start.Tx + TxTol;          % hard clip parameter to +- tolerance
        elseif Tx < Start.Tx - TxTol; Tx = Start.Tx - TxTol; end  % hard clip parameter to +- tolerance
    end              % end of tolerance if segment for Tx
    if Start.TyTol % test for tolerance > 0 and not []
        if Ty > Start.Ty + TyTol; Ty = Start.Ty + TyTol;          % hard clip parameter to +- tolerance
        elseif Ty < Start.Ty - TyTol; Ty = Start.Ty - TyTol; end  % hard clip parameter to +- tolerance
    end               % end of tolerance if segment for Ty
    if Start.TzTol % test for tolerance > 0 and not []
        if Tz > Start.Tz + TzTol; Tz = Start.Tz + TzTol;          % hard clip parameter to +- tolerance
        elseif Tz < Start.Tz - TzTol; Tz = Start.Tz - TzTol; end  % hard clip parameter to +- tolerance
    end               % end of tolerance if segment for Tz
   % disp(iterations)
   % disp(Solution) 
%    if all(abs(Solution) < 0.0000001)
%         break;
%     end    
end                   % end of iterations loop
df = (size(A, 1) - length(Solution)); % compute degrees of freedom = number of equations - number of unknowns
V = A * Solution  - L;                % compute residuals
So = sqrt(V' * V / df);        % compute standard deviation of unit weight
covar = inv(A' * A);           % compute covariance matrix
stdSolution = So * sqrt(diag(covar)); % standard deviation estimates = square root of diagonals of covariance times So
[sstd omegastd phistd kappastd Txstd Tystd Tzstd] = deal(0); % initialize all std's to 0
k = 0; % index for stdSolution
if solve4s; k = k + 1; sstd = stdSolution(k); end         % put standard deviation in common name variable
if solve4omega; k = k + 1; omegastd = stdSolution(k); end % put standard deviation in common name variable
if solve4phi; k = k + 1; phistd = stdSolution(k); end     % put standard deviation in common name variable
if solve4kappa; k = k + 1; kappastd = stdSolution(k); end % put standard deviation in common name variable
if solve4Tx; k = k + 1; Txstd = stdSolution(k); end       % put standard deviation in common name variable
if solve4Ty; k = k + 1; Tystd = stdSolution(k); end       % put standard deviation in common name variable
if solve4Tz; k = k + 1; Tzstd = stdSolution(k); end       % put standard deviation in common name variable

Parameter.omega = omega * 180 / pi;  % next 16 lines populates the output structure Parameter
Parameter.phi = phi * 180 / pi;
Parameter.kappa = kappa * 180 / pi;
Parameter.Tx = Tx;
Parameter.Ty = Ty;
Parameter.Tz = Tz;
Parameter.s = s;
Parameter.omegastd = omegastd * 180 / pi;
Parameter.phistd = phistd * 180 / pi;
Parameter.kappastd = kappastd * 180 / pi;
Parameter.Txstd = Txstd;
Parameter.Tystd = Tystd;
Parameter.Tzstd = Tzstd;
Parameter.sstd = sstd;
Parameter.So = So;
return %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end of main function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Parameter = test4allStartTolEqual0(Start) % subfunction test for all Start.parameterTol = 0 and exit function if so
% next 'if seqment' tests for all Start.parameterTol = 0 which indicates do
% not solve for any parameters; if so, exits function after setting all output
% values to input values with 0 standard deviation, also prints to Command
% Window that no parameters were solved for
if ~Start.omegaTol && ~Start.phiTol && ~Start.kappaTol && ~Start.TxTol && ~Start.TyTol && ~Start.TzTol && ~Start.sTol % test for all Start.parameterTol = 0
    Parameter.omega = Start.omega; % set output values to input values (and 0 standard deviation)
    Parameter.phi = Start.phi;     % set output values to input values (and 0 standard deviation)
    Parameter.kappa = Start.kappa; % set output values to input values (and 0 standard deviation)
    Parameter.Tx = Start.Tx;       % set output values to input values (and 0 standard deviation)
    Parameter.Ty = Start.Ty;       % set output values to input values (and 0 standard deviation)
    Parameter.Tz = Start.Tz;       % set output values to input values (and 0 standard deviation)
    Parameter.s = Start.s;         % set output values to input values (and 0 standard deviation)
    [Parameter.omegastd Parameter.phistd Parameter.kappastd Parameter.Txstd Parameter.Tystd Parameter.Tzstd Parameter.sstd Parameter.So] = deal(0);  % set all std's to 0
    fprintf(1,'No parameters solved for since all Start.parameterTol = 0\n') % print to Command Window
end                                 % end of if segment
return % end of subfuncion test4allStartTolEqual0

function [omega phi kappa Tx Ty Tz s] = setStartValues(Start)  % subfunction to setup start values
% starting values (input angles in deg converted to radians for NLLS)
omega = Start.omega * pi / 180; % omega start value (radians)
phi = Start.phi * pi / 180;     % phi start value (radians)
kappa = Start.kappa * pi / 180; % kappa start value (radians)
Tx = Start.Tx;                  % Tx start value
Ty = Start.Ty;                  % Ty start value
Tz = Start.Tz;                  % Tz start value
s = Start.s;                    % scale s start value
return % end of subfuncion setStartValues

function [XYZ1 XYZ2] = commonTargetNumbers(XYZ1, XYZ2) % subfunction to redefine XYZ1 and XYZ2 with only common target numbers
commonNum = intersect(XYZ1(:,1), XYZ2(:,1));  % find target numbers common to both XYZ1 and XYZ2 arrays
XYZ1index = []; % initialize index for XYZ1 array
XYZ2index = []; % initialize index for XYZ2 structure
for i=1:length(commonNum)  % step through common set of target numbers found above
    XYZ1index = [XYZ1index; find(XYZ1(:,1) == commonNum(i))];  % create index of XYZ1 containing common target numbers
    XYZ2index = [XYZ2index; find(XYZ2(:,1) == commonNum(i))];  % create index of XYZ2 containing common target numbers
end    % end of loop stepping through common target numbers
XYZ1 = XYZ1(XYZ1index, :); % redefine XYZ1 with common target numbers only
XYZ2 = XYZ2(XYZ2index, :); % redefine XYZ2 with common target numbers only
return % end of subfunction commonTargetNumbers

function [solve4omega solve4phi solve4kappa solve4Tx solve4Ty solve4Tz solve4s...   
    omegaTol phiTol kappaTol TxTol TyTol TzTol sTol] = setSolve4andTol(Start) % subfunction to setup solve4 and parameterTol variables
[solve4omega solve4phi solve4kappa solve4Tx solve4Ty solve4Tz solve4s] = deal(1); % solve for these 7 parameters unless any Start.parameterTol = 0
[omegaTol phiTol kappaTol TxTol TyTol TzTol sTol] = deal([]); % initialize to [] for pass back to main function
if Start.sTol          % test for tolerance > 0 and not []
    sTol = Start.sTol; % put tolerance in local variable
elseif ~Start.sTol     % test for tolerance = 0 
    solve4s = 0;       % do not solve for s
end                    % end of s tolerance if segment
if Start.omegaTol      % test for tolerance > 0 and not []
    omegaTol = Start.omegaTol; % put tolerance in local variable
elseif ~Start.omegaTol         % test for tolerance = 0 
    solve4omega = 0;           % do not solve for theta
end                            % end of omega tolerance if segment
if Start.phiTol                % test for tolerance > 0 and not []
    phiTol = Start.phiTol;     % put tolerance in local variable
elseif ~Start.phiTol           % test for tolerance = 0 
    solve4phi = 0;             % do not solve for theta
end                            % end of phi tolerance if segment
if Start.kappaTol              % test for tolerance > 0 and not []
    kappaTol = Start.kappaTol; % put tolerance in local variable
elseif ~Start.kappaTol         % test for tolerance = 0 
    solve4kappa = 0;           % do not solve for theta
end                            % end of kappa tolerance if segment
if Start.TxTol                 % test for tolerance > 0 and not []
    TxTol = Start.TxTol;       % put tolerance in local variable
elseif ~Start.TxTol            % test for tolerance = 0 
    solve4Tx = 0;              % do not solve for Tx
end                            % end of Tx tolerance if segment
if Start.TyTol                 % test for tolerance > 0 and not []
    TyTol = Start.TyTol;       % put tolerance in local variable
elseif ~Start.TyTol            % test for tolerance = 0 
    solve4Ty = 0;              % do not solve for Ty
end                            % end of Ty tolerance if segment
if Start.TzTol                 % test for tolerance > 0 and not []
    TzTol = Start.TzTol;       % put tolerance in local variable
elseif ~Start.TzTol            % test for tolerance = 0 
    solve4Tz = 0;              % do not solve for Tz
end                            % end of Tz tolerance if segment
return  % end of subfunction setSolve4andTol

function centMatch = matchIDs(centID, centCentroid)
% matches correct centroids from one array to correct IDs of another array (with only approximate centroids)
% centMatch = matchIDs(centID, centCentroid)
% centID is an N X 3 array ([pnt xpix ypix] per row) with correct IDs for approximate xpix, ypix
% centCentroid is at least an N X 3 array ([pnt xpix ypix] per row) with incorrect IDs, but correct xpix, ypix
% centMatch is an output array ([pnt xpix ypix ...] per row) with correct IDs & correct xpix, ypix
% centMatch contains all columns of centCentroid (with possibly target ID altered in column 1)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: June 22, 2009
% primary author: A. W. Burner

rowsID = size(centID,1);             % get number of rows in centID array
centMatch = [];                      % initialize output array centMatch
for i = 1 : rowsID                   % step through centID arrray
    delx = abs(centCentroid(:,2) - centID(i,2));  % absolute x distance to test
    dely = abs(centCentroid(:,3) - centID(i,3));  % absolute y distance to test
    ID2centSpacing = sqrt(delx.^2 + dely.^2);  % each column of array contains spacing from centID to centCentroid for all rows of centCentroid
    j = find(ID2centSpacing == min(ID2centSpacing));
    centMatch = [centMatch; [centID(i,1) centCentroid(j(1), 2:end)]]; % creating output array with all columns of centCentroid except column 1
end
return            % end of function






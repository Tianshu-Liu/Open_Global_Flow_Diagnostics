function xymmDist = distortApply(xymm, camDistort)

% applies distortion to image coordinates
% xymmDist = distortApply(xymm, camDistort)
% xymm is an N X 2 array without target numbers or an N X 3 array (with target numbers in column 1)
% x-value and y-value located in next-to-last and last columns respectively
% N is number of image points in xymm
% image coordinates are assumed in mm
% output xymmDist is likewise N X 3, but has distortion applied
% for xymm without target numbers, target numbers on output are sequential 1:Nrows
% camDistort is a structure with the following fields
% camDistort.xs x-value (mm) of point of symmetry for distortion (use xp if xs not known)
% camDistort.ys y-value (mm) of point of symmetry for distortion (use yp if ys not known)
% camDistort.K1 3rd order radial distortion (1/mm^2)  (K1 + for pinchusion)
% camDistort.K2 5rd order radial distortion (1/mm^4)  (set to 0 if unknown)
% camDistort.K3 7rd order radial distortion (1/mm^6)  (set to 0 if unknown)
% camDistort.P1 decentering term (1/mm)  (set to 0 if unknown)
% camDistort.P2 decentering term (1/mm)  (set to 0 if unknown)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: February 15, 2009
% primary author: A. W. Burner

xs = camDistort.xs;
ys = camDistort.ys;
K1 = camDistort.K1;
K2 = camDistort.K2;
K3 = camDistort.K3;
P1 = camDistort.P1;
P2 = camDistort.P2;

if ischar(xymm)         % test to see if xymm is a string (or string variable)
    xymm = load(xymm);  % if string load xymm array from file named from input argument xymm
end

Nrows = size(xymm,1);  % get number of rows (or centroid pairs) of input mm file
Ncols = size(xymm,2);  % get number of columns where 2 columns implies no target numbers and 3 columns implies target numbers in 1st column
xymmDist = [];         % initialize output array xymmDist
for i = 1:Nrows        % 
    xmm = xymm(i,Ncols - 1); % x-value in next to last column
    ymm = xymm(i,Ncols);     % y-value in last column
    xmmC = xmm - xs;       % subtract out x-value of point of symmetry for distortion
    ymmC = ymm - ys;       % subtract out y-value of point of symmetry for distortion
    rsqr = xmmC^2 + ymmC^2;  % square of the radius
    xmmDistK1 = K1 * xmmC * rsqr;
    ymmDistK1 = K1 * ymmC * rsqr;
    xmmDistK2 = K2 * xmmC * rsqr^2;
    ymmDistK2 = K2 * ymmC * rsqr^2;
    xmmDistK3 = K3 * xmmC * rsqr^3;
    ymmDistK3 = K3 * ymmC * rsqr^3;
    xmmDistP = P1 * (rsqr + 2 * xmmC^2) + 2 * P2 * xmmC * ymmC;
    ymmDistP = P2 * (rsqr + 2 * ymmC^2) + 2 * P1 * xmmC * ymmC;
    xmmDistSum = xmmDistK1 + xmmDistK2 + xmmDistK3 + xmmDistP;
    ymmDistSum = ymmDistK1 + ymmDistK2 + ymmDistK3 + ymmDistP;
    if Ncols == 3
        xymmDist(i,1) = xymm(i,1);    % get point numbers from column 1 of input file if 3-column input
    else
        xymmDist(i,1) = i;            % set sequential point number if only 2-column input
    end
    xymmDist(i,2) = xmm + xmmDistSum;  %  add distortion to in put x-value
    xymmDist(i,3) = ymm + ymmDistSum;  %  add distortion to in put y-value
end
return   % end of function distortApply


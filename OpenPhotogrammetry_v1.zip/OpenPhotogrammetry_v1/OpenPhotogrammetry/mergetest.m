a=load('centa.txt');
b=load('centb.txt');
% centMatch = matchIDs(a, b, 5)

centMerge = centroidMerge(a, b, 10)
save centMerge.txt centMerge -ascii -double

c=load('centc.txt');
centMerge2 = centroidMerge(centMerge, c, 10)
centMerge3 = centroidMerge(c, centMerge, 10)
save centMerge2.txt centMerge2 -ascii -double
save centMerge3.txt centMerge3 -ascii -double


function [theta, Txy, s, So] = conformal2DLLS(xin, xtrans)

% linear least squares to determine conformal transformation coefficients and
% estimates of their standard deviations for 2D coordinates
% [theta, Txy, s] = conformal2DLLS(xin, xtrans)
% the conformal transfomation is of the form below
% xt =  a * x + b * y + Tx =  s * cos(theta) * x + s * sin(theta) + Tx
% yt = -b * x + a * y + Ty = -s * sin(theta) * x + s * cos(theta) + Ty
% input xin is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% input xtrans is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% output Theta is a 1 X 2 array in which the 1st column contains the
% rotation angle in degrees, + for CW and the 
% 2nd column contains the least squares estimate of the standard deviation 
% output Txy is a 2 X 2 array in which the 1st column contains the
% x, y translations Tx, Ty and the 2nd column contains the
% least squares estimate of their standard deviations 
% s is a 1 X 2 array in which the 1st column contains the
% scale factor and the 2nd column contains the
% least squares estimate of the standard deviation 
% So is a scalar which contains the least squares standard deviation of
% unit weight

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 11, 2006
% primary author: A. W. Burner

commonNum = intersect(xin(:,1), xtrans(:,1));  % find target numbers common to both xin and xtrans
xinIndex = []; % initialize index for xin array
xtransIndex  = []; % initialize index for xtrans array
for i=1:length(commonNum)  % step through common set of target numbers found above
    xinIndex    = [xinIndex;     find(xin(:,1)    == commonNum(i))];  % create index of xin containing common target numbers
    xtransIndex = [xtransIndex;  find(xtrans(:,1) == commonNum(i))];  % create index of xtrans containing common target numbers
end
xin    = xin(xinIndex, :);       % redefine xin with common target numbers only
xtrans = xtrans(xtransIndex, :); % redefine xtrans(:,1) with common target numbers only

Nrows = size(xin, 1);  % find number of rows (number of target point numbers) of the redefined xin (and xtrans)
A = [];   % initialize the array A that represents the right hand side of the conformal transformation
L = [];   % initialize the column vector L which represents the left hand side of the conformal transformation
for i = 1: Nrows      % step through each coordinate pair of the redefined xin (and xtrans) 
    x = xin(i,2);     % create x as a scalar containing the x-value of a coordinate pair from xin
    y = xin(i,3);     % create y as a scalar containing the y-value of a coordinate pair from xin
    xt = xtrans(i,2); % create xt as a scalar containing the x-value of a coordinate pair from xtrans
    yt = xtrans(i,3); % create yt as a scalar containing the y-value of a coordinate pair from xtrans
    j = 2*i - 1;      % j is intermediate index 1:2:2 * Nrows - 1 since there will 2 equations for each coordinate pair (each i)
    L(j)   = xt;      % populate L matrix (left hand side of trans) for x-equation
    L(j+1) = yt;      % populate L matrix (left hand side of trans) for y-equation      
    A(j,1) = x;       % populate A matrix (right hand side of trans), a term
    A(j,2) = y;       % j index is for the x-equation of the transformation, b term
    A(j,3) = 1;       % Tx term
    A(j,4) = 0;       % Ty term = 0 for x-equation
    A(j+1,1) = y;     % a term for y-equation (j+1 index)
    A(j+1,2) = -x;    % b term
    A(j+1,3) = 0;     % Tx term = 0 for y-equation
    A(j+1,4) = 1;     % Ty term
end                   % end of loop stepping through coordinate pairs
L = L';               % make L a column vector for matrix math next line
X = A\L;              % MATLAB least squares solution column vector
a = X(1);             % put solutions into common variable names
b = X(2);             % put solutions into common variable names
Tx = X(3);            % put solutions into common variable names
Ty = X(4);            % put solutions into common variable names
s = sqrt(a^2 + b^2);  % compute scale
theta = atan2(b, a) * 180 / pi; % compute thetax and convert to degrees
Txy = [Tx; Ty];             % create output column array for translation values
df = (size(A, 1) - length(X)); % compute degrees of freedom = number of equations - number of unknowns
V = A * X  - L;                % compute residuals
So = sqrt(V' * V / df);        % compute standard deviation of unit weight
covar = inv(A' * A);           % compute covariance matrix
stdX = So * sqrt(diag(covar)); % standard deviation estimates = square root of diagonals of covariance X So
stda = stdX(1);                % put standard deviation in common name variable
stdb = stdX(2);                % put standard deviation in common name variable
stdTx = stdX(3);               % put standard deviation in common name variable
stdTy = stdX(4);               % put standard deviation in common name variable
stds = sqrt(((a * stda)^2 + (b * stdb)^2) / (a^2 + b^2)); % error propagation for std of s
stdtheta = (sqrt(((a * stdb)^2 + (b * stda)^2)) / (a^2 + b^2)) *180 / pi; % error propagation for std of theta
theta = [theta stdtheta];      % append 2nd column to theta containing standard deviation
Txy = [Txy [stdTx; stdTy]];    % append 2nd column to Txy containing standard deviations
s = [s stds];                  % append 2nd column to Sxy containing standard deviations
return                         % end of function

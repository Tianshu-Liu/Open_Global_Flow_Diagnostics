function m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll, AngleUnits)

% 3 X 3 rotation matrix (Azimuth, Elevation, Roll)
% m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll, AngleUnits)
% with only 3 input arguments; if 4th optional argument AngleUnits =
% 'radians'(exactly)then 3 input angles are assumed to be in radians
% (if AngleUnits anything other than 'radians' then degrees are assumed)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

n = nargin;   % determine number of input arguments
if n < 3     % test for 3 input arguments and exit function if not = 3
    disp '3 (or 4) arguments are necessary to invoke function m = rotationMatrixAzElevRoll(Azimtuh, Elevation, Roll, AngleUnits)'
    disp 'Type ''help rotationMatrixAzElevRoll'' to see argument definitions'
    return
else
    if n == 4 && size(AngleUnits,2) == 7 && strcmp(AngleUnits, 'radians')
        A = Azimuth;   % angles already in radians so no conversion necessary
        E = Elevation;
        R = Roll;
    else
        A = Azimuth * pi / 180;  % convert angles from degrees to radians
        E = Elevation * pi / 180;
        R = Roll * pi / 180;
    end
    m = [];   % initialize output array m
    m(1,1) = sin(A) * sin(E) * sin(R) + cos(A) * cos(R);
    m(1,2) = -cos(A) * sin(E) * sin(R) + sin(A) * cos(R);
    m(1,3) = cos(E) * sin(R);
    m(2,1) = sin(A) * sin(E) * cos(R) - cos(A) * sin(R);
    m(2,2) =  -cos(A) * sin(E) * cos(R) - sin(A) * sin(R);
    m(2,3) = cos(E) * cos(R);
    m(3,1) =  sin(A) * cos(E);
    m(3,2) = -cos(A) * cos(E);
    m(3,3) = -sin(E);
end
return



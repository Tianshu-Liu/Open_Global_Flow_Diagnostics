function XYZErr = errorAddXYZ(XYZ, Xsig, Ysig, Zsig, Xbias, Ybias, Zbias)

% adds normally distributed random error (1 sigma) to object coodinates
% XYZErr = errorAddXYZ(XYZ, Xsig, Ysig, Zsig, Xbias, Ybias, Zbias)
% XYZ is either N X 3 or N X 4 (error is added to last 3 columns)

XYZErr = XYZ;
XYZErr(:, end - 2) = XYZ(:, end - 2) + Xsig * randn(size(XYZ,1), 1) + Xbias;   % add X-error to 2nd from last column
XYZErr(:, end - 1) = XYZ(:, end - 1) + Ysig * randn(size(XYZ,1), 1) + Ybias;   % add Y-error to next to last column
XYZErr(:, end)     = XYZ(:, end)     + Zsig * randn(size(XYZ,1), 1) + Zbias;   % add Z-error to last column

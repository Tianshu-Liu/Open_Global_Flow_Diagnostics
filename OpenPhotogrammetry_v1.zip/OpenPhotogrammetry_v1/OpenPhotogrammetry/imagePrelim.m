function varargout = imagePrelim(varargin)

% GUI for preliminary target locations
% imagePrelim M-file for imagePrelim.fig
% Last Modified by GUIDE v2.5 21-Jan-2007 16:19:23

% ----------------GUI elements listing-------------
% pushbutton1    "get image file"
% edit1          "numtargs"
% text1          "targets found"
% text2          "relative threshold"
% slider1        "threshold"
% edit2          "threshold"
% text11         "minimum size"
% slider10       "min size"
% edit11         "min size"
% text12         "maximum size"
% slider11       "max size"
% edit12         "max size"
% togglebutton1  "invert grayscale on input"
% edit13         "file name"
% text13         "file name"
% pushbutton3    "roi poly select"
% pushbutton4    "show target IDs & save"
% togglebutton2  "show binary image w. o. processing"
% uipanel1       "overlay centroid file"
  % text15       "bounding box W/2 & H/2 ="
  % edit14       "W/2 & H/2"
  % pushbutton6  "select file"
  % popupmenu2   "plot color"
  % text16        "overlay plot color ="
% uipanel2       "manual selection of targets"
  % pushbutton5  "manually select targets & save"
% uipanel3       "match target IDs to centroids & save"
  % pushbutton7  "select input & ouput files"
  % text17       "match tolerance ="
  % edit15       "match tolerance value"
% panel14        "grayscale centroids & save"
  % pushbutton8  "select input & ouput files"
  % text18       "add to bounding boxes ="
  % edit16       "addition to bounding boxes value"
% uipanel5       "thresh/size inputs"
  % radiobutton1 "sliders"
  % radiobutton2 "edit boxes"
  % pushbutton9  "process"
%----------end of GUI element listing---------------
  
% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: January 28s, 2007
% primary author: A. W. Burner

% Begin initialization code - DO NOT EDIT (from Guide)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @imagePrelim_OpeningFcn, ...
                   'gui_OutputFcn',  @imagePrelim_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before imagePrelim is made visible.
function imagePrelim_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to imagePrelim (see VARARGIN)

% Choose default command line output for imagePrelim
% set some initial values on GUI startup
global I
clear global I   % clear global image variable I on startup to prevent use of leftover variable
handles.output = hObject;
set(handles.edit14, 'String', num2str(10))  % default bounding box half-width & half-height for overlay centroid file pushbutton
% set(handles.edit15, 'String', num2str(10))  % default match tolerance for 'match targetIDs to centroids' panel
set(handles.edit16, 'String', num2str(3))   % default bounding box half-width & half-height for grayscale centroids
set(handles.radiobutton1, 'Value', 1)       % default bounding box half-width & half-height for grayscale centroids

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes imagePrelim wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = imagePrelim_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%-------------------get image file--------------------------
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I
set(handles.togglebutton2, 'value', 0)  % turn off 'show binary image w. o. processing" toggle button
[fileName userCancel] = imgetfile;      % get file name (or cancel state) from file input dialog box
if ~userCancel             % if get file not canceled by user then do next segment
    I = imread(fileName);  % input the image file into variable I
    [pathstr, name, ext, versn] = fileparts(fileName);  % get the various parts of the filename input above
    set(handles.edit13, 'String', [name ext])           % put the file name in edit box 13
    if get(handles.togglebutton1, 'Value')              % test for 'invert grayscale on input' toggle on
        I = imcomplement(I);                            % if toggle on then invert grayscale
    end                                                 % end of 'invert test loop'
    hold off                                            % cancel hold on figure
    imshow(I, [])                                           % show image I in figure window of GUI
    if get(handles.radiobutton1, 'Value')  % execute only if 'sliders' radiobutton is on
        threshold = graythresh(I);                          % compute overall 'best' threshold for converting to binary
        data = imageProcess(I, threshold);                  % get binary centroids, bounding boxes, and eccentricity using regionprops (see imageProcess below)
        plotData(data)                                      % subfunction below to plot bounding boxes on image
        setHandles(data, handles, threshold)                % subfunction below to set handles
    else
        set(handles.edit11, 'String', '1');                   % set minimum size to 1
        set(handles.edit12, 'String', num2str(max(size(I)))); % set maximum size to max of width of height of image
    end                                                       % end of sliders radiobutton on-off test
end                                                           % end of user cancel test

%-------------num targs------------------------------------------
function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%--------------relative threshold-----------------------------------------
% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global I
threshold = get(handles.slider1, 'Value');       % get threshold from slider1 relative position
set(handles.edit2, 'String', num2str(threshold)) % put slider value in edit box 2
if size(I)   % execute 1st part of segment if the global image I has some size (has been loaded)
    if ~get(handles.togglebutton2, 'Value')  % do next segment if togglebutton2 is off & radiobutton1 is on
        hold off                                     % turn figure hold off
        imshow(I, [])                                    % show image in GUI figure window
        if get(handles.radiobutton1, 'Value')  % do next segment if radiobutton1 is on
            data = imageProcess(I, threshold);           % get binary centroids, bounding boxes, and eccentricity using regionprops (see imageProcess below)
            plotData(data);                              % subfunction to plot bounding boxes on image
            numTargs = size(data,1);                     % determine number of targets for next line test
            if numTargs > 0                              % if 1 or more targets found then do this segment
                setHandles(data, handles, threshold)     % subfunction setHandles populates the handles
            end                                          % end of numTargs > 0 segment
        end
    else                                             % do this segment if togglebutton2 (show binary image w. o. processing) in on
        bw = im2bw(I, threshold);                    % create binary image from image I using currect value of threshold
        imshow(bw)                                   % show binary image in figure window
    end                                              % end of binary iamge show
else                                                 % if size(I) = 0 (no image loaded)then beep and display message
    beep
    disp('image file must be loaded first')
end                                                  % end of 'size(I)' if statement
% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

%-------------threshold------------------------------------
function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function data = imageProcess(I, threshold)  % subfunction to do main processing with regionprops
bw = im2bw(I, threshold);                   % create binary image from I using current threshold
L = bwlabel(bw);                            % create label image from binary image
s = regionprops(L, 'Centroid', 'BoundingBox', 'Eccentricity');  % get structure from label image L with centroid, bounding box, and eccentricity
centroids = cat(1, s.Centroid);             % extract 2 column array of centroids from structure field
boundingBoxes = cat(1, s.BoundingBox);      % extract 4 column array of bounding box demensions from structure field
eccentricities = cat(1, s.Eccentricity);    % extract 1 column array of eccentricity from structure field
data = [centroids boundingBoxes eccentricities];  % combine above 3 arrays into an N X 7 array (N = number of targets)
save data data                              % save the N X 7 array 'data' has the 'mat' file 'data.mat' in current directory for later use

function plotData(data)   % subfunction to plot centroid bounding boxes and IDs on image
hold on
numTargs = size(data,1); % number of targets is numbe of rows of data array 
for i = 1: numTargs      % step through each row of data
    x =[data(i,3),...    % x is vector of x-locations of bounding box
        data(i,3) + data(i,5),...
        data(i,3) + data(i,5),...
        data(i,3),...
        data(i,3)];
    y =[data(i,4),...    % y is vector of y-locations of bounding box
        data(i,4),...
        data(i,4) + data(i,6),...
        data(i,4) + data(i,6),...
        data(i,4)];
    plot(x, y, 'g')     % plot boxes in green
    if data(i,5) < 4 | data(i,6) < 4   % test for small targets that might be missed if plot not emphasized with +
        plot(data(i,1), data(i,2), 'g+','MarkerSize',10)
    end
end    % end of plotData subfunction

function setHandles(data, handles, threshold)  % subfunction to set sliders and edit boxes with inof from data array
numTargs = size(data,1);                       % number of targets is number of rows of data array
minWidth = min(data(:,5));                     % find min bounding box width
maxWidth = max(data(:,5));                     % find max bounding box width
minHeight = min(data(:,6));                    % find min bounding box height
maxHeight = max(data(:,6));                    % find max bounding box height
minSize = min([minWidth minHeight]);           % min size is taken to be the least of min width or min height
maxSize = max([maxWidth maxHeight]);           % max size is taken to be the greatest of max width or max height        
set(handles.edit1, 'String', num2str(numTargs))      
set(handles.slider1, 'Value', threshold)
set(handles.edit2, 'String', num2str(threshold))
set(handles.slider10, 'Value', 0)                    % default 'min size' relative slider position is far left (0)
set(handles.slider10, 'SliderStep', [1/maxSize 0.1]) % slider motion in 0.1 of max size
set(handles.edit11, 'String', num2str(minSize))
set(handles.slider11, 'Value', 1)                    % default 'max size' relative slider position is far right (1)
set(handles.slider11, 'SliderStep', [1/maxSize 0.1]) % slider motion in 0.1 of max size
set(handles.edit12, 'String', num2str(maxSize))

%----------------minimum size-----------------------------------
% --- Executes on slider movement.
function slider10_Callback(hObject, eventdata, handles)
% hObject    handle to slider10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global I   % declare gobal so this function can access image array I
if get(handles.radiobutton1, 'Value')  % execute only if 'sliders' radiobutton is on
    if size(I)                         % test to see if image array I has been loaded
        if ~get(handles.togglebutton2, 'Value')        % do this segment if the show binary image toggle is off
            threshold = get(handles.slider1, 'Value'); % get threshold from slider1 
            I = getimage;                              % get current image
            hold off                                   % clear hold for plotting data on image
            imshow(I, [])                                  % show image
            data = imageProcess(I, threshold);         % process
            minWidth = min(data(:,5));                 % minimum width from the min of column 5
            maxWidth = max(data(:,5));                 % maximum width from the max of column 5
            minHeight = min(data(:,6));                % minimum height from the min of column 6
            maxHeight = max(data(:,6));                % maximum height from the max of column 6
            minSize = min([minWidth minHeight]);       % minimum size from the least of width or height
            maxSize = max([maxWidth maxHeight]);       % maximum size from the greated of width or height
            Fract = get(handles.slider10, 'Value');    % get fraction of 'min size' slider relative position
            minSizeNew = round(minSize + Fract * (maxSize - minSize)); % determine the new minimum size to put in the edit box
            set(handles.edit11, 'String', num2str(minSizeNew));        % put new minimum size in the edit box (11)
            maxSizeNew = str2double(get(handles.edit12, 'String'));    % get max size set in edit box 12
            index = find(data(:,5) >= minSizeNew & data(:,5) <= maxSizeNew...  % find bounding boxes within min % max size (columns 5 & 6)
                & data(:,6) >= minSizeNew & data(:,6) <= maxSizeNew);
            data = data(index, :);                            % only keep data within size restrictions
            save data data                                    % save array data as data.mat                  
            numTargs = size(data,1);                          % compute number of targets (number of rows) in redefined data array
            plotData(data);                                   % plot bounding boxes on image
            set(handles.edit1, 'String', num2str(numTargs))   % set number of targets in edit box 1
        end                                                   % end of show binary image off segment 
    else                                                      % if show binary image on then do next segment
        beep
        disp('image file must be loaded first')
    end                                                       % end of show binary image test
end                                                           % end of 'sliders' on test
% --- Executes during object creation, after setting all properties.
function slider10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

%-----------------min size--------------------------------------
function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double
% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%----------------------maximum size---------------------------------
% --- Executes on slider movement.
function slider11_Callback(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global I   % declare gobal so this function can access image array I
if get(handles.radiobutton1, 'Value')  % execute only if 'sliders' radiobutton is on
    if size(I)                         % test to see if image array I has been loaded
        if ~get(handles.togglebutton2, 'Value')        % do this segment if the show binary image toggle is off
            threshold = get(handles.slider1, 'Value'); % get threshold from slider1 
            I = getimage;                              % get current image
            hold off                                   % clear hold for plotting data on image
            imshow(I, [])                                  % show image
            data = imageProcess(I, threshold);         % process
            minWidth = min(data(:,5));                 % minimum width from the min of column 5
            maxWidth = max(data(:,5));                 % maximum width from the max of column 5
            minHeight = min(data(:,6));                % minimum height from the min of column 6
            maxHeight = max(data(:,6));                % maximum height from the max of column 6
            minSize = min([minWidth minHeight]);       % minimum size from the least of width or height
            maxSize = max([maxWidth maxHeight]);       % maximum size from the greated of width or height
            Fract = get(handles.slider11, 'Value');    % get fraction of 'max size' slider relative position
            maxSizeNew = round(minSize + Fract * (maxSize - minSize)); % determine the new maximum size to put in the edit box
            set(handles.edit12, 'String', num2str(maxSizeNew));        % put new minimum size in the edit box (12)
            minSizeNew = str2double(get(handles.edit11, 'String'));    % get mIN size set in edit box 11
            index = find(data(:,5) >= minSizeNew & data(:,5) <= maxSizeNew...  % find bounding boxes within min % max size (columns 5 & 6)
                & data(:,6) >= minSizeNew & data(:,6) <= maxSizeNew);
            data = data(index, :);                            % only keep data within size restrictions
            save data data                                    % save array data as data.mat                  
            numTargs = size(data,1);                          % compute number of targets (number of rows) in redefined data array
            plotData(data);                                   % plot bounding boxes on image
            set(handles.edit1, 'String', num2str(numTargs))   % set number of targets in edit box 1
        end                                                   % end of show binary image off segment 
    else                                                      % if show binary image on then do next segment
        beep
        disp('image file must be loaded first')
    end                                                       % end of show binary image test
end                                                           % end of 'sliders' on test
% --- Executes during object creation, after setting all properties.
function slider11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

%----------------max size----------------------------------
function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double
% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%-------------------invert grayscale on input---------------------------------
% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of togglebutton1
% state = get(hObject,'Value')


function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double

%------------------------------file name-------------------------
% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%------roi poly select-----------------------------------
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I     % declare global so image array I can be accessed with this pushbutton function
if size(I)   % do segment if image array I has been loaded
    if ~get(handles.togglebutton2, 'Value')  % test for 'show binary image w. o. processing' toggle off
        Iout = roiPolySelect(I);             % invoke function roiPolySlect to get polynomila region of image to keep
        I = Iout;                            % redefine image array same as Iout (polynomial region)
        close(gcf)                           % close figure
        close(gcf)                           % close figure 2nd time due to roiPolySelect function
        hold off                             % clear hold for plotting
        imshow(Iout, [])                         % display polynomial region of image
        threshold = graythresh(Iout);        % get default threshold of image
        data = imageProcess(Iout, threshold); % process
        plotData(data);                       % plot target bounding boxes
        numTargs = size(data,1);              % determine number of targets from number of rows in array data
        set(handles.edit1, 'String', num2str(numTargs)) % put number of targets in edit box 1
        if numTargs > 0                                 % do subfunction sethandles if any targets found
            setHandles(data, handles, threshold)
        end                                             % end of test for targets found
    end                                                 % end of test for binary image show toggle
else                                                    % if image array I no loaded yet
    beep
    disp('image file must be loaded first')
end                                                     % end of test for existance of image array I 

%-----------show target IDs & save------------------
% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I     % declare global so image array I can be accessed with this pushbutton function
if size(I)   % do segment if image array I has been loaded
    if ~get(handles.togglebutton2, 'Value')  % test for 'show binary image w. o. processing' toggle off
        load data                            % create array data from data.mat (saved earlier)
        overlayCentroidsBox([[1:size(data,1)]' data(:,1:2)], data(:,5) / 2, data(:,6) / 2) % invoke function to overlay array
        pause(.01)                           % needed to see ouput from pixelXYselect before opening file dialog box
        [file path] = uiputfile('*.*');      % file dialog box for output filename
        if file                              % check for existance of name
            filename = [path file];          % append path to filename
            fid = fopen(filename, 'wt');     % open output file for writing in text mode with file ID fid
            fprintf(fid, '%6d %5.4f %5.4f %4d %4d\n', [[1:size(data,1)]' data(:,1) data(:,2) round(data(:,5) / 2) round(data(:,6) / 2)]');
            fclose(fid);                     % close output file
        end                                  % end of filename existance test
    end                                      % end of test for binary image display toggle on
else                                         % do this segment if image array I not loaded yet  
    beep
    disp('image file must be loaded first')
end                                          % end of pushbutton4

%-----------show binary image w. o. processing--------------------------------
% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of togglebutton2
global I     % declare global so image array I can be accessed with this pushbutton function
if size(I)   % do segment if image array I has been loaded
    if get(handles.togglebutton2, 'Value')         % if button pushed then do this segment
        % threshold = get(handles.slider1, 'Value') % get value from threshold slider 
        threshold = str2num(get(handles.edit2, 'String')); % put slider value in edit box 2
        bw = im2bw(I, threshold);                  % convert to binary using threshold slider value
        imshow(bw)                                 % display binary image
    else                                           % if button off then display grayscale image
        imshow(I, [])
    end                                            % end of togglebutton2 on-off test
else                                               % do this segment if image array I not loaded yet  
    beep
    disp('image file must be loaded first')
end                                                % end of togglebutton2

%----------manually select targets & save-------------------
% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I     % to avoid plotting on blank screen
if size(I)   % do segment if image array I has been loaded
    pixelXYselect('FileName', 'centMan.txt', 'FileMode', 'w', 'PrintOut', 0); % invoke function for manual selection of targets
    pause(0.01)                                                               % needed to see ouput from pixelXYselect before opening file dialog box
    [file path] = uiputfile('', 'enter file to save manual IDs');             % file dialog box to select output filename
    if ~isequal(file,0) || ~isequal(path,0)                                   % test for file & path not equal 0                           
        filename = [path file];                                               % append path to file name  
        copyfile('centMan.txt', filename);                                    % copy output file from pixelXYselct (centMan.txt) to filename
    end                                                                       % end of test for file & path not equal 0
else                                                                          % do this segment if image array I not loaded yet                                                                           
    beep
    disp('image file must be loaded first')
end                                                                           % end of pushbutton5

%--------------select file (overlay centroid file)-------------------
% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I     % to avoid plotting on blank screen
if size(I)   % do segment if image array I has been loaded
    [file path] = uigetfile('*.*', 'select centroid file to overlay'); % file dialog box to select file to be overlaid
    if ~isequal(file,0) || ~isequal(path,0)                            % test for file & path not equal 0
        filename = [path file];                                        % append path to file name
        cent = load(filename);                                         % create array cent from file filename
        contents = get(handles.popupmenu2,'String');                   % get contents (cell array) of popup menu for plot colors
        plotColor = contents{get(handles.popupmenu2,'Value')};         % get plot color from popup menu contents cell array
        if size(cent,2) > 4                                            % do segment if more than 4 columns
            overlayCentroidsBox(cent(:,1:3), cent(:,4), cent(:,5), plotColor)  % get delx and dely from columns 4 & 5
        elseif size(cent,2) == 3                                       % if only 3 columns take delx and dely from 'bounding box W/2 & H/2 =' edit box
            del = str2num(get(handles.edit14, 'String'));              % get values from edit box (14)
            overlayCentroidsBox(cent, del, del, plotColor)             % invoke function to overlay centroid data on image
        end                                                            % end of number of columns test
    end                                                                % end of file & path existance test
else                                                                   % do this segment if image array I not loaded yet
    beep
    disp('image file must be loaded first')
end                                                                    % end of pushbutton6

%--------------bounding box width/2 & height/2 (overlay centroid file)-------------------
function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double

% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%--------------plot color popup (overlay centroid file)-------------------
% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = get(hObject,'String') returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%----------------------select input & output files (match target IDs to centroids & save)----------------
% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file path] = uigetfile('*.*', 'correct target IDs, but approx centroids'); % select file containing correct target IDs
if ~isequal(file,0) || ~isequal(path,0)                                     % test for file and path not equal 0
    filename = [path file];                                                 % append path to filename
    centID = load(filename);                                                % create centID array from file filename
    [file path] = uigetfile('*.*', 'incorrect target IDs, but valid centroids'); % select file containing correct centroids, but incorrect IDs
    if ~isequal(file,0) || ~isequal(path,0)                                 % test for file and path not equal 0
        filename = [path file];                                             % append path to filename
        centCentroid = load(filename);                                      % create centcentroid array from file filename
        % tol = str2num(get(handles.edit15, 'String'));                       % match tolerance 
        centMatch = matchIDs(centID, centCentroid);                    % use function matchIDs to perform match
        [file path] = uiputfile('*.*', 'correct target IDs with valid centroids'); % select filename for output of matched file
        if ~isequal(file,0) || ~isequal(path,0)                             % test for file and path not equal 0
            filename = [path file];                                         % append path to filename
            fid = fopen(filename, 'wt');                                    % open output file for writing in text mode
            for i = 1:size(centMatch,1)                                     % step through each row of array centMatch
                fprintf(fid, '%g ', centMatch(i,:)');                       % write each row in 'most compact' format (%g)
                fprintf(fid,'\n');                                          % write new line after each row
            end                                                             % end of file write loop
            fclose(fid);                                                    % close ouput file
        end                                                                 % end of output file & path exist test
    end                                                                     % end of incorrect ID file & path test
end                                                                         % end of correct ID file & path test

%--------match tolerance edit box (match target IDs to centroids & save)----------------
function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double
% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%----------------select input & output files (grayscale centroids & save)----------------
% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I    % declare global so image array I can be accessed with this pushbutton function
if size(I)  % test for existance of image array I
    [file path] = uigetfile('*.*', 'start approx centroids'); % use file dialog box to get input (approximate) centroid file
    if ~isequal(file,0) || ~isequal(path,0)                   % if either filename or path not set to 0 test
        filename = [path file];                               % append path to filename
        centStart = load(filename);                           % create array centStart from file filename
        if size(centStart,2) < 5                              % test for less than 5 columns (no bounding boxes input)
            beep                                              
            disp(['centroid start file ' file ' does not have enough columns (min is 5) iwth columns 4, 5 = delx, dely bounding box half-width (oo height)'])
            return                                            % exit pushbutton function if delx, dely columns not present        
        end                                                   % end of 'no bounding box columns' test
        [file path] = uiputfile('*.*', 'grayscale centroid output file'); % use file dialog box to selecy ouput centroid filename and path
        if ~isequal(file,0) || ~isequal(path,0)                    % if either filename or path not set to 0 test
            filename = [path file];                                % append path to filename
            delAdd = str2num(get(handles.edit16, 'String'));       % from 'add to bounding boxes =' edit box
            Nrows = size(centStart,1);                             % get number of rows of array centStart
            centGray = [];                                         % initialize output array centGray
            for i = 1 : Nrows                                      % step through each row of array centStart
                x = centStart(i, 2);                               % xstart from 2nd column
                y = centStart(i, 3);                               % ystart from 3rd column 
                delx = centStart(i, 4) + delAdd;                   % half-width of bounding box from 4th column  
                dely = centStart(i, 5) + delAdd;                   % half-height of bounding box from 5th column  
                if x - delx < 1; delx = x - 1; end                 % to avoid trying to access grayscale less than x = 1
                if x + delx > size(I,2); delx = size(I,2) - x; end % to avoid trying to access grayscale greater than x = xmax
                if y - dely < 1; dely = y - 1; end                 % to avoid trying to access grayscale lass than y = 1
                if y + dely > size(I,1); dely = size(I,1) - y; end % to avoid trying to access grayscale greater than y = ymax
                Gback = findBackground(I, x, y, delx, dely);       % find max grayscale on perimeter x-delx, x+delx, y-dely, y+dely
                xy = centroid(I, x, y, delx, dely, Gback);         % 2-column vector output xy with grayscale centroid at nominal x, y
                centGray = [centGray; centStart(i,1) xy delx dely centStart(i,6:end)];  % columns [2 3 4 5] replaced with [xy delx dely]
            end                                      % end of step through each nominal x, y location to compute grayscale centroids
            fid = fopen(filename, 'wt');             % open file selected as output file for write in text mode with file ID fid
            for i = 1:size(centGray,1)               % write out 1 line for each row of centGray array
                fprintf(fid, '%g ', centGray(i,:)'); % write row in 'most compact' format (%g)
                fprintf(fid,'\n');                   % new line after every row
            end                                      % end of step through each row of centGray array
            fclose(fid);                             % close ouput file
        end                                          % end of segment testing for valid filename and path for output file
    end                                              % end of segment testing for valid filename and path for input file
else                                                 % if size(I) = 0, indicating that an image file has not yet been loaded
    beep
    disp('image file must be loaded first')
end                                                  % end of size(I) test segment

%-----------------text box for 'add to bounding boxes' value---------------------
function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double
% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%---------------sliders----------------------------
% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of radiobutton1
if get(handles.radiobutton1, 'Value')     % turn radiobutton2 (edit boxes) off (next line) if 1 (sliders) is turned on
    set(handles.radiobutton2, 'Value', 0)
else                                      % do next line if radiobutton1 off
    set(handles.radiobutton2, 'Value', 1) % turn radiobutton2 (edit boxes) on if 1 (sliders) is turned off
end                                       % end of radiobutton1 on-off test    

%---------------edit boxes-----------------------------
% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of radiobutton2
if get(handles.radiobutton2, 'Value')     % turn radiobutton1 (sliders) off if 2 (edit boxes) is turned on
    set(handles.radiobutton1, 'Value', 0)
else                                      % do next line if radiobutton2 off
    set(handles.radiobutton1, 'Value', 1) % turn radiobutton1 (sliders) on if 2 (edit boxes) is turned off
end                                       % end of radiobutton2 on-off test   

%----------process-----------------------
% --- Executes on button press in pushbutton9 
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I
if get(handles.radiobutton2, 'Value')  % execute only if 'edit boxes' radiobutton is on
    if size(I)   % do next segment only if image has been loaded (size > 0)
        if ~get(handles.togglebutton2, 'Value')  % execute next segment only if 'show binary image w. o. processing' toggle is off
            threshold = str2double(get(handles.edit2, 'string')); % threshold value from edit box (string is converted to double)
            hold off
            imshow(I, [])                                                % show image
            data = imageProcess(I, threshold);                       % main data processing subfunction
            minSizeNew = str2double(get(handles.edit11, 'string'));  % edit box below min size slider
            maxSizeNew = str2double(get(handles.edit12, 'string'));  % edit box below max size slider
            index = find(data(:,5) >= minSizeNew & data(:,5) <= maxSizeNew...    % find centroids within size contstraints
                       & data(:,6) >= minSizeNew & data(:,6) <= maxSizeNew);
            data = data(index, :);                                   % redefine data array with only data within size constraint
            save data data                                           % save array data as 'data.mat' for later recall
            numTargs = size(data,1);                                 % number of targets is the number of rows in the array data
            plotData(data);                                          % subfunction to display centroids on image
            set(handles.edit1, 'String', num2str(numTargs))          % put number of targets in edit box below 'targets found' tag
        end                                                          % end of main processing segment
    else                                                             % if size(I) = 0 beep and then display message to command window
        beep
        disp('image file must be loaded first')
    end    % end of size(I) segment
end        % end of radiobutton test
%---------------------------end of GUI function----------------------------------------

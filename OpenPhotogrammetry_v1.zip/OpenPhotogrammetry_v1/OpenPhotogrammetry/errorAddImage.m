function xymmErr = errorAddImage(xymm, xsig, ysig, xbias, ybias)

% adds normally distributed random error (1 sigma) to image coodinates
% xymmErr = errorAddImage(xymm, xsig, ysig, xbias, ybias)
% xymm is either N X 2 or N X 3 (error is added to last 2 columns)

xymmErr = xymm;
xymmErr(:, end-1) = xymm(:, end-1) + xsig * randn(size(xymm,1), 1) + xbias;   % add x-error to next to last column
xymmErr(:, end)   = xymm(:, end)   + ysig * randn(size(xymm,1), 1) + ybias;   % add y-error to last column

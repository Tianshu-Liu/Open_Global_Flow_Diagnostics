function centMerge = centroidMerge(centA, centB, tol)
% merges 2 centroid arrays with the same number of columns into a single centroid array
% centMerge = centroidMerge(centA, centB, tol)
% centA and centB typically have at least 3 columns ([pnt xpix ypix ...] per row)
% pixel locations within the pixel match tolerance (tol) of each array are given the target ID of centA
% any targets not matching from array centB are appended with new target IDs starting at the max ID
% of array centA and incremented by 1
% tol is tolerance for closeness of the match for agreement of the 2 sets of centroids in pixels
% centMerge is an output array ([pnt xpix ypix ...] per row) with same number of columns as centA and centB

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: February 5, 2007
% primary author: A. W. Burner

rowsA = size(centA,1); % get number of rows in centA array
rowsB = size(centB,1); % get number of rows in centB array
kDup = [];                          % initialize duplicate k variable 'kDup'
for i = 1 : rowsA                   % step through centA arrray
    for k = 1 : rowsB               % step through centB array
        if abs(centB(k,2) - centA(i,2)) < tol && abs(centB(k,3) - centA(i,3)) < tol  % test for xy centroids within tolerance (match)
            kDup = [kDup; k];       % create array of indices of centB array whose centroid location matches centA (within tol)
            break  % exit k for loop if match found
        end        % end of match test
    end            % end of step though centB
end                % end of step though centA
kDup = sort(kDup); % put kDup in ascending order
centB = setxor(centB, centB(kDup,:),'rows');      % redefine centB array to be only targets not matched above
pntStartB = max(centA(:,1)) + 1;                  % start target ID for appended data from centB
pntB = pntStartB : pntStartB + size(centB,1) - 1; % target IDs for appended portion of centB
centB(:,1) = pntB';                               % put target IDs in column 1 as a column vector
centMerge=[centA; centB];                         % append portion of centB (with new IDs) to original centA
return                                            % end of function


function [dxp,exterior]=resec3(epsilon,interior,exterior,format,xyimagd,xyimagu,xyzobj)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% linear least squares for omega,phi,kappa given other parameters
% This program is used in 'dlt.m'.
%
% Inputs: (1) epsilon, a small number for controling iteration
%         (2) exterior, the exterior orientation parameters, (omega,phi,kappa,Xc,Yc,Zc)
%         (3) interior, the interior orientation parameters, (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (4) format, the camera format file, 
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%         (5) xyimagd, distorted image coordinates (x,y), in pixels
%         (6) xyimagu, undistorted image coordinates (x,y), in pixels
%         (7) xyzobj, the object space coordinates (X,Y,Z), in inches
%
% Outputs: (1) dx, the residual of least squares estimation for targets in the image plane
%          (2) exterior, the exterior orientation parameters
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

angles=exterior(1:3);
XYZc=exterior(4:6);
h=0.001*ones(3,1);

[dx,xxp]=lleast3(angles,XYZc,interior,format,xyimagd,xyimagu,xyzobj);
var=norm(dx);
k=1;
if var>=epsilon
  while norm(var)>epsilon
       [dx0,xxp]=lleast3(angles,XYZc,interior,format,xyimagd,xyimagu,xyzobj);
       [dx2,xxp]=lleast3(angles+h,XYZc,interior,format,xyimagd,xyimagu,xyzobj);
       [dx1,xxp]=lleast3(angles-h,XYZc,interior,format,xyimagd,xyimagu,xyzobj);
       itera=(2*dx0.*h)./(dx2-dx1);
       angles=angles-itera;
     [dx,xxp]=lleast3(angles,XYZc,interior,format,xyimagd,xyimagu,xyzobj);
     var=norm(dx);
     k=k+1;
     if (k>=20)  
     break;
     end
  end  
end
exterior=[angles;XYZc];
dxp=std(xxp);


  
     
     
     
function xymmCorr = distortCorrect(xymmDist, camDistort)

% corrects image coordinates for distortion
% xymmCorr = distortCorrect(xymmDist, camDistort)
% xymmDist is an N X 2 array without target numbers or an N X 3 array (with target numbers in column 1)
% x-value and y-value located in next-to-last and last columns respectively
% N is number of image points in xymmDist
% image coordinates are assumed in mm
% output xymmCorr is N X 3, but has distortion removed
% for xymmDist without target numbers, target numbers on output are sequential 1:Nrows
% camDistort is a structure with the following fields
% camDistort.xs x-value (mm) of point of symmetry for distortion (use xp if xs not known)
% camDistort.ys y-value (mm) of point of symmetry for distortion (use yp if ys not known)
% camDistort.K1 3rd order radial distortion (1/mm^2)  (K1 + for pinchusion)
% camDistort.K2 5rd order radial distortion (1/mm^4)  (set to 0 if unknown)
% camDistort.K3 7rd order radial distortion (1/mm^6)  (set to 0 if unknown)
% camDistort.P1 decentering term (1/mm)  (set to 0 if unknown)
% camDistort.P2 decentering term (1/mm)  (set to 0 if unknown)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: February 15, 2009
% primary author: A. W. Burner

xs = camDistort.xs;
ys = camDistort.ys;
K1 = camDistort.K1;
K2 = camDistort.K2;
K3 = camDistort.K3;
P1 = camDistort.P1;
P2 = camDistort.P2;

if ischar(xymmDist)         % test to see if xymmDist is a string (or string variable)
    xymmDist = load(xymmDist);  % if string then load xymmDist array from file named from input argument xymmDist
end

Nrows = size(xymmDist,1);  % get number of rows (or centroid pairs) of input mm file
Ncols = size(xymmDist,2);  % get number of columns where 2 columns implies no target numbers and 3 columns implies target numbers in 1st column
xymmCorr = [];
for i=1:Nrows
    xmm = xymmDist(i,Ncols - 1);  % x-value in next to last column
    ymm = xymmDist(i,Ncols);      % y-value in last column
    xmmC = xmm - xs;
    ymmC = ymm - ys;
  %  for j=1:30    % iterate to find corrrected image coordinates needed for distortion correction
   for j=1:30    % iterate to find corrrected image coordinates needed for distortion correction
        rsqr = xmmC^2 + ymmC^2; % square of the radius
        xmmCorrK1 = K1 * xmmC * rsqr;
        ymmCorrK1 = K1 * ymmC * rsqr;
        xmmCorrK2 = K2 * xmmC * rsqr^2;
        ymmCorrK2 = K2 * ymmC * rsqr^2;
        xmmCorrK3 = K3 * xmmC * rsqr^3;
        ymmCorrK3 = K3 * ymmC * rsqr^3;
        xmmCorrP = P1 * (rsqr + 2 * xmmC^2) + 2 * P2 * xmmC * ymmC;
        ymmCorrP = P2 * (rsqr + 2 * ymmC^2) + 2 * P1 * xmmC * ymmC;
        xmmCorrTot = xmmCorrK1 + xmmCorrK2 + xmmCorrK3 + xmmCorrP;
        ymmCorrTot = ymmCorrK1 + ymmCorrK2 + ymmCorrK3 + ymmCorrP;
        xmmC = xmm - xmmCorrTot - xs;
        ymmC = ymm - ymmCorrTot - ys;
        % disp([j xmmCorrK1 xmmCorrK2 xmmCorrK3 xmmCorrP])
        % disp([j ymmCorrK1 ymmCorrK2 ymmCorrK3 ymmCorrP])
    end
    if Ncols == 3
        xymmCorr(i,1) = xymmDist(i,1);
    else
        xymmCorr(i,1) = i;
    end
%     xymmCorr(i,2) = xmmC;
%     xymmCorr(i,3) = ymmC;
    xymmCorr(i,2) = xmm - xmmCorrTot;
    xymmCorr(i,3) = ymm - ymmCorrTot;
end
return  % end of function distortCorrect


function m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing, AngleUnits)

% 3 X 3 rotation matrix (Azimuth, Tilt, Swing)
% m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing, AngleUnits)
% with only 3 input arguments; if 4th optional argument AngleUnits =
% 'radians'(exactly)then 3 input angles are assumed to be in radians
% (if AngleUnits anything other than 'radians' then degrees are assumed)
% sign convention for + angles: Azimuth: CW; Tilt: CCW; Swing: CCW

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

n = nargin;   % determine number of input arguments
if n < 3     % test for 3 input arguments and exit function if not = 3
    disp '3 (or 4) arguments are necessary to invoke function m = RotationMatrixAzTiltSwing(Azimtuh, Tilt, Swing, AngleUnits)'
    disp 'Type ''help RotationMatrixAzTiltSwing'' to see argument definitions'
    return
else
    if n == 4 && size(AngleUnits,2) == 7 && strcmp(AngleUnits, 'radians')
        A = Azimuth;   % angles already in radians so no conversion necessary
        T = Tilt;
        S = Swing;
    else
        A = Azimuth * pi / 180;  % convert angles from degrees to radians
        T = Tilt * pi / 180;
        S = Swing * pi / 180;
    end
% Reference	Elements of Photogrammetry, 2nd edition, McGraw-Hill, Paul R.
% Wolf, 1983, p. 610-612
    m = [];
    m(1,1) = -sin(A) * cos(T) * sin(S) - cos(A) * cos(S);
    m(1,2) = -cos(A) * cos(T) * sin(S) + sin(A) * cos(S);
    m(1,3) = -sin(T) * sin(S);
    m(2,1) = -sin(A) * cos(T) * cos(S) + cos(A) * sin(S);
    m(2,2) = -cos(A) * cos(T) * cos(S) - sin(A) * sin(S);
    m(2,3) = -sin(T) * cos(S);
    m(3,1) = -sin(A) * sin(T);
    m(3,2) = -cos(A) * sin(T);
    m(3,3) = cos(T);
end
return


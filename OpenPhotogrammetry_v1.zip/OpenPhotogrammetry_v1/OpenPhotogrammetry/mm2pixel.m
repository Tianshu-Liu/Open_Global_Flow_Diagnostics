function xypix = mm2pixel(xymm, Sh, Sv, x0, y0)

% converts image plane coordinates in mm to pixels
% xypix = mm2pixel(xymm, Sh, Sv, x0, y0)
% using standard pixel sign convention of 0,0 upper left hand corner
% with positive xpix to the right and positive ypix down
% input in mm centered (zeroed) at x0, y0 pixel coordinates with positive xmm right
% and positive ymm up
% output array xypix is an N X 3 array like [pt1 xpix1 ypix1; pt2 xpix2 ypix2;...ptN xpixN ypixN]
% where N is number of image points in mm to be converted to pixels
% and pt1, pt2...ptN are the point numbers
% for input mm arrays without point numbers (N X 2 array) pt1,
% pt2,...ptN in output array xypix are just a sequential counter from 1:N
% input xymm is an an N X 2 array of pixel coordinates like [xmm1 ymm1; xmm2 ymm2;...xmmN ymmN]
% or N X 3 array in mm [pt1 xmm1 ymm1; pt2 xmm2 ymm2;...ptN xmmN ymmN]
% x0, y0 locates the reference center of image in pixels
% 0, 0 in mm array will be equivalent to x0, y0 in pixels on output
% Sh and Sv are the horizontal and vertical pixel spacings in units of mm

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

n = nargin;   % determine number of input arguments
if n ~= 5     % test for 5 input arguments and exit function if not = 5
    disp '5 arguments are necessary to invoke function xypix = mm2pixel(xymm, Sh, Sv, x0, y0)'
    disp 'Type ''help mm2pixel'' to see argument definitions'
    return
else
    sz=size(xymm);             % determine number of rows and columns of input array xymm
    numberCoordinates = sz(1); % number of image coordinates N of input array xymm = number of rows
    numberCols = sz(2);        % number of columns of input array xymm
        if numberCols == 2
        ycol = numberCols;         % get y-values from last column of input array xypix
        xcol = ycol - 1;           % get x-values from next to last column of input array xypix
    else
        ycol = 3;         % get y-values from last column of input array xypix
        xcol = 2;           % get x-values from next to last column of input array xypix
    end

    xypix = [];                % initialize output array xypix
    for i=1:numberCoordinates  % step through x, y mm coordinates and convert to pixels
        xmm = xymm(i,xcol);    % temporary holder for x-value in mm
        ymm = xymm(i,ycol);    % temporary holder for y-value in mm
        x = xmm / Sh + x0;     % x-value in pixels
        y = -ymm / Sv + y0;    % y-value in pixels (- sign in front of ymm / Sv due to positive ypix down convention)
        if numberCols == 2     % test for 2 column input array xymm (without point numbers)
            xypix(i,1) = i;    % set point numbers to 1:numberCoordinates if point numbers are not explicitly entered within xymm input array
        else
            xypix(i,1) = xymm(i,1);  % get point numbers from 1st column of xymm if 3-column array
        end
        xypix(i,2) = x;         % put x-value in pixels in 2nd column of output array xypix
        xypix(i,3) = y;         % put y-value in pixels in 3rd column of output array xypix
    end
end
return



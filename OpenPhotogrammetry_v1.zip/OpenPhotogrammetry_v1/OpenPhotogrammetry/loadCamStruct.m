function cam = loadCamStruct(fileName)

% utility to load cam structure
% cam = loadCamStruct(fileName)
% fileName of file from which to load cam structure (string 'fileName' or variable fileName)
% camStructure is structure containing c, xp, yp, m, Xc, Yc, Zc
% rest of structure ignored

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

cam = [];       % initialize output structure cam
if exist(fileName, 'file')    % test to see if file exists (or can be found with specified path)
    linesOfText = textread(fileName,'%s','delimiter', '\n');  % read file 1 line at a time into cell array of strings
    mtemp = [];     % intialize internal array for rotation matrix m
    jRow = 1;       % row index for reading rotation matrix from file
    kCol = 1;       % column index for reading rotation matrix from file
    nRowsText = size(linesOfText,1); % number of rows of linesOfText cell array read in from file
    for cellRow=1:nRowsText          % step through cell array linesOfText from 1 to number of rows of linesOfText
        asciiTemp = double(char(linesOfText(cellRow))); % determine ascii values of each cell array row
        if asciiTemp(1) == 109                          % if ascii of 1st character = 109 ('m') then populate mtemp with rotation matrix
            charString = char(linesOfText(cellRow));    % set charString to character string of the cell array row cellRow
            mnum = str2double(charString(5:end)); % convert characters 5 to end of row to numerical value
            mtemp(jRow,kCol) = mnum;   % populate mtemp with rotation matrix
            cellRow = cellRow+1;       % increment row count of cell array from file by 1
            if jRow<3                  % order m11, m21, m31, m21, m22, m23, m31, m32, m33 in file
                jRow = jRow + 1;       % row index for rotation matrix
            else                       % if jRow = 3, reset jRow to 1 and increment kCol by 1
                kCol = kCol + 1;       % column index for rotation matrix
                jRow = 1;              % reset row of rotation matrix to 1
            end
        else
            eval(['cam.' char(linesOfText(cellRow,:)) ';']);  % populate fields of structure (like 'cam.c = 25.0', etc.)
        end
    end
    cam.m = mtemp;    % set 'm' field to mtemp (rotation matrix from file in proper order)
else                 % else print out error message if file not found
    fprintf(1, '%s file not found\n', fileName)
end
return


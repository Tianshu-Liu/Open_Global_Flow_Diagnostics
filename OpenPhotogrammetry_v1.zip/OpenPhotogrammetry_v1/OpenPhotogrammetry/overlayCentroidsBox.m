function overlayCentroidsBox(fileName, delx, dely, plotColor)

% overlays boxes at centroid locations on current figure
% overlayCentroidsBox(fileName, delx, dely, plotColor) on CURRENT figure
% delx, dely are half-width, half-height of box centered on centroids
% scalar entries for delx and dely apply the same width and height to all
% vector entries of delx and dely allows for different width/height for each target
% plotColor is and optional input parameter to specify the color to be used for the overlay plots
% Valid entries are �r� (default),  �b�, �g�, �c�, �m�, �y�, or �k�
% which indicate respectively red, blue, green, cyan, magenta, yellow, or black
% default color of plots is red without input argument plotColor
% both "pnt xpixel ypixel"
% and "xpixel ypixel" file formats supported 
% if 'fileName' is replaced with a N X 2 or N X 3 centroid array
% then the array will be used instead of a file

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: June 24, 2009
% primary author: A. W. Burner

if nargin == 3        % test for 3 arguments and set plotColor to default
    plotColor = 'r';  % default plotColor if input argument not used
end
% figure(gcf)    % set to current figure   (may not be needed)
if ischar(fileName)         % check to see if fileName is the name of a file or array variable
    xypix=load(fileName);   % load pixel values from file 
else
    xypix=fileName;         % load pixel values from array variable
end

hold on                     % do not clear figure between plot actions
Nrows = size(xypix,1);      
Ncols = size(xypix,2);      
if Ncols > 2
    x=xypix(:,2);
    y=xypix(:,3);
else
    x=xypix(:,1);
    y=xypix(:,2);
end
if length(delx) == 1
    delx(1:Nrows) = delx;
end
if length(dely) == 1
    dely(1:Nrows) = dely;
end

for i=1:Nrows
    plot([x(i) - delx(i), x(i) + delx(i)], [y(i) + dely(i), y(i) + dely(i)], plotColor)
    hold on
    plot([x(i) + delx(i), x(i) + delx(i)], [y(i) + dely(i), y(i) - dely(i)], plotColor)
    plot([x(i) + delx(i), x(i) - delx(i)], [y(i) - dely(i), y(i) - dely(i)], plotColor)
    plot([x(i) - delx(i), x(i) - delx(i)], [y(i) - dely(i), y(i) + dely(i)], plotColor)
    if Ncols > 2
        text(x(i) + delx(i) + 5, y(i),num2str(xypix(i,1)),'color', plotColor, 'horizontalalignment', 'left', 'FontWeight', 'bold', 'FontSize', 12)
    else
        text(x(i) + delx(i) + 5, y(i),num2str(i),'color', plotColor, 'horizontalalignment', 'left', 'FontWeight', 'bold', 'FontSize', 12)
    end
end
hold off   % without this last hold off drastically increased buildup of memory usage 
return
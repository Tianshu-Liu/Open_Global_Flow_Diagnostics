function [omegaDual, phiDual, kappaDual] = rotationMatrixDuality(omega, phi, kappa, AngleUnits)

% alternate set (duality) of omega, phi, kappa (degree) for identical rotation matrix
% [omegaDual, phiDual, kappaDual] = rotationMatrixDuality(omega, phi, kappa, AngleUnits)
% with only 3 input arguments; if 4th argument AngleUnits =
% 'radians'(exactly) then 3 input angles (and output angles) are assumed to be in radians
% (if AngleUnits anything other than 'radians' then degrees are assumed)
% sign convention for angles: ccw is +

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: November 27, 2006
% primary author: A. W. Burner

n = nargin;   % determine number of input arguments
if n < 3     % test for at least 3 input arguments and exit function if not => 3
    disp '3 (or 4) arguments are necessary to invoke function m = RotationMatrix(omega, phi, kappa, AngleUnits)'
    disp 'Type ''help RotationMatrix'' to see argument definitions'
    return
else
    if n == 4 && size(AngleUnits,2) == 7 && strcmp(AngleUnits, 'radians') % strcmp is string compare
        W = omega;   % angles already in radians so no conversion necessary
        P = phi;
        K = kappa;
        radiansFlag = 1;
    else
        W = omega * pi / 180;  % convert angles from degrees to radians
        P = phi * pi / 180;
        K = kappa * pi / 180;
        radiansFlag = 0;
    end
    
    % reference: PE&RS vol. 56 No.9, Sept. 1990, pp. 1281-1283
    % do al1 computations in radians and convert back to degrees if radiansFlag is off
    WDuality = [W + pi, W - pi]; % compute 2 choices for omegaDual
    i = find(abs(WDuality) == min(abs(WDuality)));  % find smallest (absolute) of 2 choices
    omegaDual = WDuality(i(1));  % set omegaDual to smallest (absolute)
    PDuality = [pi - P, -pi - P]; % compute 2 choices for phiDual
    i = find(abs(PDuality) == min(abs(PDuality)));  % find smallest (absolute) of 2 choices
    phiDual = PDuality(i(1));  % set phiDual to smallest (absolute)
    KDuality = [K + pi, K - pi]; % compute 2 choices for kappaDual
    i = find(abs(KDuality) == min(abs(KDuality)));  % find smallest (absolute) of 2 choices
    kappaDual = KDuality(i(1));  % set kappaDual to smallest (absolute)
    if ~radiansFlag   % convert to degrees if radiansFlag is off
        omegaDual = omegaDual * 180 / pi;
        phiDual   =   phiDual * 180 / pi;
        kappaDual = kappaDual * 180 / pi;
    end
        
end
return   % end of function rotationMatrixDuality
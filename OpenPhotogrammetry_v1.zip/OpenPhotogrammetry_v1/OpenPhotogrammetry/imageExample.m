I = imread('coins.png');
figure, imshow(I)

bw = im2bw(I, graythresh(getimage));
figure, imshow(bw)

bw2 = imfill(bw,'holes');
L = bwlabel(bw2);
s = regionprops(L, 'centroid');
centroids = cat(1, s.Centroid);


% Display original image I and superimpose centroids.
imtool(I)
hold(imgca,'on')
plot(imgca,centroids(:,1), centroids(:,2), 'r*')
hold(imgca,'off')

% example of selecting rectangle with mouse on current figure inside loop
Nrois = 5;
roiN = []; for i = 1:Nrois; title(['select roi ' num2str(i)]); roi = getrect; roiN = [roiN; roi]; end; title('finished selecting rectangles'); disp(roiN)
% roiN is an array with [xmin ymin width height] per row with Nrois rows

% functions to check out
% strel
% label2rgb
% label matrix (not function)
% imcrop
% regionprops BoundingBox field
% histogram of bounding box sizes or areas
% comp.soft-sys.matlab
% For single or double arrays, values range from [0, 1]. For uint8, values
% range from [0,255]. For uint16, values range from [0, 65535].
% imcomplement to complement grayscale image
% J = imadjust(I,[low_in; high_in],[low_out; high_out])  [ 0 1], [1 0] inverts image
% must be 0 -> 1 for imadjust
% ~bw inverts (complement) the binary image bw
% im2uint8, im2uint16, im2int16, im2single, or im2double
% maketform; imtransform 
% immovie; montage m-by-n-by-1-by-p, for grayscale, binary, or indexed images, or m-by-n-by-3-by-p,
% frames are concatenated along the fourth dimension
% A = cat(4,A1,A2,A3,A4,A5) to combine 5 images into a single array (4 dimensions needed for immovie)
% mov = immovie(A,colormap('Gray')); for grayscale images; movie(mov) to show
% use for i=1:10; movie(mov); end to show multiple times
% avifile; addframe
% watershed
% imlincomb
% imfinfo - file info structure
% getimage; to get to workspace if imshow used on filename (moon = getimage(imgca) for imtool)
% startup.m 
% imgca
% imtool close all (for multiple imtool figures)
% subplot(2,2,1); subimage(img) or subplot(2,2,1); imshow(img)
% warp
% impixelinfo instead of pixval
% imdisplayrange
% impixelregion
% imrect
% imhandles
% four-element position vector [left bottom width height]
hfig = figure;
hax = axes('units','normalized','position',[0 .5 1 .5]);
% hax = axes('units','normalized','position',[0 .7 .9 .2]);
himage = imshow('image1.tif');
hpixelinfopanel = impixelinfo(himage);
hdrangepanel = imdisplayrange(himage);
hpixreg = impixelregionpanel(hfig,himage);
set(hpixreg, 'Units','normalized','Position',[0 .08 1 .4]);

% [fileName userCancel]=imgetfile  % open image dialog box
% z=imresize(a,size(img),'bilinear');

% mri = uint8(zeros(128,128,1,27)); % preallocate 4-D array
% for frame=1:27
% [mri(:,:,:,frame),map] = imread('mri.tif',frame);
% end

% may be useful to introduce shear to an image to test centroiding target numbers
I = imread('cameraman.tif');
tform = maketform('affine',[1 0 0; .5 1 0; 0 0 1]);
J = imtransform(I,tform);
imshow(I), figure, imshow(J)
% or imrotate(A,angle,method) (method = 'bilinear' does good job) may be better

function grayScaleDisplay(img)  % grayScaleDisplay may be better (old -> grayScalePrint)
% Create figure, setting up properties
hfig = figure('Toolbar','none',...
'Menubar', 'none',...
'Name','Grayscale Display',...
'NumberTitle','off',...
'IntegerHandle','off');
% Create axes and reposition the axes
% to accommodate the Pixel Region tool panel
hax = axes('Units','normalized',...
'Position',[0 .5 1 .5]);
% Display image in the axes and get a handle to the image
himage = imshow(img);
% Add Distance tool, specifying axes as parent
% hdist = imdistline(hax);  % may want to leave this one off function
% Add Pixel Information tool, specifying image as parent
hpixinfo = impixelinfo(himage);
% Add Display Range tool, specifying image as parent
hdrange = imdisplayrange(himage);
% Add Pixel Region tool panel, specifying figure as parent
% and image as target
hpixreg = impixelregionpanel(hfig,himage);
% Reposition the Pixel Region tool to fit in the figure
% window, leaving room for the Pixel Information and
% Display Range tools.
set(hpixreg, 'units','normalized','position',[0 .08 1 .4])

% Locating Image Features
% The Fourier transform can also be used to perform correlation, which is closely
% related to convolution. Correlation can be used to locate features within an
% image; in this context correlation is often called template matching.

% background = imopen(I,strel('disk',15));  % radius = 15
% [labeled,numObjects] = bwlabel(bw,4); % 4-connected
% RGB_label = label2rgb(labeled, @spring, 'c', 'shuffle');
% graindata = regionprops(labeled,'basic')
% nbins = 20;
% figure,hist(allgrains,nbins)
% Another word for object detection is segmentation.
% BWdfill = imfill(BWsdil, 'holes');   % fill holes in image
% BWnobord = imclearborder(BWdfill, 4);
% seD = strel('diamond',1);
% BWfinal = imerode(BWnobord,seD);
% BWfinal = imerode(BWfinal,seD);
% figure, imshow(BWfinal), title('segmented image');
% BWoutline = bwperim(BWfinal);   % perimeter of object
% Segout = I; 
% Segout(BWoutline) = 255;    % make perimeter of object on image white
% figure, imshow(Segout), title('outlined original image');

% false;  true; logical; islogical
% &, |, and ~ are the logical array operators AND, OR, and NOT
% xor(A,B) implements the exclusive OR operation

% strel
% getnhood
% Note You typically choose a structuring element the same size and shape as
% the objects you want to process in the input image. For example, to find lines
% in an image, create a linear structuring element.
% sel = strel('diamond',4)
% seq = getsequence(sel)
% [seq(1) seq(2)...]
% imdilate
% bwpack
% imerode
% definition of a morphological opening
% of an image is an erosion followed by a dilation, using the same structuring
% element for both operations. The related operation, morphological closing of
% an image, is the reverse: it consists of dilation followed by an erosion with the
% same structuring element.
% imopen
% You can use morphological opening to remove small objects from an image
% while preserving the shape and size of larger objects in the image.
% bwmorph (skeletonization)
% bwperim
% imreconstruct
% imfill removes regional minima that are not connected to the image border
% can be useful in removing irrelevant artifacts from images (background)
% imregionalmax and imregionalmin functions identify all regional minima or maxima.
% imextendedmax and imextendedmin functions identify all regional
% minima or maxima that are greater than or less than a specified threshold
% grayscale to binary with regional min or max as 1
% imhmax  significant minima or maxima and not in these smaller minima and maxima
% caused by background texture
% imimposemin
% mask is main image; marker is secondary

% creating a binary image
% center1 = -10;
% center2 = -center1;
% dist = sqrt(2*(2*center1)^2);
% radius = dist/2 * 1.4;
% lims = [floor(center1-1.2*radius) ceil(center2+1.2*radius)];
% [x,y] = meshgrid(lims(1):lims(2));
% bw1 = sqrt((x-center1).^2 + (y-center1).^2) <= radius;
% bw2 = sqrt((x-center2).^2 + (y-center2).^2) <= radius;
% bw = bw1 | bw2;
% figure, imshow(bw), title('bw')

% bwlabel appears to label regions left-2-right
% label2rgb(L) converts a label matrix L, such as those returned by bwlabel or watershed, into an RGB color image for the purpose of visualizing the labeled regions
% bwselect
% bwarea
% The bweuler function returns the Euler number for a binary image. The
% Euler number is a measure of the topology of an image. It is defined as the
% total number of objects in the image minus the number of holes in those
% objects
% makelut and applylut
% imcontour
% imhist
% mean2, std2, corr2
% regionprops
% ismember 
% a binary image containing only the regions whose area is greater than 80
% idx = find([stats.Area] > 80);
% BW2 = ismember(L,idx);
% bwtraceboundary and bwboundaries
% hough to detect lines
% houghpeaks
% houghlines
% Entropy is a statistical measure of randomness.
% imnoise

% mmfileinfo

% binary mask, which is a binary image with the same size as the image you want
% to process. The mask contains 1�s for all pixels that are part of the region
% of interest, and 0�s everywhere else.
% roipoly
% roifilt2
% roifill

% msg = nargoutchk(1, 3, nargout) % to check if calling m-file has enough output arguments
% error(nargchk(2, 3, nargin)) % check input arguments

% MATLAB provides the conv and filter2 functions for performing convolution, and the toolbox
% provides the imfilter function.  See Chapter 8, �Linear Filtering and Filter
% Design� for more information about these functions.

% nlfilter

% guidata
% guide
% guihandles
% movegui

% vars = evalin('base','who');  % to get cell array of strings listing workspace variables
%  files = evalin('base','dir'); % to get structure array of files; files(:).name contains names

% LOWER  Convert string to lowercase.  also upper (both work on cell array of strings)
% switch ... case...case...otherwise...end

% [fileName path] = uiputfile({'*.tif;*.jpg','Image files (*.tif,*.jpg)'; '*.*', 'all files (*.*)'}, 'nameForDialogBox')
% [fileName path] = uigetfile({'*.tif;*.jpg','Image files (*.tif,*.jpg)'; '*.*', 'all files (*.*)'}, 'nameForDialogBox')
%       N X 1 or N X 2 cell array above
% uigetdir
% matlabroot
% addpath([matlabroot '/toolbox/local/myfiles']) adds the directory myfiles to the MATLAB search path.
% [pathstr, name, ext, versn] = fileparts('filename')
% fullfile(pathstr,[name ext versn])
% f = fullfile('dir1', 'dir2', ..., 'filename')





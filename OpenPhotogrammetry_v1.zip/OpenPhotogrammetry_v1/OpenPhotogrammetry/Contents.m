% Photogrammetry Toolbox
% Version 1 01-May-2007
%   affine2D                  - affine transformation for 2D coordinates
%   affine2DLLS               - linear least squares to determine affine transformation coefficients
%   Australis2PM              - returns omega, phi, kappa output in degrees from Australis Azimuth, Elevation, Roll input in degrees
%   camcal_fun                - camera calibration by optimization 
%   camcal_fun_1              - camera calibration by multiple-stage optimization 
%   cameraConstant            - finds camera constant given image data at 2 or more known Z-displacements
%   centroid                  - gray scale centroid for a region of interest (roi)
%   centroid_cal_fun          - centroid of an image area in pixels 
%   centroidMerge             - merges 2 centroid arrays with the same number of columns into a single centroid array
%   clicking_target_fun       - centroids by mouse selection
%   collinearity              - creates ideal image plane data
%   conformal2D               - conformal 2D transformation
%   conformal2Dinv            - inverse conformal 2D transformation
%   conformal2DLLS            - linear least squares to determine conformal transformation coefficients and
%   conformal2DNLLS           - non-linear least squares (NLLS) to determine conformal transformation coefficients and
%   conformal3D               - 3D conformal transformation [Xtrans] = s * [m] * [Xin] + [Txyz]
%   conformal3Dinv            - inverse transformation [Xtrans] = [m'] * [Xin - Txyz] / s 
%   conformal3DNLLS           - non-linear least squares (NLLS) to determine conformal transformation coefficients and
%   conformalAltSol           - finds alternate solution of omega, phi, kappa, Tx, Ty, Tz, s
%   displayGrayScale          - displays gray scale for ROI
%   distortApply              - applies distortion to image coordinates
%   distortCorrect            - corrects image coordinates for distortion
%   distortSolve              - solves for any or all distortion coefficients K1, K2, K3, P1, P2
%   dlt                       - to determine initial approximations for the camera orientation parameters 
%   dlt0                      - raw DLT function to give the DLT paparmeters and initial approximations
%   EpipolarLine_x            - determines the epipolar line (x) in the image 1 for a given point (ximag2,yimag2) in pixels in the image 2
%   EpipolarLine_y            - determines the epipolar line (y) in the image 1 for a given point (ximag2,yimag2) in pixels in the image 2
%   EpipolarRelation_x        - gives an epipolar relation (x) between two images (A and B) when the camera orientation parameters
%   EpipolarRelation_y        - gives an epipolar relation (y) between two images (A and B) when the camera orientation parameters
%   findBackground            - finds max gray scale, Gback, on perimeter of region of interest (roi) of a digital image
%   grayScaleDisplay          - grayscale display (interactive) with image in a figure window
%   helpPT                    - display contents of 'Photogrammetry Toolbox'
%   imageObject               - GUI to solve for focal length, object distance, or image distance, given any 2
%   imageObject2              - calculates focal length, object distance, or image distance
%   imagePrelim               - GUI for preliminary target locations
%   intersection              - multi-camera photogrammetric spatial intersection to determine 3D
%   lleast                    - linear least squares estimation for the collinearity equations.
%   lleast3                   - linear least squares determines only omega, phi, kappa when other parameters known
%   loadCamStruct             - utility to load cam structure
%   locating_target1_fun      - centroid of a single target near a selected location in pixels.
%   matchIDs                  - matches correct centroids from one array to correct IDs of another array (with only approximate centroids)
%   mm2pixel                  - converts image plane coordinates in mm to pixels
%   overlayCentroidsBox       - overlays boxes at centroid locations on current figure
%   pixel2mm                  - converts image plane coordinates in pixels to mm
%   pixelXYselect             - manual selection of x, y location (using impixel) on current image and storage to file
%   PM2Australis              - returns Australis Azimuth, Elevation, Roll with omega, phi, kappa input in degrees
%   RadiomCali_cheby_fun      - radiometric camera calibration based on the Chebysev functions
%   RadiomCali_poly_fun       - radiometric camera calibration based on the power functions
%   resection                 - nonlinear least squares (NLLS) to determine omega, phi, kappa, Xc, Yc, Zc
%   resec                     - resection to obtain the exterior orientation parameters given interior orientation
%   resec3                    - linear least squares for omega,phi,kappa given other parameters
%   resecA                    - resection for exterior orientation given interior orientation
%   resec_ZW                  - closed-form space resection function developed by Zeng and Wang (1992)
%   resectionLocalMin         - determines 3 alternate sets of exterior orientation for resection on near planar objects
%   residual_exterior         - residual of the calculated image coordinates (minimization of the exterior orientation)
%   residual_interior1        - residual of the calculated image coordinates (minimization of the first subset of the interior orientation)
%   residual_interior2        - residual of the calculated image coordinates (minimization of the second subset of the interior orientation)
%   roiPolySelect             - select by mouse polygon region of interest (roi) on an image; rest of image = 0
%   roiSelect                 - select by mouse 1 or more regions of interest (roi) on an image; rest of image = 0
%   rotationMatrix            - 3 X 3 rotation matrix omega, phi, kappa
%   rotationMatrixAzElevRoll  - 3 X 3 rotation matrix (Azimuth, Elevation, Roll)
%   rotationMatrixAzTiltSwing - 3 X 3 rotation matrix (Azimuth, Tilt, Swing)
%   rotationMatrixDuality     - alternate set (duality) of omega, phi, kappa (degree) for identical rotation matrix
%   saveCamStruct             - utility to save structure cam
%   singleView                - single view photogrammetry computing 1 or 2 coordinates if 2 or 1 known
%   TransposeAngles           - omega, phi, kappa for tanspose of rotation matrix
%   xy2XYZ                    - photogrammetric 2-view intersection (LaRC column format entry)
%   xy2XZ                     - single view (X,Z) coordinates
%   xyplot                    - plot to compare the calculated and measured targets in the image plane 
%   XYZ2xy                    - generates target coordinates (in pixels) in the image plane
function [x_c,y_c]=centroid_cal_fun(A)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% centroid of an image area in pixels 
% where x_c and y_c are the x-coordinate (horizontal) and y-coordinate (vertical)
% from the upper-left corner of the image.
%
% Inputs:
%       (1) 'A', a local area of an image intensity field (not particularly defined) 
%
% Outputs:
%       [x_c,y_c], calculated centroid of the image area A in pixels
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A=double(A);
size_A=size(A);
x_range=size_A(2);
y_range=size_A(1);

% compute the centroid of A
sx=0;
j=1;
i=1;
while (j<=x_range)
   while (i<=y_range)
      sx=sx+A(i,j)*j;
      i=i+1;
   end
   i=1;
   j=j+1;
end
x_c=sx/sum(sum(A));

sy=0;
j=1;
i=1;
while (j<=x_range)
   while (i<=y_range)
      sy=sy+A(i,j)*i;
      i=i+1;
   end
   i=1;
   j=j+1;
end
y_c=sy/sum(sum(A));


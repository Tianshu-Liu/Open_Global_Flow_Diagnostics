function [Xtarg, Ztarg] = xy2XZ(xPix,yPix,Ytarg,ori,camformat)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% single view (X,Z) coordinates
% from a single calibrated camera (or image) for a given Y location.  This is useful for wing deformation measurements
% in wind tunnels when only a single camera is available. It is also known as the single-camera solution. 
%
% Inputs: (1) (xPix,yPix), (x,y) coordinates in pixel in image, (x - horizantal, y - vertical)
%         (2) Ytarg, the designated or given Y-coordinate of a target, in inches (typically)
%         (3) ori, the camera exterior and interior orientation parameters
%             (omega,phi,kappa,Xc,Yc,Zc), (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (4) camformat, the camera format file, 
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%
% Outputs: [Xtarg, Ztarg], (X,Z) coordinates of a target in the designated object space coordinate system
%          for the given Ytarg, the units are consistent with (Xc,Yc,Zc) (typically in inches)
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

orientation=ori;
cam_format=camformat;

omaga=orientation(1)*pi/180;
phi=orientation(2)*pi/180;
kappa=orientation(3)*pi/180;
Xc=orientation(4);
Yc=orientation(5);
Zc=orientation(6);
c=orientation(7); %mm
xp=orientation(8); %mm
yp=orientation(9); %mm
hvratio=orientation(10);
k1=orientation(11);
k2=orientation(12);
p1=orientation(13);
p2=orientation(14);
Sv=cam_format(4);
Sh=hvratio*Sv;
xrange=cam_format(1);
yrange=cam_format(2);

% calculate the rotational matrix
m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);

xd=Sh*(xPix-xrange/2);
yd=Sv*(yrange/2-yPix);
xud=xd;
yud=yd;

k=0;
while k<=6
	xx=xud-xp;
   yy=yud-yp;
   r2=(xx).^2+(yy).^2;
	dxr=k1*xx.*r2+k2*xx.*(r2.*r2);
	dyr=k1*yy.*r2+k2*yy.*(r2.*r2);
	dxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
	dyd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
	xud=xd+dxr+dxd;
   yud=yd+dyr+dyd;
   k=k+1;
end

	xn = (xud - xp)/c;
	yn = (yud - yp)/c;

% solve for X and Z
	a11=xn*m31+m11;
	a12=xn*m32+m12;
	a13=xn*m33+m13;
	a21=yn*m31+m21;
	a22=yn*m32+m22;
	a23=yn*m33+m23;
	b1=a11*Xc+a12*Yc+a13*Zc-a12*Ytarg;
	b2=a21*Xc+a22*Yc+a23*Zc-a22*Ytarg;
	delta=a11*a23-a21*a13;
	delta1=b1*a23-b2*a13;
	delta2=b2*a11-b1*a21;
	Xtarg = delta1/delta;
	Ztarg = delta2/delta;

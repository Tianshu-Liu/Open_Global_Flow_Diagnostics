function [L,orien]=dlt0(camformat,xyimag,xyzobj)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% raw DLT function to give the DLT paparmeters and initial approximations
% for the camera orientation parameters. However, the Euler angles (omega,phi,kappa) are not
% transformed to the domains -180<omega<180, -90<phi<90, -180<kappa<180. 
%
% Inputs: (1) 'camformat' is the camera format file,
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%         (2) 'xyimag' is the target coordinate file in the image plane in pixels 
%         (3) 'xyzobj' is the target coordinate file in the object space in inches.
%
% Outputs: (1) L, The DLT parameters
%          (2) orien, The orientation parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp)
%
% Note that xp and yp given by the DLT are very sensitive to small errors, and they may not be accurate 
%       and the Euler rotationa angles giveb by his raw DLT are accurate.  
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% convert the target coordinates to 'mm' in both the image plane and object space 
x_range=camformat(1);
y_range=camformat(2);
Sv=camformat(4);
Sh=camformat(3);

xim=(xyimag(:,1)-x_range/2)*Sh;
yim=-(xyimag(:,2)-y_range/2)*Sv;

% convert inch to mm for the object space coordinates
xm=xyzobj(:,1)*25.4;
ym=xyzobj(:,2)*25.4;
zm=xyzobj(:,3)*25.4;

% obtain the DLT solution
a11=xm;
a12=ym;
a13=zm;
a14=1*ones(length(xm),1);
a15=0*ones(length(xm),1);
a16=0*ones(length(xm),1);
a17=0*ones(length(xm),1);
a18=0*ones(length(xm),1);
a19=-xim.*xm;
a110=-xim.*ym;
a111=-xim.*zm;
a21=0*ones(length(xm),1);
a22=0*ones(length(xm),1);
a23=0*ones(length(xm),1);
a24=0*ones(length(xm),1);
a25=xm;
a26=ym;
a27=zm;
a28=1*ones(length(xm),1);
a29=-yim.*xm;
a210=-yim.*ym;
a211=-yim.*zm;
a=[a11 a12 a13 a14 a15 a16 a17 a18 a19 a110 a111;
   a21 a22 a23 a24 a25 a26 a27 a28 a29 a210 a211];
b1=xim;
b2=yim;
b=[b1;b2];
neq=a'*a;
rhs=a'*b;
L=neq\rhs; % DLT parameters

% convert the DLT parameters to the camera orientation parameters
e1=[L(1) L(2) L(3);
    L(5) L(6) L(7);
    L(9) L(10) L(11)];
e2=-[L(4);L(8);1];
XYZc=(e1\e2)/25.4;
LL=-1/(L(9)^2+L(10)^2+L(11)^2)^0.5;
xp=(L(1)*L(9)+L(2)*L(10)+L(3)*L(11))*LL^2;
yp=(L(5)*L(9)+L(6)*L(10)+L(7)*L(11))*LL^2;
c=(LL^2*(L(1)^2+L(2)^2+L(3)^2)-xp)^0.5;
omega=atan(-L(10)/L(11))*180/pi;
phi=asin(L(9)*LL)*180/pi;
m11=LL*(xp*L(9)-L(1))/c;
kappa=acos(m11/cos(phi*pi/180))*180/pi;

interior=[c;0;0;Sh/Sv;0];
exterior=[omega;phi;kappa;XYZc];
orien=[exterior;interior];

% plot the results
xyplot(camformat,orien,xyimag,xyzobj,1);
title('Initial Estimation by DLT');



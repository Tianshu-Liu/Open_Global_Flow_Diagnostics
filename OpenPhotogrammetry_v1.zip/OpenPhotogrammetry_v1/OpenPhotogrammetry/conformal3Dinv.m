function Xout = conformal3Dinv(Xin, m, Txyz, s)

% inverse transformation [Xtrans] = [m'] * [Xin - Txyz] / s 
% Xout = conformal3Dinv(Xin, m, Txyz, s)
% Xin is N X 4 (1st column contains target numbers); m is 3 X 3 from rotationMatrix function
% Txyz is a row or column vector of translations in X, Y, and Z order
% s is scale (scalar)
% output array Xout is N X 4

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

Nrows = size(Xin, 1); % find number of rows (# of target) of Xin for next 'for loop'
Xout =[];             % initialize Xout array
T = [Txyz(1); Txyz(2); Txyz(3)]; % create 3 X 1 column vector for matrix calculation below (in case Txyz passed as a row vector)
for i = 1:Nrows       % step through rows of Xin (1 row = 1 target number)
    XYZ2 = Xin(i,2:4)';  % create column vector from row of XYZ
    Xout(i,:) = m' * (XYZ2 - T) / s; % column vector of transformed XYZ stored as row vector of Xout
end                   % end of subtract translation loop 
Xout = [Xin(:,1) Xout]; % attach target numbers to 1st column of output array Xout


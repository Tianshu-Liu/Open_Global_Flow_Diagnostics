function []=xyplot(camformat,orien,xyimag,xyzobj,plot_No)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot to compare the calculated and measured targets in the image plane 
% when the camera orientation parameters are given.
%
% Inputs: (1) orien, the exterior and interior orientation parameters, (omega,phi,kappa,Xc,Yc,Zc)
%             (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (2) camformat, the camera format file,
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%         (3) xyimag, measured image coordinates, in pixels
%         (4) xyzobj, the object space coordinates, in inches
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


xm=xyzobj(:,1);
ym=xyzobj(:,2);
zm=xyzobj(:,3);

omaga=orien(1)*pi/180;
phi=orien(2)*pi/180;
kappa=orien(3)*pi/180;
xc=orien(4);
yc=orien(5);
zc=orien(6);
c=orien(7); %mm
xp=orien(8); %mm
yp=orien(9); %mm
k1=orien(11);
k2=0;
p1=0;
p2=0;

m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);
w=m31*(xm-xc)+m32*(ym-yc)+m33*(zm-zc);
wx=m11*(xm-xc)+m12*(ym-yc)+m13*(zm-zc);
wy=m21*(xm-xc)+m22*(ym-yc)+m23*(zm-zc);
x_image=xp-c*wx./w;
y_image=yp-c*wy./w;

r2=(x_image-xp).^2+(y_image-yp).^2;
xx=x_image-xp;
yy=y_image-yp;
deltaxr=k1*xx.*r2+k2*xx.*(r2.*r2);
deltayr=k1*yy.*r2+k2*yy.*(r2.*r2);
deltaxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
deltayd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
deltax=deltaxr+deltaxd;
deltay=deltayr+deltayd;

x_imaged=xp-deltax-c*wx./w;
y_imaged=yp-deltay-c*wy./w;


Sv=camformat(4);
Sh=orien(10)*Sv;
x_range=camformat(1);
y_range=camformat(2);
x_imag=(xyimag(:,1)-x_range/2)*Sh;
y_imag=-(xyimag(:,2)-y_range/2)*Sv;

figure(plot_No);
plot(x_imaged,y_imaged,'+',x_imag,y_imag,'o');
xlabel('x (mm)');ylabel('y (mm)');
legend('calculated','measured');



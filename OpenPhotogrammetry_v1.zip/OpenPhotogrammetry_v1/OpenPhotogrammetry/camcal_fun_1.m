function [orien]=camcal_fun_1(xyimag,xyzobj,camformat,ex_orien_0,in_orien1_0,in_orien2_0)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% camera calibration by multiple-stage optimization 
% parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1), where multiple-stages of optimization
% are used for the exterior orientation parameters and two subset of the interior orientation parameters.
% Compared to 'camcal_fun.m', this function does not use non-linear least squares estimation that may
% fail in certain case.  
%
% Inputs:
%       (1) 'xyzobj', the object space coordinates of a number of known targets in inches, which is a three-colunm file. 
%       (2) 'xyimag', the corresponding image centroids in pixels, which is a two-colunm file.
%       (3) 'camformat', the camera format, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (4) 'ex_orien_0', the approximate exterior orientation perameters for optimization, (omega,phi,kappa,Xc,Yc,Zc)
%       (5) 'in_orien1_0', the first subset of approximate interior orientation perameters for optimization, (c,xp,yp,Sh/Sv,K1)
%       (4) 'in_orien2_0', the second subset of approximate interior orientation perameters for optimization, (K2,P1,P2)
%
%  Outputs:
%       The camera orientation parameters improved by optimization:
%       For example, typical values of the orientation parameters:
%       Omega: -56 deg.
%       Phi: -9 deg.
%       Kappa: -80 deg.
%       Xc: -2 in
%       Yc: 56 in
%       Zc: 36 in
%       c: 28 mm
%       xp: 0.2 mm
%       yp: 0.08 mm
%       Sh/Sv: 0.923
%       K1 (mm^-2): 0.0005    
%       K2=0
%       P1=0
%       P2=0
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% interactive two-step optimization for the exterior orientation parameters and first subset of the 
% interior orientation parameters
k=1;
N=50;
while (k<=N)
    [ex_orien_1,residual]=fminsearch('residual_exterior',ex_orien_0,[],in_orien1_0,in_orien2_0,camformat,xyimag,xyzobj);
    [in_orien1_1,residual]=fminsearch('residual_interior1',in_orien1_0,[],ex_orien_1,in_orien2_0,camformat,xyimag,xyzobj);
   
    ex_orien_0=ex_orien_1;
    in_orien1_0=in_orien1_1;   
    k=k+1;
    residual
end

% optimization for the second subset of the interior orientation parameters
[in_orien2_1,residual]=fminsearch('residual_interior2',in_orien2_0,[],ex_orien_1,in_orien1_1,camformat,xyimag,xyzobj);
residual

% the camera orientation parameters
orien=[ex_orien_1;in_orien1_1;in_orien2_1];   
     

fprintf('\nFinal Orientation Parameters:\n');
fprintf('Omega (deg): %g\n',orien(1));
fprintf('Phi (deg): %g\n',orien(2));
fprintf('Kappa (deg): %g\n',orien(3));
fprintf('Xc (in): %g\n',orien(4));
fprintf('Yc (in): %g\n',orien(5));
fprintf('Zc (in): %g\n',orien(6));
fprintf('c(mm): %g\n',orien(7));
fprintf('xp(mm): %g\n',orien(8));
fprintf('yp(mm): %g\n',orien(9));
fprintf('Sh/Sv: %g\n',orien(10));
fprintf('K1 (mm^-2): %g\n',orien(11));
fprintf('K2 (mm^-2): %g\n',orien(12));
fprintf('P1 (mm^-2): %g\n',orien(13));
fprintf('P2 (mm^-2): %g\n',orien(14));
fprintf('Residual (mm): %g\n',residual);





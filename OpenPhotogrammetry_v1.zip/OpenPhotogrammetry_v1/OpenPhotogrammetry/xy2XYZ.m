function [Xtarg, Ytarg, Ztarg] = xy2XYZ(xPixA,yPixA,xPixB,yPixB,oriA,oriB,camformatA,camformatB)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% photogrammetric 2-view intersection (LaRC column format entry)
% from two calibrated cameras A and B (or images A and B)
%
% Inputs: (1) (xPixA,yPixA), (x,y) coordinates in pixel in Image A, (x - horizantal, y - vertical)
%         (2) (xPixB,yPixB), (x,y) coordinates in pixel in Image B, (x - horizantal, y - vertical)
%         (3) oriA, the exterior and interior orientation parameters of Camera A,
%             (omega,phi,kappa,Xc,Yc,Zc), (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (4) oriB, the exterior and interior orientation parameters of Camera B,
%             (omega,phi,kappa,Xc,Yc,Zc), (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (5) camformatA, the camera format file for Camera A, 
%         (6) camformatB, the camera format file for Camera B, 
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%
% Outputs: [Xtarg, Ytarg, Ztarg], (X,Y,Z) coordinates of a target in the designated object space coordinate system,
%          the units are consistent with (Xc,Yc,Zc) (typically in inches)
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for Camera A
omaga=oriA(1)*pi/180;
phi=oriA(2)*pi/180;
kappa=oriA(3)*pi/180;
Xc=oriA(4);
Yc=oriA(5);
Zc=oriA(6);
c=oriA(7); %mm
xp=oriA(8); %mm
yp=oriA(9); %mm
hvratio=oriA(10);
k1=oriA(11);
k2=oriA(12);
p1=oriA(13);
p2=oriA(14);
Sv=camformatA(4);
Sh=hvratio*Sv;
xrange=camformatA(1);
yrange=camformatA(2);

% calculate the rotational matrix for camera A
m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);

xd=Sh*(xPixA-xrange/2);
yd=Sv*(yrange/2-yPixA);
xud=xd;
yud=yd;

k=0;
while k<=6
	xx=xud-xp;
   yy=yud-yp;
   r2=(xx).^2+(yy).^2;
	dxr=k1*xx.*r2+k2*xx.*(r2.*r2);
	dyr=k1*yy.*r2+k2*yy.*(r2.*r2);
	dxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
	dyd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
	xud=xd+dxr+dxd;
   yud=yd+dyr+dyd;
   k=k+1;
end

	xn = (xud - xp)/c;
	yn = (yud - yp)/c;
   
   
   B1=[(m11+xn*m31) (m12+xn*m32) (m13+xn*m33);
      (m21+yn*m31) (m22+yn*m32) (m23+yn*m33)];
   C1=[(xn*m31+m11)*Xc+(xn*m32+m12)*Yc+(xn*m33+m13)*Zc;
      (yn*m31+m21)*Xc+(yn*m32+m22)*Yc+(yn*m33+m23)*Zc];


% for Camera B
omaga=oriB(1)*pi/180;
phi=oriB(2)*pi/180;
kappa=oriB(3)*pi/180;
Xc=oriB(4);
Yc=oriB(5);
Zc=oriB(6);
c=oriB(7); %mm
xp=oriB(8); %mm
yp=oriB(9); %mm
hvratio=oriB(10);
k1=oriB(11);
k2=oriB(12);
p1=oriB(13);
p2=oriB(14);
Sv=camformatB(4);
Sh=hvratio*Sv;
xrange=camformatB(1);
yrange=camformatB(2);

% calculate the rotational matrix for camera B
m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);

xd=Sh*(xPixB-xrange/2);
yd=Sv*(yrange/2-yPixB);
xud=xd;
yud=yd;

k=0;
while k<=6
	xx=xud-xp;
   yy=yud-yp;
   r2=(xx).^2+(yy).^2;
	dxr=k1*xx.*r2+k2*xx.*(r2.*r2);
	dyr=k1*yy.*r2+k2*yy.*(r2.*r2);
	dxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
	dyd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
	xud=xd+dxr+dxd;
   yud=yd+dyr+dyd;
   k=k+1;
end

	xn = (xud - xp)/c;
	yn = (yud - yp)/c;
   
   B2=[(m11+xn*m31) (m12+xn*m32) (m13+xn*m33);
      (m21+yn*m31) (m22+yn*m32) (m23+yn*m33)];
   C2=[(xn*m31+m11)*Xc+(xn*m32+m12)*Yc+(xn*m33+m13)*Zc;
      (yn*m31+m21)*Xc+(yn*m32+m22)*Yc+(yn*m33+m23)*Zc];
   
   
% least-squares solution for (X,Y,Z)
B=[B1;B2];
C=[C1;C2];
XYZ=(inv(B'*B))*B'*C;
Xtarg=XYZ(1);
Ytarg=XYZ(2);
Ztarg=XYZ(3);








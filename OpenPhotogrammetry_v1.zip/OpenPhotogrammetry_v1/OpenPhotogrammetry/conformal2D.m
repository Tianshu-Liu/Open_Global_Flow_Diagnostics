function xtrans = conformal2D(xin, theta, Txy, s)

% conformal 2D transformation
% xtrans = conformal2D(xin, theta, Txy, s)
% xt = s * m * xy + Txy
% where m is the rotation matrix [cos(theta) sin(theta;...
%                                -sin(theta) cos(theta)];
% xy is the column vector of x,y values from xin
% input xin is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% output xtrans is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% theta is rotation angle in degrees, + for CW
% Txy is a row or column vector of x- and y-translations Txy = [Tx; Ty];
% s is scalar scale

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

Nrows = size(xin,1);              % find number rows (# x,y coordinate pairs) of input array xin
xtrans = [];                      % initialize output array xtrans
theta = theta * pi / 180;         % convert input angle theta from degrees to radians
m = [cos(theta) sin(theta);...    % create 2 X 2 rotation matrix 
    -sin(theta) cos(theta)]; 
T = [Txy(1); Txy(2)];             % create 2 X 1 column vector (in case Txy passed as a row vector)
for i=1:Nrows                     % step through each coordinate pair of input array xin
    xy = xin(i,2:3)';             % create a 2 X 1 column vector for matrix calculations below
    xtrans(i,:) = s * m * xy + T; % matrix calculation to form column vector of x,y that is stored in xtrans as a row vector
end                               % end of loop steping through coordinate pairs
xtrans = [xin(:,1) xtrans];       % attach target numbers to 1st column of output array xtrans
return                            % end of function


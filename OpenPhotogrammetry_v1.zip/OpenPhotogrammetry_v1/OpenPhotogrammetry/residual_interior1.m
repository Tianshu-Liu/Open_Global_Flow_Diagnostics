function [dd]=residual_interior1(in_orien1,ex_orien,in_orien2,camformat,xyimag,xyzobj)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% residual of the calculated image coordinates (minimization of the first subset of the interior orientation)
% from the measured image coordimates when the relevant parameters are tentatively given.
%
% Inputs:
%       (1) 'xyzobj', the object space coordinates of a number of known targets in inches, which is a three-colunm file. 
%       (2) 'xyimag', the corresponding image centroids in pixels, which is a two-colunm file.
%       (3) 'camformat', the camera format, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (4) 'ex_orien', the approximate exterior orientation perameters for optimization, (omega,phi,kappa,Xc,Yc,Zc)
%       (5) 'in_orien1', the first subset of approximate interior orientation perameters for optimization, (c,xp,yp,Sh/Sv,K1)
%       (4) 'in_orien2', the second subset of approximate interior orientation perameters for optimization, (K2,P1,P2)
%
%  Outputs:
%       dd, the standard deviation of the calculated and measured coordinates of targets in the image plane
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% projection based on the collinearity equations
xm=xyzobj(:,1)*25.4;
ym=xyzobj(:,2)*25.4;
zm=xyzobj(:,3)*25.4;

omaga=ex_orien(1)*pi/180;
phi=ex_orien(2)*pi/180;
kappa=ex_orien(3)*pi/180;
xc=ex_orien(4)*25.4;
yc=ex_orien(5)*25.4;
zc=ex_orien(6)*25.4;
c=in_orien1(1); %mm
xp=in_orien1(2); %mm
yp=in_orien1(3); %mm
hv_ratio=in_orien1(4);
k1=in_orien1(5);

k2=in_orien2(1);
p1=in_orien2(2);
p2=in_orien2(3);


m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);
w=m31*(xm-xc)+m32*(ym-yc)+m33*(zm-zc);
wx=m11*(xm-xc)+m12*(ym-yc)+m13*(zm-zc);
wy=m21*(xm-xc)+m22*(ym-yc)+m23*(zm-zc);
x_image=xp-c*wx./w;
y_image=yp-c*wy./w;

r2=(x_image-xp).^2+(y_image-yp).^2;
xx=x_image-xp;
yy=y_image-yp;
deltaxr=k1*xx.*r2+k2*xx.*(r2.*r2);
deltayr=k1*yy.*r2+k2*yy.*(r2.*r2);
deltaxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
deltayd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
deltax=deltaxr+deltaxd;
deltay=deltayr+deltayd;

x_imaged=xp-deltax-c*wx./w;
y_imaged=yp-deltay-c*wy./w;


Sv=camformat(4);
Sh=hv_ratio*Sv;
x_range=camformat(1);
y_range=camformat(2);
x_imag=(xyimag(:,1)-x_range/2)*Sh;
y_imag=-(xyimag(:,2)-y_range/2)*Sv;

% the standard deviation of the calculated and measured image coordinates
dd=(sum((x_imaged-x_imag).^2+(y_imaged-y_imag).^2)/length(x_imaged))^(1/2);





% roiSelectExample
% illustrates usage of function roiSelect

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: October 2, 2006
% primary author: A. W. Burner

fprintf(1, '\ninteractive selection of regions of interest (roi)\n')
fprintf(1, 'single click outside of image to exit roi selection\n')
fprintf(1, '4 ways of accessing function roiSelect are illustrated\n')
fprintf(1, '1. [imgOut roi] = roiSelect(img); a workspace variable img = imread(''image2.tif'')\n')
fprintf(1, '2. [imgOut roi] = roiSelect(''image1.tif''); an image file\n')
fprintf(1, '3. [imgOut roi] = roiSelect; to open a get-file dialog box\n')
fprintf(1, '4. [imgOut roi] = roiSelect(img, ''reject''); to create an image with the roi''s missing\n')
fprintf(1, 'imgOut is the ouput image returned by the function with just the roi''s and a background of 0\n')
fprintf(1, 'or if the optional rejectFlag = ''reject'' imgOut is the original image with the roi''s missing\n')
input('\npress ''Enter'' to continue roiSelect example')

img = imread('image2.tif');  % create image variable in workspace from file
[imgOut roi] = roiSelect(img);        % call function with image variable
fprintf(1, '\nouput image is Workspace variable imgOut\n');
fprintf(1, 'roi array after calling roiSelect with a workspace image variable\n')
fprintf(1, '   xmin   ymin  width  height\n')
fprintf(1, '%6.0f %6.0f %6.0f %6.0f\n', roi')
input('\npress ''Enter'' to continue roiSelect example')

[imgOut roi] = roiSelect('image1.tif'); % call function with image file name
fprintf(1, '\nouput image is Workspace variable imgOut\n');
fprintf(1, 'roi array after calling roiSelect with a character string file name\n')
fprintf(1, '   xmin   ymin  width  height\n')
fprintf(1, '%6.0f %6.0f %6.0f %6.0f\n', roi')
input('\npress ''Enter'' to continue roiSelect example')

[imgOut roi] = roiSelect;  % call without input arguments
fprintf(1, '\nouput image is Workspace variable imgOut\n');
fprintf(1, 'roi array after calling roiSelect without an input argument\n')
fprintf(1, '   xmin   ymin  width  height\n')
fprintf(1, '%6.0f %6.0f %6.0f %6.0f\n', roi')

input('\npress ''Enter'' to continue roiSelect example')
[imgOut roi] = roiSelect(img, 'reject');  % call with rejectFlag set to 'reject'
fprintf(1, '\nouput image is Workspace variable imgOut\n');
fprintf(1, '(with roi''s missing from image\n');fprintf(1, 'roi array after calling roiSelect with rejectFlag set to ''reject''\n')
fprintf(1, '   xmin   ymin  width  height\n')
fprintf(1, '%6.0f %6.0f %6.0f %6.0f\n', roi')

fprintf(1, '\nEnter ''close all'' to close all figures\n')





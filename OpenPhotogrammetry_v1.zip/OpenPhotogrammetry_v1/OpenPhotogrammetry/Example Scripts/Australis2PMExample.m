% Australis2PMExample.m
% illustrates use of Australis2PM.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 29, 2006
% primary author: A. W. Burner


Azimuth = 10;  % set input angles in degrees
Elevation = 20;
Roll = 30;
OmegaPhiKappa = Australis2PM(Azimuth, Elevation, Roll);
fprintf(1,'%s\n', 'Examples of function Australis2PM') 
fprintf(1,'%s\n', ['  azim   elev     roll  omega   phi    kappa']);
fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', Azimuth, Elevation, Roll, OmegaPhiKappa);
fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', 0, 0, 0, Australis2PM(0, 0, 0));
fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', 90, 90, 90, Australis2PM(90, 90, 90));


% roiPolySelectExample
% illustrates usage of function roiPolyselect

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: October 2, 2006
% primary author: A. W. Burner

fprintf(1, '\ninteractive selection of polygon region of interest (roi)\n')
fprintf(1, 'press ''Enter'' to exit roi selection\n')
fprintf(1, '3 ways of accessing function roiPolySelect are illustrated\n')
fprintf(1, '1. imgOut = roiPolyselect(img); a workspace variable img = imread(''image2.tif'')\n')
fprintf(1, '2. imgOut = roiPolyselect(''image1.tif''); an image file\n')
fprintf(1, '3. imgOut = roiPolyselect(img, ''reject''); to create an image with the roi''s missing\n')
fprintf(1, 'imgOut is the ouput image returned by the function with just the polygon roi and a background of 0\n')
fprintf(1, 'or if the optional rejectFlag = ''reject'' imgOut is the original image with the polygon roi missing\n')
input('\npress ''Enter'' to continue roiPolyselect example')

img = imread('image2.tif');  % create image variable in workspace from file
imgOut = roiPolySelect(img);        % call function with image variable
fprintf(1, '\noutput image is Workspace variable imgOut\n');
input('\npress ''Enter'' to continue roiPolyselect example')

imgOut = roiPolySelect('image1.tif'); % call function with image file name
fprintf(1, '\nouput image is Workspace variable imgOut\n');
input('\npress ''Enter'' to continue roiPolyselect example')

imgOut = roiPolySelect(img, 'reject');  % call with rejectFlag set to 'reject'
fprintf(1, '\nouput image is Workspace variable imgOut\n');

fprintf(1, '\nEnter ''close all'' to close all figures\n')





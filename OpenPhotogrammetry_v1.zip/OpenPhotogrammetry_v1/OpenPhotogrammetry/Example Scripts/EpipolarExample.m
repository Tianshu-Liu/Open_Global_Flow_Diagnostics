%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script demonstrates the use of the functions 'Epipolarline_x.m' and 'Epipoplarline_y.m'
% to give an epipolar relation between two images (1 and 2) when the camera orientation parameters
% for both cameras are given. In normal cases where an epipolar line is not too vertical in the (x,y)
% image plane, 'Epipolarline_x.m' and 'Epipoplarline_y.m' shoild give the same results. 
%
% User should load the following files in the program:
%       (1) 'orientation1', the orientation perameters for camera A, (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%       (2) 'orientation2', the orientation perameters for camera B, (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%       (3) 'camformat1', the camera format for camera 1, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (4) 'camformat2', the camera format for camera 2, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%
%  Outputs:
%           The coordinates of an epipolar line in image 1 for a selected target in image 2.
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load the relevant files
load('orientation1.dat');
load('orientation2.dat');
load('camformat1.dat');
load('camformat2.dat');
load('xyzobj.dat');

% generate images
xyimag1=[];
xyimag2=[];
for i=1:length(xyzobj(:,1))
   [xyimag1add]=XYZ2xy(orientation1,xyzobj(i,:),camformat1);
   [xyimag2add]=XYZ2xy(orientation2,xyzobj(i,:),camformat2);
   xyimag1=[xyimag1;xyimag1add];
   xyimag2=[xyimag2;xyimag2add];
end

% select the target number
i=45;

% show the minimum point along the x-axis 
x=[xyimag1(i,1)-30:xyimag1(i,1)+30];
for j=1:length(x)
    normG(j)=EpipolarRelation_x(x(j),xyimag1(i,2),xyimag2(i,1),xyimag2(i,2),orientation1,orientation2,camformat1,camformat2);
end
figure(1);
plot(x,normG,'-k',xyimag1(i,1),0,'o');
xlabel('x (pixel)');
ylabel('norm(G)');
legend('norm(G) as a function of x','corresponding target at image 1');


% calculate the coordinates of the epipolar line
[x_epipo1_x,y_epipo1_x,normG_x]=EpipolarLine_x(xyimag2(i,1),xyimag2(i,2),orientation1,orientation2,camformat1,camformat2,20,500);
[x_epipo1_y,y_epipo1_y,normG_y]=EpipolarLine_y(xyimag2(i,1),xyimag2(i,2),orientation1,orientation2,camformat1,camformat2,20,450);

% plot the epipolar line and targets
figure(2);
plot(x_epipo1_x,y_epipo1_x,'r-',x_epipo1_y,y_epipo1_y,'g--',xyimag1(i,1),xyimag1(i,2),'*',xyimag1(:,1),xyimag1(:,2),'o');
title('Image 1');
xlabel('x (pixels)');
ylabel('y (pixels)');
legend('epipolar line based on x search','epipolar line based on y search','corresponding target','targets');

figure(3);
plot(xyimag2(i,1),xyimag2(i,2),'*',xyimag2(:,1),xyimag2(:,2),'o');
title('Image 2');
xlabel('x (pixels)');
ylabel('y (pixels)');
legend('selected target','targets');




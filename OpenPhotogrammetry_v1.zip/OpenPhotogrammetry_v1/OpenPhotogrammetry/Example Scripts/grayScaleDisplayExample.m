% grayscaleDisplayExample
% illustrates usage of function grayScaleDisplay

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 27, 2006
% primary author: A. W. Burner

img = imread('image2.tif');  % create image variable in workspace from file
grayScaleDisplay(img)        % call function with image variable

grayScaleDisplay('image1.tif') % call function with image file name

grayScaleDisplay % call function without input argument

fprintf(1, '\n3 figures have been created on top of each other\n')
fprintf(1, 'grab and move each to see separate figures\n')
fprintf(1, '1. grayScaleDisplay(img) a workspace variable img = imread(''image2.tif'')\n')
fprintf(1, '2. grayScaleDisplay(''image1.tif'') an image file\n')
fprintf(1, '3. grayScaleDisplay to open a get-file dialog box\n')
fprintf(1, 'interactive X,Y pixel and grayscale values are shown in the middle left of the figure\n')
fprintf(1, 'and in the lower left of the Pixel Region tool ')
fprintf(1, 'as the cursor is moved about\n\n')
fprintf(1, 'Enter ''close all'' to close all figures\n')



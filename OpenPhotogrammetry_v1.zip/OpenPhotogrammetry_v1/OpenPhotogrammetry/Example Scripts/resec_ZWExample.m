%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  This is a program (script) for demonstration of the use of the closed-form resection function 
%  'resec_ZW.m' to estimate the exterior orientation parameters (omega,phi,kappa,Xc,Yc,Zc),
%  based on four targets (two three-point groups).
% 
%  Inputs:(1) xyzobj.dat, the object space coordinates of a number of known targets in inches, which is a three-colunm file. 
%         (2) xyimag.dat, the corresponding image centroids in pixels, which is a two-colunm file.
%         (3) 'camformat', the camera format, a one-colunm file
%              [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%              such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%         (4) 'c', principal distance in mm
%        
%  Outputs: 
%           The correct exterior orientation parameters (omega,phi,kappa,Xc,Yc,Zc)
%          
%           For example, typical values of the exterior orientation parameters:
%           Omega: -56 deg.
%           Phi: -9 deg.
%           Kappa: -80 deg.
%           Xc: -2 in
%           Yc: 56 in
%           Zc: 36 in
%
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% load camera format, object-space coordinates (X,Y,Z), and orientation parameters
camformat=load('camformat.dat');
xyzobj_all=load('xyzobj.dat');
ori=load('ori0.dat');
c=28; % principal distance in mm

% generate the corresponding image coordinates
[xyimag_all]=XYZ2xy(ori,xyzobj_all,camformat);

% select the first group of three targets (numbering of targets should be counterclockwise)
xyimag1=[xyimag_all(1,:);xyimag_all(11,:);xyimag_all(7,:)];
xyzobj1=[xyzobj_all(1,:);xyzobj_all(11,:);xyzobj_all(7,:)];

% select the second group of three targets (numbering of targets should be counterclockwise)
xyimag2=[xyimag_all(1,:);xyimag_all(11,:);xyimag_all(8,:)];
xyzobj2=[xyzobj_all(1,:);xyzobj_all(11,:);xyzobj_all(8,:)];

% plot the selected targets
% camera format
x_range=camformat(1);
y_range=camformat(2);
Sv=camformat(4);
Sh=camformat(3);

% convert pixels to mm in the image coordinates
xim1=(xyimag1(:,1)-x_range/2)*Sh;
yim1=-(xyimag1(:,2)-y_range/2)*Sv;

xim2=(xyimag2(:,1)-x_range/2)*Sh;
yim2=-(xyimag2(:,2)-y_range/2)*Sv;
% plot 
figure(1);
hold;
plot(xim1,yim1,'o',xim2,yim2,'s');

% calculate the exterior orientation parameters for the two groups of three targets 
[exterior1]=resec_ZW(xyimag1,xyzobj1,camformat,c);
[exterior2]=resec_ZW(xyimag2,xyzobj2,camformat,c);

% full sets of the exterior orientation parameters
ext_groups=[exterior1 exterior2];

% select the groups of the exterior orientation parameters that are repeated;
% This is the correct set of the exterior orientation parameters
for i=1:length(ext_groups(1,:))
    for j=1:length(ext_groups(1,:))
        d=abs(ext_groups(:,i)-ext_groups(:,j));
        if d<0.01
            exterior_corr=ext_groups(:,i);
            break;
        end
    end
end

% plot the calculated and true image coordinates of three targets
ori_cal=[exterior_corr;ori(7:14)];
xyplot(camformat,ori_cal,xyimag1,xyzobj1,2);





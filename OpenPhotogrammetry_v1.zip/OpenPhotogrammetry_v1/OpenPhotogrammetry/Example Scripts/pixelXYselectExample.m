% pixelXYselectExample
% illustrates use of function pixelXYselect

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 1, 2006
% primary author: A. W. Burner

figure(1)   % select figure 1 to start
hold off    % don't keep old plots (if any)
clf         % clear figure
imshow('Sample Files\image1.tif')    % load sample image to figure(1)
title('Move cursor to desired locations and left click; Enter to terminate')  % place instructional title over image
fprintf(1,'************************************************************\n')   % print info to screen
fprintf(1,'* Example of quick call to pixelXYselect without arguments *\n')
fprintf(1,'*                 pixelXYselect                            *\n')
fprintf(1,'************************************************************\n')
pixelXYselect                                                                 % most simplist use of function

fprintf(1,'**********************************************************************\n') % print info to screen
fprintf(1,'* Example of quick call to pixelXYselect with starting target # only *\n')
fprintf(1,'*                 pixelXYselect(313)                                 *\n')
fprintf(1,'**********************************************************************\n')
pixelXYselect(313)                                                            % next most simplist use of function

fprintf(1,'*************************************************************************\n') % print info to screen
fprintf(1,'* Example of call to pixelXYselect with output to file ''centTemp2.txt''*\n')
fprintf(1,'*              pixelXYselect(''FileName'', ''centTemp2.txt'')           *\n')
fprintf(1,'*************************************************************************\n')
pixelXYselect('FileName', 'centTemp2.txt')                                    % specify file name
 
fprintf(1,'****************************************************************************************************\n')
fprintf(1,'* Example of call to pixelXYselect with output to file ''centTemp2.txt''                           *\n')
fprintf(1,'* with starting # 616, non-append to file, to figure(2)                                            *\n')
fprintf(1,'* pixelXYselect(''FileName'', ''centTemp2.txt'', ''Nstart'', 616, ''FileMode'', ''w'', ''fig'', 2) *\n')
fprintf(1,'****************************************************************************************************\n')
figure(2)
imshow('Sample Files\image2.tif')
pixelXYselect('FileName', 'centTemp2.txt','Nstart', 616, 'FileMode', 'w', 'fig', 2)  % specify file name, starting target #, file mode, and figure #


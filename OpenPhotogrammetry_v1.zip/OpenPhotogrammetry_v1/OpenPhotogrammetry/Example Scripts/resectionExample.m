% resectionExample
% illustrates usage of function resection

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: April 22, 2009
% primary author: A. W. Burner

clear all        % clear out any existing variables to avoid possible problems
XYZ = load('XYZ3.txt');  % load X, Y, Z data
camIn.c = 25;    % populate input argument structure camIn with example info
camIn.xp = 0;
camIn.yp = 0;
% camIn.omega = 3;
% camIn.phi = 2;
% camIn.kappa = 4;
% camIn.Xc = 5;
% camIn.Yc = 10;
% camIn.Zc = 15;
camIn.omega = -26;
camIn.phi = .1;
camIn.kappa = -89;
camIn.Xc = 5;
camIn.Yc = 10;
camIn.Zc = 35;
camIn.m = rotationMatrix(camIn.omega, camIn.phi, camIn.kappa);  % get rotation matrix for use in collinearity funcion next

camIn.xymm = collinearity(camIn, XYZ);   % create image plane data and place in structure field .xymm

fprintf(1, 'simulation cam structure\n')
disp(camIn)
[camIn.omega camIn.phi camIn.kappa camIn.Xc camIn.Yc camIn.Zc] = deal(0);  % set all but .c field to 0
camIn.m = eye(3);  % set .m field to identity matrix as well 
camIn.omega = -26.5;
camIn.phi = .05;
camIn.kappa = -88;
camIn.Xc = 4;
camIn.Yc = 11;
camIn.Zc = 34;
camOut = resection(camIn, XYZ);  % invoke resection function with image data without error
fprintf(1, 'ouput from resection function when no error present in input image data\n')
disp(camOut)

camIn.xymm(:, 2:3) = camIn.xymm(:, 2:3) + randn(size(camIn.xymm(:, 2:3))) * .003;  % add 0.003 random normal error to simulated data
camOut = resection(camIn, XYZ);   % invoke function resection with input image data wtih error 
fprintf(1, 'ouput from resection function with 0.003 error present in input image data\n')
disp(camOut)

% real data example
xypix = load('centroids3.txt');   % load centroids from file
Sh = 0.0075;   % horizontal pixel spacing for real data
Sv = 0.0075;
x0 = 320;   % note x0 and y0 in pixels for input arguments for pixel2mm
y0 = 240;
xymm = pixel2mm(xypix, Sh, Sv, x0, y0);  % convert from pixels to mm
camDistort.xs = 0;
camDistort.ys = 0;
camDistort.K1 = -2.481E-2;    % distortion parameters for real data set
camDistort.K2 = 6.0436E-4;
camDistort.K3 = 0;
camDistort.P1 = -3.0507E-4;
camDistort.P2 = 3.5323E-4;

% camDistort.K1 = -1.8E-2;    % distortion parameters for real data set
% camDistort.K2 = 0;
% camDistort.K3 = 0;
% camDistort.P1 = 0;
% camDistort.P2 = 0;

camIn.xymm = distortCorrect(xymm, camDistort);   % correct xymm data for distortion

camIn.c = 4.136;  % set .c field to known camera constant
[camIn.omega camIn.phi camIn.kappa camIn.Xc camIn.Yc camIn.Zc] = deal(0);  % set all but .c field to 0

camOut = resection(camIn, XYZ);  % invoke resection function
fprintf(1, 'ouput from resection function with real data input\n')
disp(camOut)

% camDistort.K1 = -0.0201;
% camDistort.K2 = 0;
% camDistort.K3 = 0;
% camDistort.P1 = -6.0792e-004;
% camDistort.P2 = 1.9633e-004;
% xymm = pixel2mm(xypix, Sh, Sv, x0, y0);  % convert from pixels to mm
% camIn.xymm = distortCorrect(xymm, camDistort);   % correct xymm data for distortion
% camOut = resection(camIn, XYZ);  % invoke resection function
% fprintf(1, 'ouput from resection function with real data input\n')
% disp(camOut)

% 
% XYZ = load('AMES54.STA');
% cam.xp = -0.1298;
% cam.yp = -0.0676;
% cam.c = 15.9676;
% cam.omega = -26.1297;
% cam.phi = 0.1062;
% cam.kappa = -89.0344;
% cam.m = rotationMatrix(cam.omega, cam.phi, cam.kappa);
% cam.Xc = 5.0622;
% cam.Yc = 9.6451;
% cam.Zc = 35.7048;
% cam.xymm = collinearity(cam, XYZ);
% camOut = resection(cam, XYZ);  % invoke resection function
% fprintf(1, 'ouput from resection function\n')
% disp(camOut)
% 
% cam.xymm(:,2:3) = cam.xymm(:,2:3) + randn(size(cam.xymm(:,2:3))) * .002;
% camOut = resection(cam, XYZ);  % invoke resection function
% fprintf(1, 'ouput from resection function\n')
% disp(camOut)
% 


 



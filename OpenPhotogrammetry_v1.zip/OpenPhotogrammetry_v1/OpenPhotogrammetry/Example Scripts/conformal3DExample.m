% conformal3DExample
% illustrates usage of function conformal3D

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 8, 2006
% primary author: A. W. Burner

X1 = [4  1  2  3;... % create input array X1 [pnt X Y Z] per row
      5  4  5  6;...
      6  7  8  8;...
      7 10 11 12];
fprintf('         input array X1\n')   % print to Comand Window
fprintf('    pnt   Xin   Yin   Zin\n') % print to Comand Window
disp(X1)  % display X1
s = 1.2;  % set scale
m = rotationMatrix(10, 20, 30); % get rotation matrix m with omega, phi, kappa = 10, 20, 30
Txyz = [2; 4; 6];  % set translation column vector to delX, delY, delZ = 2, 4, 6
X2 = conformal3D(X1, m, Txyz, s);  % invoke function conformal3D
fprintf('scale s = %g; omega, phi, kappa = 10, 20, 30\n',s)  % print to Command Window
fprintf('translation Txyz = %g %g %g\n', Txyz)
fprintf('output array X2 from function conformal3D\n')
fprintf('     pnt     Xtrans    Ytrans    Ztrans\n')
disp(X2)   % display output array X2

% resectionLocalMinExample
% illustrates usage of resectionLocalMin

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: February 11, 2007
% primary author: A. W. Burner

% set up input fields of structure cam with next 6 lines
cam.omega = 31;
cam.phi = -18;
cam.kappa = 44;
cam.Xc = 5;
cam.Yc = 10;
cam.Zc = 15;

disp('fields of input structure cam:')
disp(cam)
camLocalMin = resectionLocalMin(cam);  % invoke function (Zmean assumed = 0 for this example)
disp(' ')
disp('4 possible solutions for nearly planar objects:')
disp(camLocalMin)
camLocalMin = resectionLocalMin(cam, 5);  % invoke function (Zmean assumed = 5 for this example)
disp(' ')
disp('4 possible solutions for nearly planar objects (with Zmean = 5):')
disp(camLocalMin)
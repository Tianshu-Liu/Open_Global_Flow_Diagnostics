% overlayCentroidsBoxExample.m example script for function overlayCentroidsBox.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: January 18, 2007
% primary author: A. W. Burner

fprintf(1,'%s\n', 'Example using overlayCentroidsBox with input from file: Sample Files\centroids2.txt');
fprintf(1,'%s\n\n', 'and image file from: Sample Files\image2.tif');
fprintf(1, '%s', 'centroids from input file'); 
centroids = load('Sample Files\centroids2.txt') % get sample centroids from file with point numbers imbedded in file
fprintf(1, '%s\n', 'Note target # 4 is missing from file and not displayed on fig 1 or fig 2'); 
fprintf(1, '%s\n', 'Note targets # 5 and 6 become # 4 and 5 in fig 3 where target numbers are not entered explicitly'); 

figure(1)   % figure to show input centroid locations on an actual image
clf
hold off
iptsetpref('ImshowAxesVisible', 'on')  % show pixel axes when using imshow
imshow('Sample Files\image2.tif')      % show image 
title('Centroid locations and point numbers from file ''Sample Files\\centroids2.txt''')   % put title on plot
xlabel('Xpixel')    % label x-axis of plot
ylabel('Ypixel')    % label y-axis of plot
delx = 15;    % 1/2 width of box to be placed around centroid location on image
dely = 13;    % 1/2 height of box to be placed around centroid location on image
overlayCentroidsBox('Sample Files\centroids2.txt',delx,dely);   % function to display boxes around centroids
hold on   % donot clear figure before next plots
plot([0 100], [3 3], 'g', 'Linewidth', 2)    % next 4 lines draws green axes at approximate location of image origin
plot([100 90], [3 10], 'g', 'Linewidth', 2)
plot([3 3], [0 100], 'g', 'Linewidth', 2)
plot([3 10], [100 90], 'g', 'Linewidth', 2)
text(0,0,'(0, 0)', 'HorizontalAlignment', 'center', 'color', 'r', 'FontSize', 14)  % write (0, 0) at origin of pixel-space

figure(2)   % figure to show input centroid locations on an actual image
clf
hold off
iptsetpref('ImshowAxesVisible', 'on')  % show pixel axes when using imshow
imshow('Sample Files\image2.tif')      % show image 
title('Centroid locations and point numbers from array variable')
xlabel('Xpixel')
ylabel('Ypixel')
delx = 15;    % width of box to be placed around centroid location on image
dely = 13;    % height of box to be placed around centroid location on image
overlayCentroidsBox(centroids,delx,dely);   % function to display boxes around centroids variable
hold on
plot([0 100], [3 3], 'g', 'Linewidth', 2)    % next 4 lines draws green axes at approximate location of image origin
plot([100 90], [3 10], 'g', 'Linewidth', 2)
plot([3 3], [0 100], 'g', 'Linewidth', 2)
plot([3 10], [100 90], 'g', 'Linewidth', 2)
text(0,0,'(0, 0)', 'HorizontalAlignment', 'center', 'color', 'r', 'FontSize', 14)  % write (0, 0) at origin of pixel-space

figure(3)   % figure to show input centroid locations on an actual image
clf
hold off
iptsetpref('ImshowAxesVisible', 'on')  % show pixel axes when using imshow
imshow('Sample Files\image2.tif')     % show image 
title('Centroid locations and point numbers from array variable without target numbers (optional input argument specifies green overlay)')
xlabel('Xpixel')
ylabel('Ypixel')
delx = 15;    % width of box to be placed around centroid location on image
dely = 13;    % height of box to be placed around centroid location on image
% next line uses optional 4th input argument to specify green overlay plot instead of default red 
overlayCentroidsBox(centroids(:, [2 3]),delx,dely, 'g');   % function to display boxes around centroids ignoring target numbers
hold on
plot([0 100], [3 3], 'g', 'Linewidth', 2)    % next 4 lines draws green axes at approximate location of image origin
plot([100 90], [3 10], 'g', 'Linewidth', 2)
plot([3 3], [0 100], 'g', 'Linewidth', 2)
plot([3 10], [100 90], 'g', 'Linewidth', 2)
text(0,0,'(0, 0)', 'HorizontalAlignment', 'center', 'color', 'r', 'FontSize', 14)  % write (0, 0) at origin of pixel-space

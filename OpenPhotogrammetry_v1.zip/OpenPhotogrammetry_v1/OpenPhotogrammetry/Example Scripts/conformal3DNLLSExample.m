% conformal3DNLLSExample
% illustrates usage of function conformal3DNLLS

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 20, 2006
% primary author: A. W. Burner
tic


X1 = load('Sample Files\XYZ2.txt');
fprintf('         input array X1\n')   % print to Comand Window
fprintf('    pnt   Xin   Yin   Zin\n') % print to Comand Window
disp(X1)  % display X1
w = 10;
p = 20;
k = 33;
Tx = 10;
Ty = 15;
Tz = 20;
s = 1.1;

m = rotationMatrix(w, p, k); % get rotation matrix m with omega, phi, kappa = 10, 20, 33
Txyz = [Tx; Ty; Tz];  % set translation column vector to delX, delY, delZ = 2, 4, 6

X2 = conformal3D(X1, m, Txyz, s);  % invoke function conformal3D 
% X2 = conformal3Dinv(X1, m', Txyz, s);  % invoke function conformal3D **** (with m' to match conformal3DNLLS)
fprintf('scale s = %g; omega, phi, kappa = 10, 20, 30\n',s)  % print to Command Window
fprintf('translation Txyz = %g %g %g\n', Txyz)
fprintf('output array X2 from function conformal3D\n')
fprintf('     pnt     Xtrans    Ytrans    Ztrans\n')
disp(X2)   % display output array X2

% get data set of XYZ with scale of 1 for use later
X3 = conformal3D(X1, m, Txyz, 1);  % invoke function conformal3D
% -19.5756   -10.8308   -36.6415   -11.7412   -12.1522   -17.7099     0.9091
% Txyz = [  -11.7412   -12.1522   -17.7099];
% m = rotationMatrix(-19.5756,   -10.8308,   -36.6415); % get rotation matrix m with omega, phi, kappa = 10, 20, 30
% 
% X3 = conformal3Dinv(X2, m', Txyz, 0.9091) 
% X3-X1

[Start.omega Start.phi Start.kappa Start.Tx Start.Ty Start.Tz] = deal(0); % set all start values except scale s to 0
Start.s = 1;
[Start.omegaTol Start.phiTol Start.kappaTol Start.TxTol Start.TyTol Start.TzTol Start.sTol] = deal([]); % set all tolerances for solve for ([])
Parameter = conformal3DNLLS(X1([1:20 23:52],:), X2(5:52,:), Start); % invoke function
fprintf(1, 'No error in X, Y, Z of 2 input arrays\n')
fprintf(1, '               omega       phi       kappa       Tx         Ty         Tz           s         So\n')  % print to Command Window
fprintf(1, 'test input %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [w, p, k, Tx, Ty, Tz, s])
fprintf(1, 'start      %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Start.omega, Start.phi, Start.kappa, Start.Tx, Start.Ty, Start.Tz, Start.s])
fprintf(1, 'NLLS solve %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Parameter.omega, Parameter.phi, Parameter.kappa, Parameter.Tx, Parameter.Ty, Parameter.Tz, Parameter.s])
fprintf(1, 'NLLS std   %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n\n', [Parameter.omegastd, Parameter.phistd, Parameter.kappastd, Parameter.Txstd, Parameter.Tystd, Parameter.Tzstd, Parameter.sstd, Parameter.So])

X1(:,2:4) = X1(:,2:4) + randn(size(X1,1),3) * .1;  % put 0.1 error in each coordinate of X1
X2(:,2:4) = X2(:,2:4) + randn(size(X2,1),3) * .1;  % put 0.1 error in each coordinate of X2
Parameter = conformal3DNLLS(X1, X2, Start); % invoke function with error in X1 and X2
fprintf(1, '0.1 std error in X, Y, Z of 2 input arrays\n')
fprintf(1, '               omega       phi       kappa       Tx         Ty         Tz           s         So\n')  % print to Command Window
fprintf(1, 'test input %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [w, p, k, Tx, Ty, Tz, s])
fprintf(1, 'start      %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Start.omega, Start.phi, Start.kappa, Start.Tx, Start.Ty, Start.Tz, Start.s])
fprintf(1, 'NLLS solve %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Parameter.omega, Parameter.phi, Parameter.kappa, Parameter.Tx, Parameter.Ty, Parameter.Tz, Parameter.s])
fprintf(1, 'NLLS std   %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n\n', [Parameter.omegastd, Parameter.phistd, Parameter.kappastd, Parameter.Txstd, Parameter.Tystd, Parameter.Tzstd, Parameter.sstd, Parameter.So])

X3(:,2:4) = X3(:,2:4) + randn(size(X3,1),3) * .1;  % X3 has scale of 1 instead of 1.1 as in previous examples
Parameter = conformal3DNLLS(X1, X3, Start);   % invoke with start value of scale s still set to 1.1
fprintf(1, '0.1 std error in X, Y, Z of 2 input arrays, scale = 1\n')
fprintf(1, '               omega       phi       kappa       Tx         Ty         Tz           s         So\n')  % print to Command Window
fprintf(1, 'test input %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [w, p, k, Tx, Ty, Tz, 1])
fprintf(1, 'start      %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Start.omega, Start.phi, Start.kappa, Start.Tx, Start.Ty, Start.Tz, Start.s])
fprintf(1, 'NLLS solve %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Parameter.omega, Parameter.phi, Parameter.kappa, Parameter.Tx, Parameter.Ty, Parameter.Tz, Parameter.s])
fprintf(1, 'NLLS std   %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n\n', [Parameter.omegastd, Parameter.phistd, Parameter.kappastd, Parameter.Txstd, Parameter.Tystd, Parameter.Tzstd, Parameter.sstd, Parameter.So])

Start.s = 1; Start.sTol = 0;  % fix scale as a constant = 1 (with Tol = 0)
Parameter = conformal3DNLLS(X1, X3, Start);  % invoke function with scale as a constant instead of a variable
fprintf(1, '0.1 std error in X, Y, Z of 2 input arrays, scale = 1 (fixed at 1 for NLLS)\n')
fprintf(1, '               omega       phi       kappa       Tx         Ty         Tz           s         So\n')  % print to Command Window
fprintf(1, 'test input %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [w, p, k, Tx, Ty, Tz, 1])
fprintf(1, 'start      %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Start.omega, Start.phi, Start.kappa, Start.Tx, Start.Ty, Start.Tz, Start.s])
fprintf(1, 'NLLS solve %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Parameter.omega, Parameter.phi, Parameter.kappa, Parameter.Tx, Parameter.Ty, Parameter.Tz, Parameter.s])
fprintf(1, 'NLLS std   %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n\n', [Parameter.omegastd, Parameter.phistd, Parameter.kappastd, Parameter.Txstd, Parameter.Tystd, Parameter.Tzstd, Parameter.sstd, Parameter.So])

Start.s = 1.1; Start.sTol = 0;   % set scale s to 1.1 constant
[Start.TxTol Start.TyTol Start.TzTol Start.sTol] = deal(0);  % set Tx Ty Tz as constants with values in next 3 lines
Start.Tx = 10;
Start.Ty = 15;
Start.Tz = 20;
% [Start.omegaTol Start.phiTol Start.kappaTol Start.TxTol Start.TyTol Start.TzTol Start.sTol] = deal(0);
Parameter = conformal3DNLLS(X1, X2, Start);  % invoke function with s, Tx, Ty, Tz fixed to original values
fprintf(1, '0.1 std error in X, Y, Z of 2 input arrays (Tx, Ty, Tz fixed to 10, 15, 20 for NLLS)\n')
fprintf(1, '               omega       phi       kappa       Tx         Ty         Tz           s         So\n')  % print to Command Window
fprintf(1, 'test input %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [w, p, k, Tx, Ty, Tz, s])
fprintf(1, 'start      %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Start.omega, Start.phi, Start.kappa, Start.Tx, Start.Ty, Start.Tz, Start.s])
fprintf(1, 'NLLS solve %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Parameter.omega, Parameter.phi, Parameter.kappa, Parameter.Tx, Parameter.Ty, Parameter.Tz, Parameter.s])
fprintf(1, 'NLLS std   %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n\n', [Parameter.omegastd, Parameter.phistd, Parameter.kappastd, Parameter.Txstd, Parameter.Tystd, Parameter.Tzstd, Parameter.sstd, Parameter.So])

% set all Start.parameterTol = 0 to be treated as constants; function will
% then return input Start values in Parameter without any computations
[Start.omegaTol Start.phiTol Start.kappaTol Start.TxTol Start.TyTol Start.TzTol Start.sTol] = deal(0);
fprintf(1', 'in next example all Start.parameterTol''s = 0 indicating all are constants so there is nothing to solve for\n')
fprintf(1', 'Output structure ''Parameter'' returns input values without computation since\n')
Parameter = conformal3DNLLS(X1, X2, Start)
fprintf(1, '               omega       phi       kappa       Tx         Ty         Tz           s         So\n')  % print to Command Window
fprintf(1, 'test input %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [w, p, k, Tx, Ty, Tz, s])
fprintf(1, 'start      %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Start.omega, Start.phi, Start.kappa, Start.Tx, Start.Ty, Start.Tz, Start.s])
fprintf(1, 'NLLS solve %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n', [Parameter.omega, Parameter.phi, Parameter.kappa, Parameter.Tx, Parameter.Ty, Parameter.Tz, Parameter.s])
fprintf(1, 'NLLS std   %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n\n', [Parameter.omegastd, Parameter.phistd, Parameter.kappastd, Parameter.Txstd, Parameter.Tystd, Parameter.Tzstd, Parameter.sstd, Parameter.So])

toc


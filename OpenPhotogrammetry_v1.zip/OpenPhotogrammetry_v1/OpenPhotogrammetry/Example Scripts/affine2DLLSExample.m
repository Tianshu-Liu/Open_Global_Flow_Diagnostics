% affine2DLLSExample
% illustrates usage of affine2DLLS

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 11, 2006
% primary author: A. W. Burner

Sxy1 = [1.1; 1.2];   % create scale vector for 2 axes
Thetaxy1 = [10; 11]; % create rotation angle vector for 2 axes

xin = [5 1 1;...    % create input array xin
       6 3 4;...
       7 5 6;...
       8 9 10;...
       9 8  8;...
       10 9 9];
fprintf('    input array xin\n') % print to Comand Window
fprintf('    pnt   xin   yin\n') % print to Comand Window
disp(xin)  % display xin
Txy1 = [5; 10]; % set translation terms to Tx = 5; Ty = 10; 
xtrans = affine2D(xin, Thetaxy1, Txy1, Sxy1);  % invoke function affine2D
fprintf('xscale = %g; yscale = %g; thetax = %g; thetay = %g\n', Sxy1(1), Sxy1(2), Thetaxy1(1), Thetaxy1(2))  % print to Command Window
fprintf('translation Txyz = %g %g\n', Txy1)
fprintf('output array xtrans from function affine2D\n')
fprintf('     pnt     xtrans    ytrans\n')
disp(xtrans)   % display output array xtrans

% call function next line with 3rd row of xin (target # 7) and 4th row of xtrans (target # 8)  missing 
[Thetaxy, Txy, Sxy, So] = affine2DLLS(xin([1:2 4:6],:), xtrans([1:3 5:6],:));
fprintf(1,'results from function affine2DLLS when target numbers are missing\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', So)
fprintf(1,'   thetax      std        Tx       std        Sx       std\n')  % print to Command Window
fprintf(1,'   thetay      std        Ty       std        Sy       std\n')
disp([Thetaxy, Txy, Sxy])    % display output parameters from funcion affineDLLS
% call function next line with no target numbers missing 
[Thetaxy, Txy, Sxy, So] = affine2DLLS(xin, xtrans);
fprintf(1,'results from function affine2DLLS when no target numbers are missing\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', So)
fprintf(1,'   thetax      std        Tx       std        Sx       std\n')  % print to Command Window
fprintf(1,'   thetay      std        Ty       std        Sy       std\n')
disp([Thetaxy, Txy, Sxy])    % display output parameters from funcion affineDLLS

xinErr = [xin(:, 1) xin(:,2:3) + randn(size(xin(:,2:3))) * .01];          % create input data with 0.01 std error
xtransErr = [xtrans(:, 1) xtrans(:,2:3) + randn(size(xin(:,2:3))) * .01]; % create input data with 0.01 std error
[Thetaxy, Txy, Sxy, So] = affine2DLLS(xinErr, xtransErr);
fprintf(1,'results from function affine2DLLS with 0.01 std error in 2 input coordinate sets\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', So)
fprintf(1,'   thetax      std        Tx       std        Sx       std\n')  % print to Command Window
fprintf(1,'   thetay      std        Ty       std        Sy       std\n')
disp([Thetaxy, Txy, Sxy])    % display output parameters from funcion affineDLLS




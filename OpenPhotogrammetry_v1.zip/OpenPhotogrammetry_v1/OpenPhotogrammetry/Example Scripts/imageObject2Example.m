% imageObject2Example
% example of imageObject2

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date:October 27, 2006
% primary author: A. W. Burner

% populate input argument structure camIn
camIn.f = 25;
camIn.obj = 1000;
camIn.img = [];  % variable to be solved for
disp('camIn')
disp(camIn)
camOut = imageObject2(camIn);  % call function
disp('camOut after passing camIn to function imageObject2')
disp('image distance ''img'' is calculated')
disp(camOut)

%
camIn.img = 25.641;
camIn.f = [];  % variable to be solved for
disp('camIn')
disp(camIn)
camOut = imageObject2(camIn);  % call function
disp('camOut after passing camIn to function imageObject2')
disp('focal length ''f'' is calculated')
disp(camOut)

camIn.obj = [];  % variable to be solved for
camIn.f = 25;
disp('camIn')
disp(camIn)
camOut = imageObject2(camIn);  % call function
disp('camOut after passing camIn to function imageObject2')
disp('object distance ''obj'' is calculated')
disp(camOut)
imageObject    % call imageObject GUI for trials with these values

disp('imageObject GUI is called to experiment with these (or other) values')
% end of imageObject2Example


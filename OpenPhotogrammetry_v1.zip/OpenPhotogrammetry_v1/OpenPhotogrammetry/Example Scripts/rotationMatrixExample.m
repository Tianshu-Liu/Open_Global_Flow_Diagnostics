% rotationMatrixExample.m example script for function rotationMatrix.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 16, 2006
% primary author: A. W. Burner

fprintf(1,'%s\n\n', 'rotationMatrixExample.m example script for function rotationMatrix.m')

omega = 0;
phi = 0;
kappa = 0;
fprintf(1, 'm = rotationMatrix(%3d, %3d, %3d) assumes degrees', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa)

omega = 0;
phi = 0;
kappa = 0;
fprintf(1, 'm = rotationMatrix(%3d, %3d, %3d, ''radians'') assumes radians', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa, 'radians')

omega = 90;
phi = 90;
kappa = 90;
fprintf(1, 'm = rotationMatrix(%3d, %3d, %3d) assumes degrees', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa)

omega = pi /2;
phi = pi /2;
kappa = pi /2;
fprintf(1, 'm = rotationMatrix(pi/2, pi/2, pi/2, ''radians'') assumes radians', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa, 'radians')

omega = 180;
phi = 180;
kappa = 180;
fprintf(1, 'm = rotationMatrix(%3d, %3d, %3d) assumes degrees', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa)

omega = pi;
phi = pi;
kappa = pi;
fprintf(1, 'm = rotationMatrix(pi, pi, pi, ''radians'') assumes radians', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa, 'radians')


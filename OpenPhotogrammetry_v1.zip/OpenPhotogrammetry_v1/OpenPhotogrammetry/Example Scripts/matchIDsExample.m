% matchIDsExample
% illustrates usage of function matchIDs

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: January 17, 2007
% primary author: A. W. Burner

centID = load('cent.txt');        % N X 3 array in file (correct IDs, but only approximate x,y centroids)
centCentroid = load('cent2.txt'); % N X 5 array in file (incorrect IDs, but correct x,y centroids) (only 1st 3 columns used in function matchID below)
centMatch = matchIDs(centID, centCentroid);  % invoke matchIDs function

disp('centID has correct IDs, but only approximate x, y centroids')
disp(centID)
disp('') % skip line 
disp('centCentroid has incorrect IDs, but correct x, y centroids')
disp(centCentroid)
disp('') % skip line
disp('centMatch has correct IDs and correct x, y centroids')
disp(centMatch)



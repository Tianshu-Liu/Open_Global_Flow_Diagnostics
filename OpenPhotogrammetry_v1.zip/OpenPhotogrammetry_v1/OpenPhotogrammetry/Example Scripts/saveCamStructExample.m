% saveCamStructExample.m

% testing example for function saveCamStruct.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 24, 2006
% primary author: A. W. Burner

% cam is a camera parameter structure as follows
cam.c = 25;
cam.xp = .5;
cam.yp = -.5;
m = rotationMatrix(30, 40 ,50);
cam.m = m;
cam.Xc = 10;
cam.Yc = 20;
cam.Zc = 30;

fileName = 'Sample Files\camStruct.txt';
fid = saveCamStruct(fileName, cam);
if fid > -1
    fprintf(1,'after saving ''SampleFiles\\camStruct.txt'' with saveCamStructExample\n')
    fprintf(1,'type(''SampleFiles\\camStruct.txt'') yields:')
    type(fileName)
else                 % else print out error message if path not found
    fprintf(1, '%s\n', 'Sample Files folder not found; folder ''Sample Files'' should be in current active MATLAB folder')
    fprintf(1, '%s\n', 'Example scripts should be run from ''Photogrammetry Toolbox'' folder')
end



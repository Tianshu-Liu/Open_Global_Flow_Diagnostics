% loadCamStructExample.m

% testing example for function loadCamStruct.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 24, 2006
% primary author: A. W. Burner

fileName = 'Sample Files\cam1.txt';
if exist(fileName, 'file')    % test to see if file exists (or can be found with specified path)
    fprintf(1,'camera parameter structure ''cam'' outputted\n')
    fprintf(1,'by cam = loadCamStruct(fileName) where filename = ''Sample Files\\cam1.txt''')
    cam = loadCamStruct(fileName)
else                 % else print out error message if file not found
    fprintf(1, '%s\n', 'Sample Files\cam1.txt not found; folder ''Sample Files'' should be in current active MATLAB folder')
    fprintf(1, '%s\n', 'Example scripts should be run from ''Photogrammetry Toolbox'' folder\n')
end

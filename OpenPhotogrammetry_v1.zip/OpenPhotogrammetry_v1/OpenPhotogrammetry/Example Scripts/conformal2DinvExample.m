% conformal2DinvExample
% illustrates the usage of function conformal2Dinv

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 8, 2006
% primary author: A. W. Burner

xin = [5 1 1;...
       6 3 4;...
       7 5 6;...
       8 9 10];
fprintf('    input array xin\n')   % print to Comand Window
fprintf('    pnt   xin   yin\n') % print to Comand Window
disp(xin)  % display xin

theta = 10;    % set theta to 10 degrees
Txy = [5; 10]; % set translation terms to Tx = 5; Ty = 10; 
s = 1.2;       % set scale to 1.2
xtrans = conformal2D(xin, theta, Txy, s);  % invoke conformal transformation
fprintf('scale s = %g; theta = %g\n', s, theta)  % print to Command Window
fprintf('translation Txyz = %g %g\n', Txy)
fprintf('output array xtrans from function conformal2D\n')
fprintf('     pnt     xtrans    ytrans\n')
disp(xtrans)   % display output array xtrans
xtransINV = conformal2Dinv(xtrans, theta, Txy, s);  % invoke conformal transformation
fprintf('output array with xtrans above as input to function conformal2Dinv\n')
fprintf('function conformal2Dinv returns original set of x, y data xin\n')
fprintf('     pnt     xtransINV    ytransINV\n')
disp(xtransINV)   % display output array xtrans


% conformal2DNLLSExample
% illustrates usage of conformal2DNLLS

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 16, 2006
% primary author: A. W. Burner

s1 = 1.1;    % create scale vector
theta1 = 10; % create rotation angle

xin = [5 1 1;...    % create input array xin
       6 3 4;...
       7 5 6;...
       8 9 10;...
       9 8  8;...
       10 9 9];
fprintf('    input array xin\n') % print to Comand Window
fprintf('    pnt   xin   yin\n') % print to Comand Window
disp(xin)  % display xin
Txy1 = [5; 10]; % set translation terms to Tx = 5; Ty = 10; 
xtrans = conformal2D(xin, theta1, Txy1, s1);  % invoke function conformal2D
fprintf('scale = %g; theta = %g;\n', s1, theta1)  % print to Command Window
fprintf('translation Txyz = %g %g\n', Txy1)
fprintf('output array xtrans from function conformal2D\n')
fprintf('     pnt     xtrans    ytrans\n')
disp(xtrans)   % display output array xtrans

Start.s = 1.1;       % populate Start structure needed as inut argument for conformal2DNLLS 
Start.sTol = [];
Start.theta = 10;
Start.thetaTol = [];
Start.Tx = 5;
Start.TxTol = [];
Start.Ty = 10;
Start.TyTol = [];

% call function next line with 3rd row of xin (target # 7) and 4th row of xtrans (target # 8)  missing 
Parameter = conformal2DNLLS(xin([1:2 4:6],:), xtrans([1:3 5:6],:), Start);  % invoke NLLS function
fprintf(1,'results from function conformal2DNLLS when targets 7 & 8 are missing\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', Parameter.So)
fprintf(1,'theta = %g; stdtheta = %g; Tx = %g; stdTx = %g; Ty = %g; stdTy = %g\n', Parameter.theta, Parameter.thetastd, Parameter.Tx, Parameter.Txstd, Parameter.Ty, Parameter.Tystd)  % print to Command Window
fprintf(1,'s = %g; stds = %g\n\n', Parameter.s, Parameter.sstd)  % print to Command Window
% call function next line with no target numbers missing 

Parameter = conformal2DNLLS(xin, xtrans, Start);  % invoke NLLS function
fprintf(1,'results from function conformal2DNLLS when no target numbers are missing\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', Parameter.So)
fprintf(1,'theta = %g; thetastd = %g; Tx = %g; Txstd = %g; Ty = %g; stdTy = %g\n', Parameter.theta, Parameter.thetastd, Parameter.Tx, Parameter.Txstd, Parameter.Ty, Parameter.Tystd)  % print to Command Window
fprintf(1,'s = %g; sstd = %g\n\n', Parameter.s, Parameter.sstd)  % print to Command Window

xinErr = [xin(:, 1) xin(:,2:3) + randn(size(xin(:,2:3))) * .01];          % create input data with 0.01 std error
xtransErr = [xtrans(:, 1) xtrans(:,2:3) + randn(size(xin(:,2:3))) * .01]; % create input data with 0.01 std error
[theta, Txy, s, So] = conformal2DLLS(xinErr, xtransErr);  % invoke LLS function
fprintf(1,'results from function conformal2DLLS with 0.01 std error in 2 input coordinate sets\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', So)
fprintf(1,'theta = %g; thetastd = %g; Tx = %g; Txstd = %g; Ty = %g; Tystd = %g\n', theta(1), theta(2), Txy(1, 1), Txy(1, 2), Txy(2,1), Txy(2,2))  % print to Command Window
fprintf(1,'s = %g; sstd = %g\n\n', s(1), s(2))  % print to Command Window
Parameter = conformal2DNLLS(xinErr, xtransErr, Start);  % invoke NLLS function
fprintf(1,'results from function conformal2DNLLS with 0.01 std error in 2 input coordinate sets\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', Parameter.So)
fprintf(1,'theta = %g; thetastd = %g; Tx = %g; Txstd = %g; Ty = %g; Tystd = %g\n', Parameter.theta, Parameter.thetastd, Parameter.Tx, Parameter.Txstd, Parameter.Ty, Parameter.Tystd)  % print to Command Window
fprintf(1,'s = %g; sstd = %g\n\n', Parameter.s, Parameter.sstd)  % print to Command Window

Start.theta = 10; Start.thetaTol = 0;   % set start value of theta to 10 deg and do not solve for theta (Tol = 0)
Parameter = conformal2DNLLS(xinErr, xtransErr, Start);  % invoke NLLS function
fprintf(1,'theta fixed at 10 degrees and not solved for in these results\n')
fprintf(1,'results from function conformal2DNLLS with 0.01 std error in 2 input coordinate sets\n')
fprintf(1,'standard deviation of unit weight, So = %g\n', Parameter.So)
fprintf(1,'theta = %g; thetastd = %g; Tx = %g; Txstd = %g; Ty = %g; Tystd = %g\n', Parameter.theta, Parameter.thetastd, Parameter.Tx, Parameter.Txstd, Parameter.Ty, Parameter.Tystd)  % print to Command Window
fprintf(1,'s = %g; sstd = %g\n\n', Parameter.s, Parameter.sstd)  % print to Command Window

[Start.thetaTol Start.TxTol Start.TyTol Start.sTol] = deal(0);
Parameter = conformal2DNLLS(xinErr, xtransErr, Start)  % invoke NLLS function


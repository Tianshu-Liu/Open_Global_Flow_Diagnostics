% distortSolveExample
% example of distortSolve

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: February 15, 2009
% primary author: A. W. Burner

XYZ = load('Sample Files/XYZ3.txt');  % load X, Y, Z data (121 planar targets)

cam = [];  % initialize cam structure
% example setup data follows
cam.c = 25.123; % set camera constant c to 25.123
cam.xp = 0;     % set xp
cam.yp = 0;     % set yp
[cam.omega cam.phi cam.kappa] = deal(0); % set omega, phi, kappa all to 0
cam.m = rotationMatrix(cam.omega, cam.phi, cam.kappa); % needed for collinearity
cam.Xc =11;     % set Xc to 11
cam.Yc =8.5;    % set Yc to 8.5
cam.Zc =90;     % set Yc to 8.5

xymm = collinearity(cam, XYZ);  % create ideal (no distort) image data with collinearity
cam.m = []; % cam.m not needed for call to distortSolve

% populate distortion structure to be applied to undistorted image data generated above
camDistortExample.xs = 0;
camDistortExample.ys = 0;
camDistortExample.K1 = -1.8E-3; % all coefficents except K1 set to 0
camDistortExample.K2 = 0;
camDistortExample.K3 = 0;
camDistortExample.P1 = 0;
camDistortExample.P2 = 0;
fprintf(1,'distortion structure used to create image data\n')
disp(camDistortExample)

xymmDist = distortApply(xymm, camDistortExample); % apply distortion from structure to undistorted image data

cam.xymm = xymmDist;  % set image data of structure cam to distorted values
cam.xymm(:, 2:3) = cam.xymm(:, 2:3) + randn(size(xymmDist(:, 2:3))) * 0.001; % add 0.001 (1 standard deviation) random error to x and y image coordinates

[solve4.K1 solve4.K2 solve4.K3 solve4.P1 solve4.P2] = deal(0); % set all solve4 fields to 0 (no solve)
solve4.K1 = 1;  % set K1 field to 1 to solve for K1 only

camDistortStart.xs = 0;  % populate input argument start value structure
camDistortStart.ys = 0;
camDistortStart.K1 = 0;  % all start values set to 0, including K1 for input to distortSolve
camDistortStart.K2 = 0;
camDistortStart.K3 = 0;
camDistortStart.P1 = 0;
camDistortStart.P2 = 0;
Niterations = 40;       % iterate 40 times
useLastResults = 1;     % ignore file temp4distortSolve.mat for input
fprintf(1,'distortion found from distortSolve (%d iterations) with 0.001 std error in image data\n', Niterations)
camDistort = distortSolve(cam, camDistortStart, XYZ, Niterations, solve4, useLastResults); % solve for K1
disp(camDistort) % display output distortion structure from function distortSolve

xypix = load('Sample Files/centroids3.txt');   % load centroids from file
Sh = 0.0075;   % horizontal pixel spacing for real data
Sv = 0.0075;
x0 = 320;   % note x0 and y0 in pixels for input arguments for pixel2mm
y0 = 240;
cam.xymm = pixel2mm(xypix, Sh, Sv, x0, y0);  % convert from pixels to mm
cam.c = 4.136;  % set .c field to known camera constant
[cam.omega cam.phi cam.kappa cam.Xc cam.Yc cam.Zc] = deal(0);  % set all but .c field to 0
useLastResults = 0;     % ignore file temp4distortSolve.mat for input
[solve4.K1 solve4.K2 solve4.K3 solve4.P1 solve4.P2] = deal(0); % set all solve4 fields to 0 (no solve)
solve4.K1 = 1;  % set K1 field to 1 to solve for K1 only
solve4.P1 = 1;  % set K1 field to 1 to solve for K1 only
solve4.P2 = 1;  % set K1 field to 1 to solve for K1 only
% solve4.K2 = 1;  % set K1 field to 1 to solve for K1 only

camDistort = distortSolve(cam, camDistortStart, XYZ, Niterations, solve4, useLastResults); % solve for K1
disp(camDistort) % display output distortion structure from function distortSolve

[solve4.K1 solve4.K2 solve4.K3 solve4.P1 solve4.P2] = deal(1); % set all solve4 fields to 0 (no solve)
solve4.K3 = 0;
solve4.K2 = 0;
camDistort = distortSolve(cam, camDistortStart, XYZ, Niterations, solve4, useLastResults); % solve for K1
disp(camDistort) % display output distortion structure from function distortSolve


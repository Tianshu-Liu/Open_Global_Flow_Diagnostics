% distortCorrectExample.m
% illustrates usage of function distortCorrect

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: February 15, 2009
% primary author: A. W. Burner

xymm = [ 1 2;...    % establish 4 X 2 array xymm without explicit target numbers
         3 4;...
         5 6;...
         7 8];
K1 = -2e-4;         % set values for distortion parameters
K2 = +2e-7;
K3 = -2e-9;
P1 = -2e-5;
P2 = 3e-6;
xs = .5;          % set values for point of symmetry for distortion
ys = -.4;

camDistort.xs = xs;  % fill in fields of input structure camDistor from varibles right above
camDistort.ys = ys;
camDistort.K1 = K1;
camDistort.K2 = K2;
camDistort.K3 = K3;
camDistort.P1 = P1;
camDistort.P2 = P2;
camDistort.PP = 'sksks';


fprintf(1,'xymm array without target numbers\n')
fprintf(1,'%7.3f %7.3f\n', xymm')
fprintf(1,'apply distortion to xymm without target numbers\n');
xymmDist = distortApply(xymm, camDistort);   % calling function with array without target numbers
fprintf(1,'%7d %7.3f %7.3f\n', xymmDist')
fprintf(1, 'call function distortCorrect with distorted input to arrive back to original undistorted data\n')
xymmCorr = distortCorrect(xymmDist, camDistort);
fprintf(1,'%7d %7.3f %7.3f\n', xymmCorr')
xymmCorr2 = distortCorrect('Sample Files\mmDist1.txt', camDistort);
fprintf(1,'correct distortion for file ''Sample Files\\mmDist1.txt''\n');
fprintf(1,'which contains the last set of distorted image coordinates above\n');
fprintf(1,'%7d %7.3f %7.3f\n', xymmCorr2')
 
% examples of pinchushion and barrel distortion plotted in Fig 1
% establish image (2 column version) coordinates for a 5 X 5 box
xymm3 = [(-5 * ones(1,11))' (-5:5)'; (5 * ones(1,11))' (-5:5)'; (-5:5)' (5 * ones(1,11))'; (-5:5)' (-5 * ones(1,11))'];
camDistort2.xs = 0;      % fill in fields of input structure camDistort2
camDistort2.ys = 0;
camDistort2.K1 = 5e-3;   % positive radial distortion -> pincushion (large value for emphasis)
camDistort2.K2 = 0;
camDistort2.K3 = 0;
camDistort2.P1 = 0;
camDistort2.P2 = 0;

figure(1)
hold off        % remove any previous plotting
clf             % clear figure
subplot(1,2,1)  % position subplot to left of figure
xymmDist3 = distortApply(xymm3, camDistort2);  % apply distortion using structure camDistort2
xymmCorr3 = distortCorrect(xymmDist3, camDistort2);
plot(xymmDist3(:,2), xymmDist3(:,3), 'o')           % plot undistorted input coordinates with blue (default color) circles
axis equal      % set equal scale for x- and y-axes 
hold on         % keep previous plotting while applying new plotting
plot(xymmCorr3(:,2), xymmCorr3(:,3), '+r')   % plot distorted image coordinates with red crosses   
axis([-10 10 -10 10])              % set axes to +- 10 for nice plot aspect ratio
title('K1 > 0; Pincushion')        % set title for 1st subplot
legend('distorted input', 'corrected ouput','Location','best') % put legend on figure
xlabel('x')
ylabel('y')

h=subplot(1,2,2);      % position subplot to right of figure and repeat similar to left plot, but with K1 < 0
camDistort2.K1 = -5e-3;   % negative radial distortion -> barrel (large magnitude for emphasis)
xymmDist4 = distortApply(xymm3, camDistort2);  % structure camDistort2 now has K1 field = -5e-3 instead of 5e-3
xymmCorr4 = distortCorrect(xymmDist4, camDistort2);
plot(xymmDist4(:,2), xymmDist4(:,3), 'o')
axis equal
hold on
plot(xymmCorr4(:,2), xymmCorr4(:,3), '+r')
axis([-10 10 -10 10])
title('K1 < 0; Barrel') 
xlabel('x')
ylabel('y')
legend(h,'off')  % to remove legend from 2nd plot

fprintf(1,'see Fig 1 for example of effect of sign convention and correction of distortion\n');




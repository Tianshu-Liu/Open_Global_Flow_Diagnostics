% TransposeAnglesExample
% illustrates usage of function TransposeAngles

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 18, 2006
% primary author: A. W. Burner

Parameter.omega = 10; % set input argument structure omega
Parameter.phi = 20;   % set input argument structure phi
Parameter.kappa = 33; % set input argument structure kappa

Angle = TransposeAngles(Parameter); % call function
fprintf(1,'input  [omega phi kappa] = [%g %g %g] degrees\n', Parameter.omega, Parameter.phi, Parameter.kappa)
m = rotationMatrix(Parameter.omega, Parameter.phi, Parameter.kappa); % get rotation matrix of input angles 
mNewAngles = rotationMatrix(Angle.omega, Angle.phi, Angle.kappa);    % ge rotation matrix of output angles
fprintf(1,'rotation matrix with [omega phi kappa] = [%g %g %g]\n', Parameter.omega, Parameter.phi, Parameter.kappa)
disp(m)
fprintf(1,'transpose of rotation matrix with [omega phi kappa] = [%g %g %g]\n', Parameter.omega, Parameter.phi, Parameter.kappa)
disp(m')
fprintf(1,'rotation matrix with [omega phi kappa] = [%g %g %g]\n', Angle.omega, Angle.phi, Angle.kappa)
disp(mNewAngles)
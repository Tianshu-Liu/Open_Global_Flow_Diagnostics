% conformalAltSolExample
% illustrates usage of function conformalAltSol

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 19, 2006
% primary author: A. W. Burner

X1 = [4  1  2  3;... % create input array X1 [pnt X Y Z] per row
      5  4  5  6;...
      6  7  8  8;...
      7 10 11 12];
fprintf('         input array X1\n')   % print to Comand Window
fprintf('    pnt   Xin   Yin   Zin\n') % print to Comand Window
disp(X1)  % display X1
s = 1.1;  % set scale
m = rotationMatrix(10, 20, 33); % get rotation matrix m with omega, phi, kappa = 10, 20, 30
Txyz = [10; 15; 20];  % set translation column vector to delX, delY, delZ = 2, 4, 6
X2 = conformal3D(X1, m, Txyz, s);  % invoke function conformal3D
fprintf('scale s = %g; omega, phi, kappa = 10, 20, 33\n',s)  % print to Command Window
fprintf('translation Txyz = %g %g %g\n', Txyz)
fprintf('output array X2 from function conformal3D\n')
fprintf('     pnt     Xtrans    Ytrans    Ztrans\n')
disp(X2)   % display output array X2

Parameter.omega = 10;   % populate structure Parameter for function call to conformalaltSol below
Parameter.phi = 20;
Parameter.kappa = 33;
Parameter.Tx = 10;
Parameter.Ty = 15;
Parameter.Tz = 20;
Parameter.s = 1.1;
Alternate = conformalAltSol(Parameter);  % invoke function to get alternate solution
s3 = Alternate.s;
m3 = rotationMatrix(Alternate.omega, Alternate.phi, Alternate.kappa);
Txyz3 = [Alternate.Tx, Alternate.Ty, Alternate.Tz];
X3 = conformal3Dinv(X1, m3, Txyz3, s3);  % invoke function conformal3Dinv with alternate parameter values
fprintf('scale s = %g; omega, phi, kappa = %g, %g, %g\n', Alternate.s, Alternate.omega, Alternate.phi, Alternate.kappa)  % print to Command Window
fprintf('translation [Tx Ty Tz] = [%g %g %g]\n', Alternate.Tx, Alternate.Ty, Alternate.Tz)
fprintf('output array X3 from function conformal3Dinv with alternate solution\n')
fprintf('     pnt     Xtrans    Ytrans    Ztrans\n')
disp(X3)   % display output array X2
fprintf(1,'max error for X3 - X2 is %g\n\n', max(max(X3 - X2)))

fprintf(1,' param  input   output\n')
fprintf(1, ' omega %7.3f %7.3f\n   phi %7.3f %7.3f\n kappa %7.3f %7.3f \n    Tx %7.3f %7.3f\n    Ty %7.3f %7.3f\n    Tz %7.3f %7.3f\n     s %7.3f %7.3f\n', Parameter.omega, Alternate.omega, Parameter.phi, Alternate.phi, Parameter.kappa, Alternate.kappa, Parameter.Tx, Alternate.Tx, Parameter.Ty, Alternate.Ty, Parameter.Tz, Alternate.Tz, Parameter.s, Alternate.s)

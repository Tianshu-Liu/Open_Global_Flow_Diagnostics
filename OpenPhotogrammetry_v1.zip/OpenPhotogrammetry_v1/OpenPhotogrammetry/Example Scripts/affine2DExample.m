% affine2DExample
% illustrates usage of function affine2D

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 9, 2006
% primary author: A. W. Burner

Sxy = [1.1; 1.2];   % create scale vector for 2 axes
Thetaxy = [10; 11]; % create rotation angle vector for 2 axes

xin = [5 1 1;...    % create input array xin
       6 3 4;...
       7 5 6;...
       8 9 10];
fprintf('    input array xin\n') % print to Comand Window
fprintf('    pnt   xin   yin\n') % print to Comand Window
disp(xin)  % display xin
Txy = [5; 10]; % set translation terms to Tx = 5; Ty = 10; 
xtrans = affine2D(xin, Thetaxy, Txy, Sxy);  % invoke function affine2D
fprintf('xscale = %g; yscale = %g; thetax = %g; thetay = %g\n', Sxy(1), Sxy(2), Thetaxy(1), Thetaxy(2))  % print to Command Window
fprintf('translation Txyz = %g %g\n', Txy)
fprintf('output array xtrans from function affine2D\n')
fprintf('     pnt     xtrans    ytrans\n')
disp(xtrans)   % display output array xtrans
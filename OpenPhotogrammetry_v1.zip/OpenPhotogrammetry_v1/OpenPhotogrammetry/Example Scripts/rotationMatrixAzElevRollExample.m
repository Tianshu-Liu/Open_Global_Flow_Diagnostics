% rotationMatrixAzElevRollExample.m example script for function rotationMatrixAzElevRoll.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 16, 2006
% primary author: A. W. Burner

fprintf(1,'%s\n\n', 'rotationMatrixAzElevRollExample.m example script for function rotationMatrixAzElevRoll.m')

Azimuth = 0;
Elevation = 0;
Roll = 0;
fprintf(1, 'm = rotationMatrixAzElevRoll(%3d, %3d, %3d) assumes degrees\n', Azimuth, Elevation, Roll)
m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll);
disp(m)

Azimuth = 0;
Elevation = 0;
Roll = 0;
fprintf(1, 'm = rotationMatrixAzElevRoll(%3d, %3d, %3d, ''radians'') assumes radians\n', Azimuth, Elevation, Roll)
m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll, 'radians');
disp(m)

Azimuth = 90;
Elevation = 90;
Roll = 90;
fprintf(1, 'm = rotationMatrixAzElevRoll(%3d, %3d, %3d) assumes degrees\n', Azimuth, Elevation, Roll)
m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll);
disp(m)

Azimuth = pi /2;
Elevation = pi /2;
Roll = pi /2;
fprintf(1, 'm = rotationMatrixAzElevRoll(pi/2, pi/2, pi/2, ''radians'') assumes radians\n')
m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll, 'radians');
disp(m)

Azimuth = 180;
Elevation = 180;
Roll = 180;
fprintf(1, 'm = rotationMatrixAzElevRoll(%3d, %3d, %3d) assumes degrees\n', Azimuth, Elevation, Roll)
m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll);
disp(m)

Azimuth = pi;
Elevation = pi;
Roll = pi;
fprintf(1, 'm = rotationMatrixAzElevRoll(pi, pi, pi, ''radians'') assumes radians\n')
m = rotationMatrixAzElevRoll(Azimuth, Elevation, Roll, 'radians');
disp(m)


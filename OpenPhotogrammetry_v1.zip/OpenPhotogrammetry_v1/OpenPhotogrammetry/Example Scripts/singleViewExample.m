% singleViewExample
% illustrates usage of function singleView

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 5, 2006
% primary author: A. W. Burner

clear all    % clear out variables in Workspace
cam.notes1 = 'input structure cam can have more fields';   % example of populating input structure cam
cam.notes2 = 'than necessary for function, such as comments like these';    % with more fields than function calls for
cam.c  = 25;   % populate input structure cam
cam.xp = .5;
cam.yp = -.5;
cam.m  = rotationMatrix(3, 4, 5);   % call function rotationMatrix with omega, phi, kappa = 30, 40, 50 deg
cam.Xc = 3;
cam.Yc = 4;
cam.Zc = 7;

XYZinput = [1  0   20  70;...   % create XYZ N X 4 array
            2  1   30  90;...
            3  5   30 110;...
            4 -5   -5 120;...
            5  5   20 100;...
            6  6   10  90;...
            7  7   14 100];
fprintf(1, '%s\n', '        XYZinput array:')
disp(XYZinput)
   
xymm = collinearity(cam, XYZinput);   % call collinearity function to create image coordinates xymm

XYZ.pnt = XYZinput(:,1);  % put target numbers in pnt field of input structure XYZ

% in the code segment below the coordinates to be solved for are set to []
% in the input structure XYZ before invoking singleView
% no image or object error so should reproduce XYZinput data
fprintf(1,'solve for XY; no image or object error\n')
XYZ.X = []; XYZ.Y = []; XYZ.Z = XYZinput(:,4); XYZsv = singleView(cam, xymm, XYZ); disp(XYZsv)
fprintf(1,'solve for XZ; no image or object error\n')
XYZ.X = []; XYZ.Y = XYZinput(:,3); XYZ.Z=[]; XYZsv = singleView(cam, xymm, XYZ); disp(XYZsv)
fprintf(1,'solve for YZ; no image or object error\n')
XYZ.X = XYZinput(:,2); XYZ.Y = []; XYZ.Z=[]; XYZsv = singleView(cam, xymm, XYZ); disp(XYZsv)
fprintf(1,'solve for X; no image or object error\n')
fprintf(1,'standard deviation in 5th column should be 0 since no image or object error\n')
XYZ.X = []; XYZ.Y = XYZinput(:,3); XYZ.Z = XYZinput(:,4); XYZsv = singleView(cam, xymm, XYZ); disp(XYZsv)
fprintf(1,'solve for Y; no image or object error\n')
fprintf(1,'standard deviation in 5th column should be 0 since no image or object error\n')
XYZ.X = XYZinput(:,2); XYZ.Y = []; XYZ.Z = XYZinput(:,4); XYZsv = singleView(cam, xymm, XYZ); disp(XYZsv)
fprintf(1,'solve for Z; no image or object error\n')
fprintf(1,'standard deviation in 5th column should be 0 since no image or object error\n')
XYZ.X = XYZinput(:,2); XYZ.Y = XYZinput(:,3); XYZ.Z = []; XYZsv = singleView(cam, xymm, XYZ); disp(XYZsv)

% remove target numbers 2, 4, 6 from xymm
xymmMissingPnt = xymm([1 3 5 7],:,:); 
% add 1 std error (normal) of 0.001 to xymmMissingPnt
xymmMissingPnt(:,[2 3]) = xymmMissingPnt(:,[2 3]) + randn(size(xymmMissingPnt,1),2) * .001;
fprintf(1, '%s\n', 'xymm missing points 2, 4, 6 before invoking singleView; image & object error of 1 std = 0.001 & 0.1 respectively:')
fprintf(1,'standard deviation in 5th column should be > 0 since both image and object have error\n')
% add 1 std error (normal) of 0.1 to XYZ.X and XYZ.Y
XYZ.X = XYZ.X + randn(size(XYZ.X, 1), 1) * .1;
XYZ.Y = XYZ.Y + randn(size(XYZ.Y, 1), 1) * .1;
XYZsv = singleView(cam, xymmMissingPnt, XYZ);
disp(XYZsv)


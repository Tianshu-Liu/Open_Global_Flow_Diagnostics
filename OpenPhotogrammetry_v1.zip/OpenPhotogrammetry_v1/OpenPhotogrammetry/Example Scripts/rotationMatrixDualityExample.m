% rotaionMatrixDualityExample.m example script for function rotaionMatrixDuality.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: November 27, 2006
% primary author: A. W. Burner

% fprintf(1,'%s\n\n', 'rotaionMatrixDualityExample.m example script for function rotaionMatrixDuality.m')

omega = 0;
phi = 0;
kappa = 0;
fprintf(1, 'm = rotationMatrix(%4g, %4g, %4g)\n', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa);
disp(m)
[omegaDual, phiDual, kappaDual] = rotationMatrixDuality(omega, phi, kappa);
fprintf(1, 'mDuality = rotationMatrix(%4g, %4g, %4g)\n', omegaDual, phiDual, kappaDual)
m2 = rotationMatrix(omegaDual, phiDual, kappaDual);
disp(m)
disp('m - mDuality')
disp(m-m2)

omega = 10;
phi = -20;
kappa = 30;
fprintf(1, 'm = rotationMatrix(%4g, %4g, %4g)\n', omega, phi, kappa)
m = rotationMatrix(omega, phi, kappa);
disp(m)
[omegaDual, phiDual, kappaDual] = rotationMatrixDuality(omega, phi, kappa);
fprintf(1, 'mDuality = rotationMatrix(%4g, %4g, %4g)\n', omegaDual, phiDual, kappaDual)
m2 = rotationMatrix(omegaDual, phiDual, kappaDual);
disp(m)
disp('m - mDuality')
disp(m-m2)

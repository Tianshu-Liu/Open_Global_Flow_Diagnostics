%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a testing program (script) for deterimining the object space coordinates (X,Y,Z) 
% of a group of targets using the function 'xy2XYZ.m'.  
%

% load the files of the orientation parameters and formats for cameras 1 and 2. load the target field
load('orientation1.dat');
load('orientation2.dat');
load('camformat1.dat');
load('camformat2.dat');
load('xyzobj.dat');

% generate the targets in the images 1 and 2
xyimag1=[];
xyimag2=[];
for i=1:length(xyzobj(:,1))
	[xyimag1add]=XYZ2xy(orientation1,xyzobj(i,:),camformat1);
    [xyimag2add]=XYZ2xy(orientation2,xyzobj(i,:),camformat2);
    xyimag1=[xyimag1;xyimag1add];
    xyimag2=[xyimag2;xyimag2add];
end

% calculate the (X,Y,Z) coordinates using 'xy2XYZ.m'
XYZ=[];
for i=1:length(xyimag1(:,1))
[Xtarg,Ytarg,Ztarg]=xy2XYZ(xyimag1(i,1),xyimag1(i,2),xyimag2(i,1),xyimag2(i,2),orientation1,orientation2,camformat1,camformat2);
XYZadd=[Xtarg Ytarg Ztarg];
XYZ=[XYZ;XYZadd];
end

figure(1);
plot3(xyzobj(:,1),xyzobj(:,2),xyzobj(:,3),'o',XYZ(:,1),XYZ(:,2),XYZ(:,3),'+');
xlabel('X (in)');
ylabel('Y (in)');
zlabel('Z (in)');
grid;

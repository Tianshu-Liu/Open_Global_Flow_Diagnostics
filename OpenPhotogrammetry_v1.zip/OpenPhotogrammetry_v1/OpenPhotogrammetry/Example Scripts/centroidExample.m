% centroidExample
% illustrates usage of function centroid

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: February 16, 2007
% primary author: A. W. Burner

% example 1
img = imread('Sample Files\image1.tif'); % set variable img to digital image
figure(1)   % select figure 1
clf         % clear figure
hold off    % don't save previous plotting before the next plots
imshow(img) % put image img in figure
overlayCentroidsBox('Sample Files\centroids1.txt',8,8) % overlay 16 X 16 boxes at start centroid locations on image
title('''Sample Files\\centroids1.txt'' overlaid on ''Sample Files\\image1.tif'' ; centroids = green +') % put title above image
centStart = load('Sample Files\centroids1.txt');                           % load start values for centroid computations
fprintf(1,'image: Sample Files\\image1.tif; start locations: Sample Files\\centroids1.txt\n') % print info to Command Window
fprintf(1,'start locations for centroid computation\n')                                       % print info to Command Window
fprintf(1,'           %g %g %g\n', centStart')   % print start values to Comman Window (%g picks best format)

Nrows = size(centStart,1); % get number of rows of start value array (for loop below)
xyTot = [];                % initialize xyTot array to be populated in loop 
for i=1:Nrows              % step through start values for # of rows
    pnt = centStart(i,1);  % set target number
    x = centStart(i,2);    % set x to x-value in array
    y = centStart(i,3);    % set y to y-value in array
    xy = centroid(img, x, y, 8, 8); % compute centroid at x, y with 16 X 16 roi
    xyTot = [xyTot; [pnt xy]];      % populate xyTot with target #, xcent, ycent
end                                 % end of loop
fprintf(1,'\n          computed centroids\n')  % print to Command Window
fprintf(1,'           %g %g %g\n', xyTot')     % print xyTot to Command Window; transpose needed for order of fprintf
hold on
plot(xyTot(:,2), xyTot(:,3), '+g') 


% similar example 2 without removing background gray scale
img2 = imread('Sample Files\image2.tif');  % repeat with a second image and start file
figure(2)
clf
hold off
imshow(img2)
delx = 16;
dely = 12;
overlayCentroidsBox('Sample Files\centroids2.txt', delx, dely)
title('''Sample Files\\centroids2.txt'' overlaid on ''Sample Files\\image2.tif'' ; centroids = green +')
centStart2 = load('Sample Files\centroids2.txt');
fprintf(1,'\nimage: Sample Files\\image2.tif; start locations: Sample Files\\centroids2.txt\n')
fprintf(1,'start locations for centroid computation\n')
fprintf(1,'           %g %g %g\n', centStart2')

Nrows2 = size(centStart2,1);
xyTot2 = [];
for i=1:Nrows2
    pnt = centStart2(i,1);
    x = centStart2(i,2);
    y = centStart2(i,3);
    xy = centroid(img2,x, y, delx, dely);
    xyTot2 = [xyTot2; [pnt xy]];
end
fprintf(1,'\ncomputed centroids without removing background\n')
fprintf(1,'           %g %g %g\n', xyTot2') 

% example 3 removing background gray scale with same image and start values as example 2 above
xyTot3 = [];
for i=1:Nrows2
    pnt = centStart2(i,1);
    x = centStart2(i,2);
    y = centStart2(i,3);
    Gback = findBackground(img2, x, y, delx, dely); % use function to get Gback to pass to centroid function in next line
    xy = centroid(img2,x, y, delx, dely, Gback);
    xyTot3 = [xyTot3; [pnt xy]];                    %xyTot3 has background removed
end
fprintf(1,'\ncomputed centroids after removing background with function findBackground\n')
fprintf(1,'           %g %g %g\n', xyTot3') 

fprintf(1,'\ncentroids w.o. background - centroids w. background\n')
fprintf(1,'           %d %7.3f %7.3f\n', [xyTot3(:,1) xyTot3(:,2)-xyTot2(:,2) xyTot3(:,3)-xyTot2(:,3)]') 
% transpose needed in line above due to column order priority of fprintf
hold on
plot(xyTot3(:,2), xyTot3(:,3), '+g') 


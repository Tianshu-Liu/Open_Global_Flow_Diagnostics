% intersectionExample
% illustrates usage of function intersection

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: April 22, 2009
% primary author: A. W. Burner

clear all
XYZref = load('XYZ3.txt');    % load X Y Z data from file
camdata=[];                                   % initialize camdata   
camdata1 = load('camdata1.txt'); % get camera 1 data from file
camdata2 = load('camdata2.txt'); % get camera 2 data from file
camdata(1,:) = camdata1;                      % set 1st row of camdata to 1st camera
camdata(2,:) = camdata2;                      % set 2nd row of camdata to 2nd camera

cam = [];    % initialize cam so multiple runs of intersectionExample will not use cam as defined later in this script   
for i = 1:2  % step through camdata to populate structure array cam
    cam(i).c = camdata(i,5);   % c from column 5
    cam(i).xp = 0;             % set xp to 0
    cam(i).yp = 0;             % set yp to 0
    omega = camdata(i,6);      % omega from column 6
    phi   = camdata(i,7);      % phi from column 7
    kappa = camdata(i,8);      % kappa from column 8
    m = rotationMatrix(omega, phi, kappa); % compute rotation matrix
    cam(i).m = m;              % put m in cam structure array
    cam(i).Xc = camdata(i,9);  % Xc from column 9
    cam(i).Yc = camdata(i,10); % Yc from column 10
    cam(i).Zc = camdata(i,11); % Zc from column 11  
    cam(i).xymm = collinearity(cam(i), XYZref); % create image coordinates (xymm) from function collinearity
end         % end of loop stepping through camdata

% cam(2).xymm(6,2:3) = NaN
[XYZ] = intersection(cam);    % solve for X Y Z with function intersection

% stop

maxError = max(max(abs(XYZ(:,1:4) - XYZref)));  % find max error compared to the input values for X Y Z
fprintf(1, 'maximum error is %g comparing input and output XYZ\n', maxError) % print to Comman Window
fprintf(1,'with all 121 targets for both cameras\n\n')
cam(1).xymm = cam(1).xymm([3:33 40:118], :);  % throw away points 1:2, 34:39 119:121 for camera 1
cam(2).xymm = cam(2).xymm([5:28 33:100], :);  % throw away points 1:4, 29:32 101:121 for camera 2
[XYZ] = intersection(cam);    % solve for X Y Z with function intersection (with missing point numbers)
ind = intersect(XYZ(:,1), XYZref(:,1));  % find index of points common to ouput XYZ and input XYZref
ind2 = [];     % initialize ind2
for i = 1: length(ind)  % step through index ind to create ind2 index of points in XYZref common to XYZ
    ind2 = [ind2; find(XYZref(:,1) == ind(i))];  % find common points
end   % end of loop
maxError = max(max(abs(XYZ(:,1:4) - XYZref(ind2,:))));  % find max error compared to the input values for X Y Z 
fprintf(1, 'maximum error is %g comparing input and output XYZ\n', maxError) % print to Command Window
fprintf(1, 'with the following missing target point numbers\n')              % print to Command Window
fprintf(1, 'cam1: 1-2, 34-39, 119-121\n')                                    % print to Command Window
fprintf(1, 'cam2: 1-4, 29-31, 101-121\n')                                    % print to Command Window

i = 3;  % create camera 3 data for 3rd element of structure array cam ~ between cam 1 & 2
cam(i).c = 4.07;
cam(i).xp = 0;
cam(i).yp = 0;
omega = 43;
phi   = 0;
kappa = 0;
m = rotationMatrix(omega, phi, kappa);
cam(i).m = m;
cam(i).Xc = 10;
cam(i).Yc = -14;
cam(i).Zc = 20;
cam(i).xymm = collinearity(cam(i), XYZref);  % create image data for 3rd camera (with all 121 targets)

[XYZ] = intersection(cam);    % solve for X Y Z with function intersection (3 cameras)

ind = intersect(XYZ(:,1), XYZref(:,1));  % find index of points common to ouput XYZ and input XYZref
ind2 = [];     % initialize ind2
for i = 1: length(ind)  % step through index ind to create ind2 index of points in XYZref common to XYZ
    ind2 = [ind2; find(XYZref(:,1) == ind(i))];  % find common points
end   % end of loop
maxError = max(max(abs(XYZ(:,1:4) - XYZref(ind2,:)))); % find max absolute error compared to input
fprintf(1, '\n3 camera case\n')    % print to Command Window
fprintf(1, 'maximum error is %g comparing input and output XYZ\n', maxError)
fprintf(1, 'with the following missing target point numbers\n')
fprintf(1, 'cam1: 1-2, 34-39, 119-121\n')
fprintf(1, 'cam2: 1-4, 29-31, 101-121\n')
fprintf(1, 'cam3: none\n')

for i = 1:3  % add 0.003 error to each image coordinate
    cam(i).xymm(:, 2:3) = cam(i).xymm(:, 2:3) + randn(size(cam(i).xymm(:, 2:3))) * .003;
end

[XYZ] = intersection(cam);    % solve for X Y Z with function intersection (3 cameras with error)
XYZ3cam = XYZ;
[XYZ2cam] = intersection(cam(1:2));    % solve for X Y Z with function intersection (2 cameras with error)
ind = intersect(XYZ(:,1), XYZref(:,1));
ind2 = [];
for i = 1: length(ind)
    ind2 = [ind2; find(XYZref(:,1) == ind(i))];
end
maxError = max(max(abs(XYZ(:,1:4) - XYZref(ind2,:))));
stdError = std(XYZ(:,2:4) - XYZref(ind2,2:4));    % compute standard deviation of error compared to input X Y Z
stdLLS = mean(XYZ(:,5:7));  % get mean standard deviations from the linear least squares reducion
fprintf(1, '\n0.003 error in image coordinates for all 3 cameras\n')  % print to Command Window
fprintf(1, 'maximum error is %g comparing input and output XYZ\n', maxError)
fprintf(1, 'std dev of error in [X Y Z] is [%7.4f %7.4f %7.4f]\n', stdError)
fprintf(1, 'mean std from LLS   [X Y Z] is [%7.4f %7.4f %7.4f]\n', stdLLS)
fprintf(1, 'with the following missing target point numbers\n')
fprintf(1, 'cam1: 1-2, 34-39, 119-121\n')
fprintf(1, 'cam2: 1-4, 29-31, 101-121\n')
fprintf(1, 'cam3: none\n')

i = 4;   % create data for camera 4 (cam(4))
cam(i).c = 4.07;
cam(i).xp = 0;
cam(i).yp = 0;
omega = 36;
phi   = 0;
kappa = 0;
m = rotationMatrix(omega, phi, kappa);
cam(i).m = m;
cam(i).Xc = 9;
cam(i).Yc = -11;
cam(i).Zc = 25;
cam(i).xymm = collinearity(cam(i), XYZref);  % create image data for cam(4)

i = 5;   % create data for camera 5 (cam(5))
cam(i).c = 4.13;
cam(i).xp = 0;
cam(i).yp = 0;
omega = 50;
phi   = 0;
kappa = 0;
m = rotationMatrix(omega, phi, kappa);
cam(i).m = m;
cam(i).Xc = 11;
cam(i).Yc = -17;
cam(i).Zc = 16;
cam(i).xymm = collinearity(cam(i), XYZref);  % create image data for cam(5)

for i = 4:5  % add 0.003 error to image data for cam(4) and cam(5)
    cam(i).xymm(:, 2:3) = cam(i).xymm(:, 2:3) + randn(size(cam(i).xymm(:, 2:3))) * .003;
end

[XYZ] = intersection(cam);    % solve for X Y Z with function intersection (5 cameras with error)
maxError = max(max(abs(XYZ(:,2:4) - XYZref(:,2:4))));  
stdError = std(XYZ(:,2:4) - XYZref(:,2:4));
stdLLS = mean(XYZ(:,5:7)); 
fprintf(1, '\n5 camera example\n')
fprintf(1, '0.003 error in image coordinates for all 5 cameras\n') % print to Command Window
fprintf(1, 'maximum error is %g comparing input and output XYZ\n', maxError)
fprintf(1, 'std dev of error in [X Y Z] is [%7.4f %7.4f %7.4f]\n', stdError)
fprintf(1, 'mean std from LLS   [X Y Z] is [%7.4f %7.4f %7.4f]\n', stdLLS)
fprintf(1, 'with the following missing target point numbers\n')
fprintf(1, 'cam1: 1-2, 34-39, 119-121\n')
fprintf(1, 'cam2: 1-4, 29-31, 101-121\n')
fprintf(1, 'cam3, cam4, cam5: none\n')


%  IRVE intersection example black targets on a white background
camdata = [];
cam = [];
camdata(:,1) = load('camdataTop4thCut.txt');
camdata(:,2) = load('camdataBottom4thCut.txt');
img(:,:,1) = load('centMeanTop.dat');
img(:,:,2) = load('centMean2Bottom.dat');

for N = 1:2
    Sh = camdata(12,N);
    Sv = camdata(12,N);
    x0 = camdata(1,N);
    y0 = camdata(2,N);

    cam(N).c= camdata(5,N);

    cam(N).xp= 0;
    cam(N).yp= 0;

    omega = camdata(6,N);
    phi = camdata(7,N);
    kappa = camdata(8,N);

    m = rotationMatrix(omega, phi, kappa);
    cam(N).m = m;

    xymmDist(:,:,N) = pixel2mm(img(:,:,N), Sh, Sv, x0, y0);
    distort.xs = 0;
    distort.ys = 0;
    distort.K1=	camdata(18,N);
    distort.K2=camdata(19,N);
    distort.K3=camdata(20,N);
    distort.P1=camdata(21,N);
    distort.P2=camdata(22,N);
    xymmCorr=distortCorrect(xymmDist(:,:,N), distort);
    cam(N).xymm=xymmCorr;

    cam(N).Xc = camdata(9,N);
    cam(N).Yc = camdata(10,N);
    cam(N).Zc = camdata(11,N);
end
[XYZirve] = intersection(cam);
fprintf(1, '\nblack targets on white background IRVE intersection\n')
fprintf(1, 'means of Xsig  Ysig  Zsig\n')
fprintf(1, '        %5.3f %5.3f %5.3f\n', (mean(XYZirve(:,5:7))))


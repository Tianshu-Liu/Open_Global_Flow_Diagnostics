% cameraConstantExample
% illustrates usage of function cameraConstant

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 30, 2006
% primary author: A. W. Burner

clear all        % clear out any existing variables to avoid possible problems
XYZ = load('Sample Files/XYZ3.txt');  % load X, Y, Z data (121 planar targets)

cam(1).c = 25.123;  % set camera constant c to 25.123
cam(1).xp = 0;      % set xp  to 0
cam(1).yp = 0;      % set yp  to 0
[cam(1).omega cam(1).phi cam(1).kappa] = deal(0); % set omega, phi, kappa all to 0
cam(1).m = rotationMatrix(cam(1).omega, cam(1).phi, cam(1).kappa);  % needed for collinearity
cam(1).Xc =11;       % set Xc to 11
cam(1).Yc =8.5;      % set Yc to 8.5
for i = 1:5          % step through 5 times
    cam(i) = cam(1); % set 5 identical elements of structure array cam fields c -> Yc
    cam(i).Zc = 29 + i; % set Zc for elements 1:5 to 30:34
    cam(i).xymm = collinearity(cam(i), XYZ);  % set image coordinates for each of the 5 elements
end                  % end of 5 element step through loop

% fixed input above %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[cam.c] = deal(25);  % set field .c to 25 for all 5 elements before calling cameraConstant

c = cameraConstant(cam, XYZ);  % invoke function cameraConstant
fprintf(1, '\n5 step Z-diplacement case\n')
fprintf(1, 'c-exact = 25.123, but passed to cameraConstant as 25\n')
fprintf(1, 'No error in image coordinates\n')
disp(c)

for i= 1:5   % loop to put random normal error of 1 sigma = 0.005 in image coordinates
    cam(i).xymm(:, 2:3) = cam(i).xymm(:, 2:3) + randn(size(cam(i).xymm(:, 2:3))) * .005;
end

c = cameraConstant(cam, XYZ);  % invoke function cameraConstant with 0.005 image error
fprintf(1, '0.005 error in image coordinates\n')
disp(c)

c = cameraConstant(cam(1:2), XYZ);  % invoke function cameraConstant with only 2 steps
fprintf(1, '2 step Z-displacement so standard deviation returned as 0\n')
disp(c)

XYZ2 = load('Sample Files/XYZ4.txt');  % load X, Y, Z data for 3-step cal plate with 54 targets
cam(1).c = 25.123;  % set cam(1).c back to 25.123 before calling collinearity
cam(1).xymm = collinearity(cam(1), XYZ2);  % set image coordinates for 1st element of cam
cam(1).xymm(:, 2:3) = cam(1).xymm(:, 2:3) + randn(size(cam(1).xymm(:, 2:3))) * .005;  % add random normal error of 1 sigma = 0.005 in image coordinates
cam(1).c = 25;  % set cam(1).c to 25 before calling cameraConstant
c = cameraConstant(cam(1), XYZ2);  % invoke function cameraConstant for 3-step cal plate using only a single element structrure cam
fprintf(1, '3 step calibration plate, only 1 element of cam structure passed to function\n')
fprintf(1, '0.005 error in image coordinates\n')
disp(c)


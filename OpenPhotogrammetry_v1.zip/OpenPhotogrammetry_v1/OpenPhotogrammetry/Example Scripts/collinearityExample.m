% collinearityExample.m

% testing example for function collinearity

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 24, 2006
% primary author: A. W. Burner

cam.notes1 = 'input structure cam can have more fields';   % example of populating input structure cam
cam.notes2 = 'than below, such as comments like these';    % with more fields than function calls for
cam.c  = 25;   % populate input structure cam
cam.xp = .5;
cam.yp = -.5;
cam.m  = rotationMatrix(30, 40, 50);   % call function rotationMatrix with omega, phi, kappa = 30, 40, 50 deg
cam.Xc = 10;
cam.Yc = 20;
cam.Zc = 30;

fprintf(1, '%s\n', 'Input structure cam:')
disp(cam)

XYZ = [1  0  0  10;...   % create XYZ N X 4 array
       2 10 20  50;...
       3  5 30  110;...
       5 -5 -5  120];
fprintf(1, '%s\n', 'Input XYZ array:')
disp(XYZ)
   
xymm = collinearity(cam, XYZ);   % call collinearity function
fprintf(1, '%s\n', 'collinearity ouput with XYZ array input:')
disp(xymm)


% using sample file input for loading XYZ array instead of array directly
if exist('Sample Files\XYZ1.txt', 'file')    % test to see if file exists (or can be found with specified path)
    xymm2 = collinearity(cam, 'Sample Files\XYZ1.txt');  % using file to input XYZ instead of array 
    fprintf(1, '%s\n', 'collinearity ouput with XYZ array from file ''Sample Files\XYZ1.txt'':')
    disp(xymm2)
else                 % else print out error message if file not found
    fprintf(1, '%s\n', 'Sample Files\XYZ1.txt not found; folder ''Sample Files'' should be in current active MATLAB folder')
    fprintf(1, '%s\n', 'Example scripts should be run from ''Photogrammetry Toolbox'' folder\n')
end

% using sample file input for loading XYZ array instead of array directly
% and cam structure from file as well
if exist('Sample Files\XYZ1.txt', 'file') & exist('Sample Files\cam1.txt', 'file')   % test to see if files exists (or can be found with specified path)
    cam1 = loadCamStruct('Sample Files\cam1.txt');  % Photogrammetry Toolbox function to load cam structure
    xymm3 = collinearity(cam1, 'Sample Files\XYZ1.txt');  % using cam structure from line above and XYZ from file 
    fprintf(1, '%s\n', 'collinearity ouput with XYZ array from file ''Sample Files\XYZ1.txt'':')
    fprintf(1, '%s\n', 'and cam structure from file ''Sample Files\cam1.txt'':')
    disp(xymm3)      % display output image coordinates
else                 % else print out error message if one of files not found
    fprintf(1, '%s\n', 'Sample Files\XYZ1.txt not found; folder ''Sample Files'' should be in current active MATLAB folder')
    fprintf(1, '%s\n', 'or Sample Files\cam1.txt not found')
    fprintf(1, '%s\n', 'Example scripts should be run from ''Photogrammetry Toolbox'' folder\n')
end


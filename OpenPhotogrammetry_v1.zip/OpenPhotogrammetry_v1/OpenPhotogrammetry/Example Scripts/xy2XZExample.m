%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a testing program (script) for deterimining the object space coordinates (X,Z) 
% of a group of targets using the function 'xy2XZ.m' for given Y-coordinates of targets.  
%

% load the files of the camera orientation parameters and formats. load the target field
load('orientation1.dat');
load('camformat1.dat');
load('xyzobj.dat');

% generate the image coordinates of the targets
[xyimag1]=XYZ2xy(orientation1,xyzobj,camformat1);
Ytarg=xyzobj(:,2);

% calculate the (X,Z) coordinates using 'xy2XZ.m'
XZ=[];
for i=1:length(xyimag1(:,1))
[Xtarg,Ztarg]=xy2XZ(xyimag1(i,1),xyimag1(i,2),Ytarg(i),orientation1,camformat1);
XZadd=[Xtarg Ztarg];
XZ=[XZ;XZadd];
end

figure(2);
plot(xyzobj(:,1),xyzobj(:,3),'o',XZ(:,1),XZ(:,2),'+');
xlabel('X (in)');
ylabel('Z (in)');
legend('True Location','Calculated Location');


% displayGrayScaleExample
% illustrates usage of function displayGrayScale

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 2, 2006
% primary author: A. W. Burner

img = imread('Sample Files\image1.tif');    % populate array img with image form file
iptsetpref('ImshowAxesVisible', 'on')  % show pixel axes when using imshow
imshow(img);   % display image img in next figure
% next 3 lines forms a cell of strings in order to have 3 lines in title of figure
titleCell(1,1) = {'Move cursor to desired location and left click one time, then ''Enter'' to see gray scale segment on screen'};
titleCell(1,2) = {'select only 1 target location at a time to display gray scale after each ''Enter'''};
titleCell(1,3) = {'hit ''Enter'' without selecting a target area to exit loop'};
title(titleCell)   % put title on figure (above image img) using cell of strings above

loopCounter = 1               % initialize for while loop to display gray scale after each location selection and 'Enter'
while loopCounter == 1        % exit loop unless loopCounter is reset to other than 1; selection of 2 targets exits loop also (after displaying last target location selected)
    XY = pixelXYselect        % call short form to select x, y locations on image
    loopCounter = size(XY,1); % loopCounter here is set to the # rows of XY (usually 1 if only 1 target location selected)
    if loopCounter > 0        % loopCounter = 0 if 'Enter' without selecting target locations
        displayGrayScale(img, XY(end,2), XY(end,3)) % display gray scale of last target location before 'Enter' with defaults delx = dely = 8; G = 0
    end
end
fprintf(1,'display of gray scale loop terminated\n') % loop is terminated with 'Enter' only since # rows of XY, and hence loopCounter, = 0

img = imread('Sample Files\image2.tif');    % read into img array an image with higher background gray scale
imshow(img);                                % display image img on next figure
% next line adds one more line of text to the cell of strings used below in title
titleCell(1,4) = {'no background subtraction for 17 X 17 display of gray scale'};
title(titleCell)   % set title on current figure using cell of strings
loopCounter = 1    % initialize for loop
while loopCounter == 1   % next 6 lines repeat of loop above, but with new image from image2.tif
    XY = pixelXYselect
    loopCounter = size(XY,1);
    if loopCounter > 0
        displayGrayScale(img, XY(end,2), XY(end,3))  
    end
end
fprintf(1,'display of gray scale loop terminated\n')

titleCell(1,4) = {'60 background subtracted for 25 X 25 display of gray scale'};
title(titleCell)
loopCounter = 1
while loopCounter == 1    % same as other loops above
    XY = pixelXYselect
    loopCounter = size(XY,1);
    if loopCounter > 0
        % delx = dely = 12 in call to function below yields a pixel area of display = (2*delx + 1) X (2*dely + 1) = 25 X 25 
        displayGrayScale(img, XY(end,2), XY(end,3), 12, 12, 60)  % function call with half-width, half-height of diplay and gray scale to subtract before display 
    end
end
fprintf(1,'display of gray scale loop terminated\n')

iptsetpref('ImshowAxesVisible', 'off')  % return to default to not show pixel axes when using imshow



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a processing program (script) for radiometric camera calibration
% to determine the camera response function based on the Chebysev functions
% for black or color images
%
% User should set the following inputs in the program
% Inputs: (1) Two image files at different F-numbers
%         (2) F-numbers for image 1 & 2 
%         (3) Image color index (0 for b/w, 1 for color)
%         (4) RGB index if images are color (1:R, 2:G, 3:B)
%         (5) order of the Chebysev functions
%
% Outputs: 
%         (1) the coefficients of the Chebysev functions for camera response function
%             [1, x, 2x^2-1, 4x^3-3x, 8x^4-8x^2+1, 16x^5-20x^3+5x]
%         (2) camera response function, I/Imax=f(zeta), where zeta=m(I)/m(Imax)           
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% read images at two different F-numbers (inputs)
image1=imread('AdamsF4.0.jpg');
image2=imread('AdamsF5.6.jpg');

% show images
figure(1);
image(image1);
title ('Image 1');
figure(2);
image(image2);
title ('Image 2');

% set F-number (inputs)
F1=4.0; % for image 1
F2=5.6; % for image 2

% Select color image or b/w image; 0 for b/w, 1 for color (inputs)
image_color_index=1; 


if (image_color_index==1)
	RGB_index=1; % select color table in RGB, 1:R, 2:G, 3:B (inputs)
    'Find the max & min intensity values on images'

	Imax1=max(max(max(image1(:,:,RGB_index))));
	Imin1=min(min(min(image1(:,:,RGB_index))));
	Imax2=max(max(max(image2(:,:,RGB_index))));
	Imin2=min(min(min(image2(:,:,RGB_index))));

	Imax1=double(Imax1);
	Imin1=double(Imin1);
	Imax2=double(Imax2);
	Imin2=double(Imin2);

	'Generation of zeta'

	R12init=(Imax2/Imax1)*(F2/F1)^2;

	No_step=50;
	dI1=(Imax1-Imin1)/No_step;

	n=1;
	while n<(No_step-1)
   	[i,j]=find((image1(:,:,RGB_index)>Imin1+n*dI1) & (image1(:,:,RGB_index)<Imin1+(n+1)*dI1));
   	zeta1(n)=double(image1(i(1),j(1),RGB_index))/Imax1;
   	zeta2(n)=double(image2(i(1),j(1),RGB_index))/Imax2;
   	n=n+1;
   end
   
elseif (image_color_index==0)
        'Find the max & min intensity values on images'
        Imax1=max(max(image1));
		Imin1=min(min(image1));
		Imax2=max(max(image2));
		Imin2=min(min(image2));

		Imax1=double(Imax1);
		Imin1=double(Imin1);
		Imax2=double(Imax2);
		Imin2=double(Imin2);

		'Generation of zeta'

		R12init=(Imax2/Imax1)*(F2/F1)^2;

		No_step=50;
		dI1=(Imax1-Imin1)/No_step;

		n=1;
		while n<(No_step-1)
   		[i,j]=find((image1>Imin1+n*dI1) & (image1<Imin1+(n+1)*dI1));
   		zeta1(n)=double(image1)/Imax1;
   		zeta2(n)=double(image2)/Imax2;
   		n=n+1;
   	end    
end
   
'finish generation of zeta'

% give the order of the Chebysev functions (inputs)
NoTerm=6;

% the coefficients of the Chebysev functions (outputs)
[coef,res]=RadiomCali_cheby_fun(R12init,zeta1,zeta2,NoTerm);

% evaluate the camera response function
zeta=[0:0.05:1];
for i=1:length(zeta)
    x=zeta(i);
    base(1)=1;
    base(2)=x;
    base(3)=2*x^2-1;
    base(4)=4*x^3-3*x;
    base(5)=8*x^4-8*x^2+1;
    base(6)=16*x^5-20*x^3+5*x;
    
    f_cal(i)=base(1:NoTerm)*coef; % camera response function (outputs)
end

% plot the camera response function
figure(3);
plot(zeta,f_cal);
title('Camera Response Function');
xlabel('zeta=m(I)/m(Imax)');
ylabel('I/Imax');




% pixel2mmExample.m example script for function pixel2mm.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 16, 2006
% primary author: A. W. Burner

fprintf(1,'%s\n\n', 'Example using pixel2mm with input from file: Sample Files\centroids2.txt');
fprintf(1, '%s', 'centroids from input file'); 
centroids = load('Sample Files\centroids2.txt') % get sample centroids from file with point numbers imbedded in file
Sh = 0.013;    % set horizontal pixel spacing
Sv = 0.013;    % set vertical pixel spacing
x0 = 322;      % image below is 644 X 480
y0 = 240;
fprintf(1, '%s', 'pixel2mm output from centroid file with point numbers'); 
xymmPntNums=pixel2mm(centroids, Sh, Sv, x0, y0)                    % calling function with point number imbedded in input array
fprintf(1, '%s', 'pixel2mm output ignoring input point numbers');  % calling function without point numbers (by only using columns 2 and 3)
xymmNoPntNums=pixel2mm(centroids(:, [2, 3]), Sh, Sv, x0, y0)

figure(1)   % figure to show input centroid locations on an actual image
clf
hold off
iptsetpref('ImshowAxesVisible', 'on')  % show pixel axes when using imshow
imshow('Sample Files\image2.tif')     % show image 
title('Centroid locations and point numbers from file ''Sample Files\\centroids2.txt''')
xlabel('Xpixel')
ylabel('Ypixel')
delx = 15;    % width of box to be placed around centroid location on image
dely = 13;    % height of box to be placed around centroid location on image
overlayCentroidsBox('Sample Files\centroids2.txt',delx,dely);   % rough function to display boxes around centroids, expected to be part of toolbox
hold on
plot([0 100], [3 3], 'g', 'Linewidth', 2)    % next 4 lines draws green axes at approximate location of image origin
plot([100 90], [3 10], 'g', 'Linewidth', 2)
plot([3 3], [0 100], 'g', 'Linewidth', 2)
plot([3 10], [100 90], 'g', 'Linewidth', 2)
text(0,0,'(0, 0)', 'HorizontalAlignment', 'center', 'color', 'r', 'FontSize', 14)  % write (0, 0) at origin of pixel-space

figure(2)  % figure to show comverted coordinates to mm and origin in mm-space
clf
hold off
text(xymmPntNums(:, 2), xymmPntNums(:, 3), num2str(xymmPntNums(:,1)), 'HorizontalAlignment', 'center', 'color', 'r')  % write target numbers on plot
hold on
plot(xymmPntNums(:, 2), xymmPntNums(:, 3), 'o', 'markerSize', 12)   % plot circles over target numbers
plot([-4 4], [0 0], 'k')      % next 2 lines draw lines on plot that intersect at 0, 0 
plot([0 0], [-3 3], 'k')
axis equal                    % set for equal scale in x and y for comparison to figure 1 image
axis([-4 4 -3 3]);            % set axis to show almost whole image
title('Image coordinates after conversion to mm')
xlabel('x, mm')
ylabel('y, mm')
hold on
plot([0 1.5], [0 0], 'g', 'Linewidth', 2)       % next 4 lines draws green axes at origin of mm-space
plot([1.5 1.3], [0 -.2], 'g', 'Linewidth', 2)
plot([0 0], [0 1.5], 'g', 'Linewidth', 2)
plot([0 .2], [1.5 1.3], 'g', 'Linewidth', 2)
text(0,0,'(0, 0)', 'HorizontalAlignment', 'center', 'color', 'r', 'FontSize', 12)  % wite (0, 0) at origin of mm-space
hold off
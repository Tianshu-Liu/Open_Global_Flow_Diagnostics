% PM2AustralisExample.m
% illustrates use of PM2Australis.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: February 16, 2007
% primary author: A. W. Burner


omega = 110.284;  % set input angles in degrees
phi = 9.391;
kappa = 26.549;
AzimuthElevationRoll = PM2Australis(omega, phi, kappa);
fprintf(1,'%s\n', 'Examples of function PM2Australis') 
fprintf(1,'%s\n', ['  omega   phi    kappa  azim   elev     roll']);
fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', omega, phi, kappa, AzimuthElevationRoll);
fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', 90, 0, 0, PM2Australis(90, 0, 0));
fprintf(1,'%7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n', 180, 0, 0, PM2Australis(180, 0, 0));


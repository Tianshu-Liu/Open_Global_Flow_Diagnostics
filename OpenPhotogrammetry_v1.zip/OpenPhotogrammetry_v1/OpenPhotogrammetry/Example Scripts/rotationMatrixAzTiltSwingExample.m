% rotationMatrixAzTiltSwingExample.m example script for function rotationMatrixAzTiltSwing.m

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: July 16, 2006
% primary author: A. W. Burner

fprintf(1,'%s\n\n', 'rotationMatrixAzTiltSwingExample.m example script for function rotationMatrixAzTiltSwing.m')

Azimuth = 0;
Tilt = 0;
Swing = 0;
fprintf(1, 'm = rotationMatrixAzTiltSwing(%3d, %3d, %3d) assumes degrees', Azimuth, Tilt, Swing)
m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing)

Azimuth = 0;
Tilt = 0;
Swing = 0;
fprintf(1, 'm = rotationMatrixAzTiltSwing(%3d, %3d, %3d, ''radians'') assumes radians', Azimuth, Tilt, Swing)
m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing, 'radians')

Azimuth = 90;
Tilt = 90;
Swing = 90;
fprintf(1, 'm = rotationMatrixAzTiltSwing(%3d, %3d, %3d) assumes degrees', Azimuth, Tilt, Swing)
m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing)

Azimuth = pi /2;
Tilt = pi /2;
Swing = pi /2;
fprintf(1, 'm = rotationMatrixAzTiltSwing(pi/2, pi/2, pi/2, ''radians'') assumes radians', Azimuth, Tilt, Swing)
m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing, 'radians')

Azimuth = 180;
Tilt = 180;
Swing = 180;
fprintf(1, 'm = rotationMatrixAzTiltSwing(%3d, %3d, %3d) assumes degrees', Azimuth, Tilt, Swing)
m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing)

Azimuth = pi;
Tilt = pi;
Swing = pi;
fprintf(1, 'm = rotationMatrixAzTiltSwing(pi, pi, pi, ''radians'') assumes radians', Azimuth, Tilt, Swing)
m = rotationMatrixAzTiltSwing(Azimuth, Tilt, Swing, 'radians')


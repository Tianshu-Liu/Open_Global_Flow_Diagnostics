%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a script for demonstration of calculating target centroids by clicking targets.
%
% Inputs: User should input
%       (1) 'imag', image name after loading an image file (rgb or gray image) 
%       (2) 'No_targets', total number of targets to be selected (clicked)
%       (3) 'bk_size_0', bolck size for initial searching a target (such as 10 pixels)
%
% Outputs:
%       [xc,yc], two-column array of target centroids in pixels
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

NumTargs=10;
%imag=imread('Cam1.bmp');
imag=imread('Cam1gray.tif');
[xc,yc]=clicking_target_fun(imag,NumTargs,10);
fprintf(1,' xcent ycent\n');
disp([xc' yc']);

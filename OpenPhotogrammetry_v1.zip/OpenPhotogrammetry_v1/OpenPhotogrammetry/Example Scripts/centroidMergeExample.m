% centroidMergeExample
% illustrates usage of function centroidMerge

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: February 5, 2007
% primary author: A. W. Burner

% load 3 sets of centroid data creat4d within the GUI imagePrelim using image 'Sample Files\cal1.bmp'
centa = load('Sample Files\centa.txt'); % create array centa from file 'centa.txt'
centb = load('Sample Files\centb.txt'); % create array centb from file 'centb.txt'
centc = load('Sample Files\centc.txt'); % create array centc from file 'centc.txt'
scrsz = get(0,'ScreenSize');                       % get screen size in pixels
figure('Position',[10 40 scrsz(3)*.8 scrsz(4)*.8]) % set larger window for figure to distinguish overlay plots
subplot(2,2,1)                                     % divide figure window into 4 segments (2 X 2) and plot in upper left
imshow('Sample Files\cal1.bmp')
title('centa.txt')
overlayCentroidsBox(centa, centa(:,4), centa(:,5)) % overlay original array centa onto image
subplot(2,2,2)                                     % divide figure window into 4 segments (2 X 2) and plot in upper right
imshow('Sample Files\cal1.bmp')
title('centb.txt')
overlayCentroidsBox(centb, centb(:,4), centb(:,5)) % overlay original array centb onto image
subplot(2,2,3)                                     % divide figure window into 4 segments (2 X 2) and plot in lower left
imshow('Sample Files\cal1.bmp')
title('centc.txt')
overlayCentroidsBox(centc, centc(:,4), centc(:,5)) % overlay original array centc onto image 

centMerge = centroidMerge(centa, centb, 10);      % 1st merge centb with centa
centMerge2 = centroidMerge(centMerge, centc, 10); % then merge centc with results from previous line

subplot(2,2,4)                                     % divide figure window into 4 segments (2 X 2) and plot in lower right
imshow('Sample Files\cal1.bmp')
title('merge of centa, centb, centc')
overlayCentroidsBox(centMerge2, centMerge2(:,4), centMerge2(:,5)) % overlay results of merging centa, centb, centc onto image


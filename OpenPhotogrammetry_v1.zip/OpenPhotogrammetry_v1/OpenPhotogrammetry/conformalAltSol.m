function Alternate = conformalAltSol(Parameter)

% finds alternate solution of omega, phi, kappa, Tx, Ty, Tz, s
% Alternate = conformalAltSol(Parameter)
% that will transform an XYZ data set to the same values using conformal3Dinv
% for Parameter solution [Xtrans] =      s  * [m]  * [Xin] + [Txyz]
% for Alterate solution  [Xtrans] = (1 / s) * [m'] * [Xin - Txyz] 
% input structure Parameter with at least the following fields
% Parameter.omega - rotation angle in degrees, + for CCW
% Parameter.phi - rotation angle in degrees, + for CCW
% Parameter.kappa - rotation angle in degrees, + for CCW
% Parameter.Tx - X translation of transformation Tx
% Parameter.Ty - Y translation of transformation Ty
% Parameter.Tz - Z translation of transformation Ty
% Parameter.s- scale
% output structure Alternate with the following fields
% Alternate.omega - rotation angle in degrees, + for CCW
% Alternate.phi - rotation angle in degrees, + for CCW
% Alternate.kappa - rotation angle in degrees, + for CCW
% Alternate.Tx - X translation of transformation Tx
% Alternate.Ty - Y translation of transformation Ty
% Alternate.Tz - Z translation of transformation Ty
% Alternate.s- scale

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

m = rotationMatrix(Parameter.omega, Parameter.phi, Parameter.kappa); % get rotation matrix of input parameters
Alternate = TransposeAngles(Parameter);         % get transpose angles from input and put in output structure
T = [Parameter.Tx; Parameter.Ty; Parameter.Tz]; % set input translation vector for next computation
Txyz = -(1 / Parameter.s) * m' * T;             % compute new output translation vector
Alternate.Tx = Txyz(1);                         % populate output structure with new Tx
Alternate.Ty = Txyz(2);                         % populate output structure with new Ty
Alternate.Tz = Txyz(3);                         % populate output structure with new Tz
Alternate.s = 1 / Parameter.s;                  % populate output structure with new s



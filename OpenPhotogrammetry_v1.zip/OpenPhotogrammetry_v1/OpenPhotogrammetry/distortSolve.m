function camDistort = distortSolve(cam, camDistortStart, XYZ, Niterations, solve4, useLastResults)

% solves for any or all distortion coefficients K1, K2, K3, P1, P2
% camDistort = distortSolve(cam, camDistortStart, XYZ, Niterations, solve4, useLastResults)
% input argument structure cam with at least the following fields
% cam.c
% cam.xp
% cam.yp
% cam.omega
% cam.phi
% cam.kappa
% cam.Xc
% cam.Yc
% cam.Zc
% cam.xymm
% input argument structure camDistortStart with at least the following fields
% to serve as start values for distortion (and final value for xs, ys) unless
% input argument useLastResults = 1 and temp4distortSolve.mat exists
% which causes camDistortStart to be taken from file
% (except for xs and ys which always come from the input structure camDistortStart)
% camDistortStart.xs; point of symmetry for distortion x-value used for all calcs and output
% camDistortStart.ys; point of symmetry for distortion y-value used for all calcs and output
% camDistortStart.K1; 
% camDistortStart.K2;
% camDistortStart.K3;
% camDistortStart.P1;
% camDistortStart.P2;
% input argument numerical N X 4 array XYZ with format [pnt X Y Z]; 
% input argument Niterations = number of iterations
% input structure solve4 with the following fields
% field = 1 for solve, = 0 for no solve (coefficient fixed to 0) 
% solve4.K1
% solve4.K2
% solve4.K3
% solve4.P1
% solve4.P2
% typically much weaker solutions for K2, K3, P1, P2 compared to K1
% input argument useLastResults = 1 to use previous output results from
% file temp4distortSolve.mat in current folder; = 0 to ignore file
% output argument structure camDistort with the following fields
% camDistort.xs; point of symmetry for distortion x-value
% camDistort.ys; point of symmetry for distortion y-value
% camDistort.K1;
% camDistort.K2;
% camDistort.K3;
% camDistort.P1;
% camDistort.P2;
% camDistort.K1std;
% camDistort.K2std;
% camDistort.K3std;
% camDistort.P1std;
% camDistort.P2std;
% camDistort.So;
% output structure camDistort written to file temp4distortSolve.mat
% use camDistortSolution = load('temp4distortSolve') to access from MATLAB;

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: December 1, 2009
% primary author: A. W. Burner

[XYZ cam.xymm] = commonTargetNumbers(XYZ, cam.xymm); % subfunction to redefine XYZ and cam.xymm with only common target numbers
xymmDist = cam.xymm;  % set distorted coordinates to input image coordinates 

fprintf(1,'Waiting for %d iterations for distortion coefficient(s)', Niterations)
if solve4.K1; fprintf(1,' K1'); end   % print to Command Window which coefficients are solved for
if solve4.K2; fprintf(1,' K2'); end
if solve4.K2; fprintf(1,' K3'); end
if solve4.P1; fprintf(1,' P1'); end
if solve4.P2; fprintf(1,' P2'); end
fprintf(1,'\n')
if useLastResults && exist('temp4distortSolve.mat', 'file')  % test for use last results AND if file exists
    camDistort2 = load('temp4distortSolve');                 % load distortion coefficients from existing file
    camDistort2.xs =  camDistortStart.xs;                    % set point of symmetry of distortion based on input argument camDistortStart
    camDistort2.ys =  camDistortStart.ys;                    % set point of symmetry of distortion based on input argument camDistortStart
    cam.xymm = distortCorrect(xymmDist, camDistort2);        % correct for distortion based on input file
    fprintf(1,'distortion start input from file: temp4distortSolve.mat\n')
else
    cam.xymm = distortCorrect(xymmDist, camDistortStart);    % correct for distortion based on input argument camDistortStart
end   % end of use-last-results and saved file existance test
xs = camDistortStart.xs; % set point of symmetry of distortion based on input argument camDistortStart
ys = camDistortStart.ys; % set point of symmetry of distortion based on input argument camDistortStart
camDistort2.xs = xs; % set point of symmetry of distortion for intermediate distortion structure
camDistort2.ys = ys; % set point of symmetry of distortion for intermediate distortion structure

Nrows = size(cam.xymm, 1);  % seet number of rows (targets) of image data in cam.xymm

h = waitbar(0,'Solving for distortion...');  % dialog box with slider showing % completion
for iterations = 1:Niterations        % iterate for Niterations times
    waitbar(iterations / Niterations) % show % completion on waitbar
    fprintf(1,'iteration %4d of %4d of total',iterations, Niterations)  % print to Command Window
    camOut = resection(cam, XYZ);     % resection using current camera parameters and image data
    xymm = collinearity(camOut, XYZ); % create ideal image data from resection parameters just found and object coordinates
    A = [];                           % initialize A array (RHS) where L = A * Solution
    L = [];                           % initialize L array (LHS) where L = A * Solution 
    for i=1: Nrows                    % step through common target point numbers
        j = 2*i - 1;                  % index such that for i = [1 2 3...]; j = [ 1 3 5...]
        x = xymmDist(i, 2);           % distorted x-image coordinate
        y = xymmDist(i, 3);           % distorted y-image coordinate
        xu = xymm(i, 2);              % current undistorted x-image coordinate from collinearity above
        yu = xymm(i, 3);              % current undistorted y-image coordinate from collinearity above
        rsqr = (xu - xs)^2 + (yu - ys)^2; % radius squared
        L(j, 1) = x - xu;                 % distorted x - undistorted x for LHS L
        L(j + 1, 1) = y - yu;             % distorted y - undistorted y for LHS L
        k = 0;                            % set k = 0; k is index for column of A RHS matrix
        if solve4.K1; k = k + 1; A(j, k) = rsqr * (xu - xs); end          % solve for K1 if true
        if solve4.K2; k = k + 1; A(j, k) = rsqr^2 * (xu - xs); end        % solve for K2 if true
        if solve4.K3; k = k + 1; A(j, k) = rsqr^3 * (xu - xs); end        % solve for K3 if true
        if solve4.P1; k = k + 1; A(j, k) = rsqr + 2 * (xu - xs)^2; end    % solve for P1 if true
        if solve4.P2; k = k + 1; A(j, k) = 2 * (xu - xs) * (yu - ys); end % solve for P2 if true
        k = 0;       % set k = 0; k is index for column of A matrix
        if solve4.K1; k = k + 1; A(j + 1, k) = rsqr * (yu - ys); end          % solve for K1 if true
        if solve4.K2; k = k + 1; A(j + 1, k) = rsqr^2 * (yu - ys); end        % solve for K2 if true
        if solve4.K3; k = k + 1; A(j + 1, k) = rsqr^3 * (yu - ys); end        % solve for K3 if true
        if solve4.P1; k = k + 1; A(j + 1, k) = 2 * (xu - xs) * (yu - ys); end % solve for P1 if true
        if solve4.P2; k = k + 1; A(j + 1, k) = rsqr + 2 * (yu - ys)^2; end    % solve for P2 if true
    end   % end of loop through all common target point numbers setting up A and L matrices
    Solution = A\L;  % MATLAB least squares solution
    df = (size(A, 1) - length(Solution)); % compute degrees of freedom = number of equations - number of unknowns
    V = A * Solution  - L;                % compute residuals
    So = sqrt(V' * V / df);               % compute standard deviation of unit weight
    covar = inv(A' * A);                  % compute covariance matrix
    stdSolution = So * sqrt(diag(covar)); % standard deviation estimates = square root of diagonals of covariance times So
    k = 0;   % index for vector Solution terms
    if solve4.K1; k = k + 1; camDistort2.K1 = Solution(k); else camDistort2.K1 = 0; end % get solution for K1 from Solution(k) if true
    if solve4.K2; k = k + 1; camDistort2.K2 = Solution(k); else camDistort2.K2 = 0; end % get solution for K2 from Solution(k) if true
    if solve4.K3; k = k + 1; camDistort2.K3 = Solution(k); else camDistort2.K3 = 0; end % get solution for K3 from Solution(k) if true
    if solve4.P1; k = k + 1; camDistort2.P1 = Solution(k); else camDistort2.P1 = 0; end % get solution for P1 from Solution(k) if true
    if solve4.P2; k = k + 1; camDistort2.P2 = Solution(k); else camDistort2.P2 = 0; end % get solution for P2 from Solution(k) if true
    k = 0;   % index for vector stdSolution terms
    if solve4.K1; k = k + 1; camDistort2.K1std = stdSolution(k); else camDistort2.K1std = NaN; end % get standard deviation for K1 from stdSolution(k) if true
    if solve4.K2; k = k + 1; camDistort2.K2std = stdSolution(k); else camDistort2.K2std = NaN; end % get standard deviation for K2 from stdSolution(k) if true
    if solve4.K3; k = k + 1; camDistort2.K3std = stdSolution(k); else camDistort2.K3std = NaN; end % get standard deviation for K3 from stdSolution(k) if true
    if solve4.P1; k = k + 1; camDistort2.P1std = stdSolution(k); else camDistort2.P1std = NaN; end % get standard deviation for P1 from stdSolution(k) if true
    if solve4.P2; k = k + 1; camDistort2.P2std = stdSolution(k); else camDistort2.P2std = NaN; end % get standard deviation for P2 from stdSolution(k) if true
    
    cam.xymm = distortCorrect(xymmDist, camDistort2); % update undistorted image coordinates for next iteration
    if iterations < Niterations
        fprintf(1, '\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b')   % use proper number of backspaces to go back
        fprintf(1, '\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b') % to start of line for over write without scrolling down Command Window
    elseif iterations == Niterations
        fprintf(1, '\n')    % on last iteration print new line
    end
end  % end of interations loop
close(h)  % close waitbar
camDistort = camDistort2;  % set output structure to intermediate distortion structure
camDistort.So = So;        % set So field of output structure to standard deviation of unit weight
save temp4distortSolve -struct camDistort2;  % save output distortion structure to file 'temp4distortSolve.mat'
fprintf(1,'distortion output solution written to file: temp4distortSolve.mat\n')
fprintf(1,'K1/K1std: %7.2f\n', camDistort.K1 / camDistort.K1std)
fprintf(1,'K2/K2std: %7.2f\n', camDistort.K2 / camDistort.K2std)
fprintf(1,'K3/K3std: %7.2f\n', camDistort.K3 / camDistort.K3std)
fprintf(1,'P1/P1std: %7.2f\n', camDistort.P1 / camDistort.P1std)
fprintf(1,'P2/P2std: %7.2f\n', camDistort.P2 / camDistort.P2std)
return   % end of main function distortSolve

function [XYZ xymm] = commonTargetNumbers(XYZin, xymmin) % subfunction to redefine XYZin and xymmin with only common target numbers
commonNum = intersect(XYZin(:,1), xymmin(:,1));          % find target numbers common to both XYZin and xymmin arrays
XYZinindex  = []; % initialize index for XYZin array
xymminindex = []; % initialize index for xymmin structure
for i=1:length(commonNum)  % step through common set of target numbers found above
    XYZinindex  = [XYZinindex; find(XYZin(:,1)   == commonNum(i))];  % create index of XYZin containing common target numbers
    xymminindex = [xymminindex; find(xymmin(:,1) == commonNum(i))];  % create index of xymmin containing common target numbers
end    % end of loop stepping through common target numbers
XYZ  = XYZin(XYZinindex, :);   % redefine XYZin with common target numbers only
xymm = xymmin(xymminindex, :); % redefine xymmin with common target numbers only
return % end of subfunction commonTargetNumbers

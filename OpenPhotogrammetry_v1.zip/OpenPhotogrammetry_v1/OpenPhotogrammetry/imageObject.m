function varargout = imageObject(varargin)

% GUI to solve for focal length, object distance, or image distance, given any 2
% imageObject at command line
% can also plot image distance versus object distance given the focal length

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date:October 25, 2006
% primary author: A. W. Burner

% Begin initialization code - DO NOT EDIT (code straight from GUIDE)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @imageObject_OpeningFcn, ...
                   'gui_OutputFcn',  @imageObject_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before imageObject is made visible.
function imageObject_OpeningFcn(hObject, eventdata, handles, varargin)

% Choose default command line output for imageObject
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = imageObject_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;

% next code segment sets up for 'mm' and 5 decimal places on startup
set(handles.radiobutton1, 'Value', 1); % set f radiobutton for 'mm' on 
set(handles.radiobutton2, 'Value', 0); % set f radiobutton for 'inch' off 
set(handles.radiobutton3, 'Value', 1); % set f radiobutton for 'mm' on 
set(handles.radiobutton4, 'Value', 0); % set f radiobutton for 'inch' off 
set(handles.radiobutton5, 'Value', 1); % set f radiobutton for 'mm' on 
set(handles.radiobutton6, 'Value', 0); % set f radiobutton for 'inch' off 
set(handles.popupmenu1,   'Value', 3); % 3rd item in popup is '5' (5 decimal places)

function edit1_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
mmFlagf = get(handles.radiobutton1, 'Value');   % get 'mm' button on/off (0/1) status
if mmFlagf   % if 'mm' button on, turn 'inch' button off
    set(handles.radiobutton2, 'Value', 0);  
elseif ~mmFlagf  % if 'mm' button turned off, turn on 'inch' button
    set(handles.radiobutton2, 'Value', 1);
end

% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
inchFlagf = get(handles.radiobutton2, 'Value');  % get 'inch' button on/off (0/1) status
if inchFlagf       % if 'inch' button on, turn 'mm' button off
    set(handles.radiobutton1, 'Value', 0);
elseif ~inchFlagf  % if 'inch' button turned off, turn on 'mm' button
    set(handles.radiobutton1, 'Value', 1);
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
obj =  str2double(get(handles.edit2,'String'));  % get numerical value for variable 'obj'
img =  str2double(get(handles.edit3,'String'));  % get numerical value for variable 'img'
if get(handles.radiobutton4, 'Value'); obj = obj * 25.4; end  % if 'inch' button on for obj, convert obj to mm for computation of f
if get(handles.radiobutton6, 'Value'); img = img * 25.4; end  % if 'inch' button on for img, convert img to mm for computation of f
fnew = (1/obj + 1/img)^-1;  % compute focal length fnew in units of 'mm'
if get(handles.radiobutton2, 'Value'); fnew = fnew / 25.4; end  % if 'inch' button on for f, convert f to inch
contents = get(handles.popupmenu1,'String');  % get contents (cell array) of popup menu
numDecimals = contents{get(handles.popupmenu1,'Value')};  % get number of decimals from popup menu contents cell array
fmt = ['%12.' numDecimals 'f'];  % create formating string for print out to edit box
strOut = sprintf(fmt, fnew);     % create string containing focal length in specified format
if length(strOut) > 19; strOut = strOut(1: end - length(strOut) + 19); end  % limit string to 19 characters to avoid losing display
set(handles.edit1,'String', strOut);   % put string containing focal length into edit box
 
function edit2_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties (from GUIDE)
function edit2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in radiobutton3. (see radiobutton1 comments)
function radiobutton3_Callback(hObject, eventdata, handles)
mmFlagObj = get(handles.radiobutton3, 'Value');
if mmFlagObj
    set(handles.radiobutton4, 'Value', 0);
elseif ~mmFlagObj
    set(handles.radiobutton4, 'Value', 1);
end

% --- Executes on button press in radiobutton4. (see radiobutton2 comments)
function radiobutton4_Callback(hObject, eventdata, handles)
inchFlagObj = get(handles.radiobutton4, 'Value');
if inchFlagObj
    set(handles.radiobutton3, 'Value', 0);
elseif ~inchFlagObj
    set(handles.radiobutton3, 'Value', 1);
end


% --- Executes on button press in pushbutton2. (see pushbutton1 comments)
function pushbutton2_Callback(hObject, eventdata, handles)
f   =  str2double(get(handles.edit1,'String'));
img =  str2double(get(handles.edit3,'String'));
if get(handles.radiobutton2, 'Value'); f = f * 25.4; end
if get(handles.radiobutton6, 'Value'); img = img * 25.4; end
objnew = (1/f - 1/img)^-1;
if get(handles.radiobutton4, 'Value'); objnew = objnew / 25.4; end
contents = get(handles.popupmenu1,'String');
numDecimals = contents{get(handles.popupmenu1,'Value')};
fmt = ['%12.' numDecimals 'f'];
strOut = sprintf(fmt, objnew);
if length(strOut) > 19; strOut = strOut(1: end - length(strOut) + 19); end
set(handles.edit2,'String', strOut);



function edit3_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties. (from GUIDE)
function edit3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton5. (see radiobutton1 comments)
function radiobutton5_Callback(hObject, eventdata, handles)
mmFlagImg = get(handles.radiobutton5, 'Value');
if mmFlagImg
    set(handles.radiobutton6, 'Value', 0);
elseif ~mmFlagImg
    set(handles.radiobutton6, 'Value', 1);
end


% --- Executes on button press in radiobutton6. (see radiobutton2 comments)
function radiobutton6_Callback(hObject, eventdata, handles)
inchFlagImg = get(handles.radiobutton6, 'Value');
if inchFlagImg
    set(handles.radiobutton5, 'Value', 0);
elseif ~inchFlagImg
    set(handles.radiobutton5, 'Value', 1);
end


% --- Executes on button press in pushbutton3.  (see pushbutton1 comments)
function pushbutton3_Callback(hObject, eventdata, handles)
f   =  str2double(get(handles.edit1,'String'));
obj =  str2double(get(handles.edit2,'String'));
if get(handles.radiobutton2, 'Value'); f = f * 25.4; end
if get(handles.radiobutton4, 'Value'); obj = obj * 25.4; end
imgnew = (1/f - 1/obj)^-1;
if get(handles.radiobutton6, 'Value'); imgnew = imgnew / 25.4; end
contents = get(handles.popupmenu1,'String');
numDecimals = contents{get(handles.popupmenu1,'Value')};
fmt = ['%12.' numDecimals 'f'];
strOut = sprintf(fmt, imgnew);
if length(strOut) > 19; strOut = strOut(1: end - length(strOut) + 19); end
set(handles.edit3,'String', strOut);

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
f   =  str2double(get(handles.edit1,'String'));  % get numerical value of focal length
obj =  str2double(get(handles.edit2,'String'));  % get numerical value of obj
xStr = 'obj, mm';  % set string for xlabel
yStr = 'img, mm';  % set string for ylabel
fStr = ['f = ' num2str(f, '%12.3f') ' mm'];  % set string for title
fScale = 1;  % default scale for f
xScale = 1;  % default scale for x-axis (obj)
if get(handles.radiobutton2, 'Value'); fScale = 1 / 25.4; fStr = ['f = ' num2str(f, '%12.3f') ' inch']; end % if f in inches, change title string and scale for f
if get(handles.radiobutton4, 'Value'); xScale = 1 / 25.4; xStr = 'obj, inch'; end % if obj in inches, change xlabel string and scale for obj
func = @(x) (fScale/f - xScale/x)^-1; % create function handle to compute img from f and range of obj (x)
if get(handles.radiobutton6, 'Value') % if img inch button selected, then scale output plot function to inch for img
    func = @(x) ((fScale/f - xScale/x)^-1) / 25.4;
    yStr = 'img, inch';     % change ylabel string as well
end    % end of 'inch' button on test
figure % get new figure
fplot(func, [.2 * obj   2 * obj]) % plot function over the range of .2 to 2 times obj on GUI 
xlabel(xStr)  % x axis label
ylabel(yStr)  % y axis label
title(fStr)   % title at top of plot



function normG=EpipolarRelation_x(xPixA,yPixA,xPixB,yPixB,oriA,oriB,camformatA,camformatB)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% gives an epipolar relation (x) between two images (A and B) when the camera orientation parameters
% for both cameras are given.
% It computes the difference norm: normG = ||W1com*inv(W2com)*B2com-B1com|| as a function xPixA for minimization.
% The epipolar line in image A will make 'normG' minimal for a given point (xPixB,yPixB) in pixels in the image B. 
%
% Inputs:
%       (1) 'xPixA', x-coordinate in pixels in image A 
%       (2) 'yPixA', y-coordinate in pixels in image A 
%       (3) 'xPixB', x-coordinate in pixels in image B 
%       (4) 'yPixB', y-coordinate in pixels in image B 
%       (5) 'oriA', the orientation perameters for camera A, (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%       (6) 'oriB', the orientation perameters for camera B, (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%       (7) 'camformatA', the camera format for camera A, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (8) 'camformatB', the camera format for camera B, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%
%  Outputs:
%       difference norm: normG = ||W1com*inv(W2com)*B2com-B1com|| as a function xPixA for minimization.
%       This norm is zero for an epipolar line.
%
%  Note: normG is written as a function of xPixA.  This is convenient for an epipolar line that is not too vertical
%        in the (x,y) plane (in most cases).  Thus, minimization can be done along the x-axis. 

% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for Camera A
omaga=oriA(1)*pi/180;
phi=oriA(2)*pi/180;
kappa=oriA(3)*pi/180;
Xc=oriA(4);
Yc=oriA(5);
Zc=oriA(6);
c=oriA(7); %mm
xp=oriA(8); %mm
yp=oriA(9); %mm
hvratio=oriA(10);
k1=oriA(11);
k2=oriA(12);
p1=oriA(13);
p2=oriA(14);
Sv=camformatA(4);
Sh=hvratio*Sv;
xrange=camformatA(1);
yrange=camformatA(2);

m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);

m1_vector_A=[m11;m12;m13];
m2_vector_A=[m21;m22;m23];
m3_vector_A=[m31;m32;m33];

xd=Sh*(xPixA-xrange/2);
yd=Sv*(yrange/2-yPixA);
xud=xd;
yud=yd;

% estimate the undistorted image coordinates
k=0;
while k<=6
   xx=xud-xp;
   yy=yud-yp;
   r2=(xx).^2+(yy).^2;
   dxr=k1*xx.*r2+k2*xx.*(r2.*r2);
   dyr=k1*yy.*r2+k2*yy.*(r2.*r2);
   dxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
   dyd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
   xud=xd+dxr+dxd;
   yud=yd+dyr+dyd;
   k=k+1;
end

% calculate the vectors W1A, W2A and Xc_vector_A for the camera A
W1A=(xud-xp)*m3_vector_A+c*m1_vector_A;
W2A=(yud-yp)*m3_vector_A+c*m2_vector_A;
Xc_vector_A=[Xc;Yc;Zc];


% for Camera B
omaga=oriB(1)*pi/180;
phi=oriB(2)*pi/180;
kappa=oriB(3)*pi/180;
Xc=oriB(4);
Yc=oriB(5);
Zc=oriB(6);
c=oriB(7); %mm
xp=oriB(8); %mm
yp=oriB(9); %mm
hvratio=oriB(10);
k1=oriB(11);
k2=oriB(12);
p1=oriB(13);
p2=oriB(14);
Sv=camformatB(4);
Sh=hvratio*Sv;
xrange=camformatB(1);
yrange=camformatB(2);

m11=cos(phi)*cos(kappa);
m12=sin(omaga)*sin(phi)*cos(kappa)+cos(omaga)*sin(kappa);
m13=-cos(omaga)*sin(phi)*cos(kappa)+sin(omaga)*sin(kappa);
m21=-cos(phi)*sin(kappa);
m22=-sin(omaga)*sin(phi)*sin(kappa)+cos(omaga)*cos(kappa);
m23=cos(omaga)*sin(phi)*sin(kappa)+sin(omaga)*cos(kappa);
m31=sin(phi);
m32=-sin(omaga)*cos(phi);
m33=cos(omaga)*cos(phi);

m1_vector_B=[m11;m12;m13];
m2_vector_B=[m21;m22;m23];
m3_vector_B=[m31;m32;m33];

xd=Sh*(xPixB-xrange/2);
yd=Sv*(yrange/2-yPixB);
xud=xd;
yud=yd;

k=0;
while k<=6
   xx=xud-xp;
   yy=yud-yp;
   r2=(xx).^2+(yy).^2;
   dxr=k1*xx.*r2+k2*xx.*(r2.*r2);
   dyr=k1*yy.*r2+k2*yy.*(r2.*r2);
   dxd=p1*(r2+2*xx.*xx)+2*p2*xx.*yy;
   dyd=p2*(r2+2*yy.*yy)+2*p1*xx.*yy;
   xud=xd+dxr+dxd;
   yud=yd+dyr+dyd;
   k=k+1;
end

% calculate the vectors W1A, W2A and Xc_vector_A for the camera A
W1B=(xud-xp)*m3_vector_B+c*m1_vector_B;
W2B=(yud-yp)*m3_vector_B+c*m2_vector_B;
Xc_vector_B=[Xc;Yc;Zc];

% calculate the composite matrices and vectors
W1com=[W1A';W2A';W1B'];
W2com=[W1A';W2A';W2B'];

B1com=[W1A'*Xc_vector_A;W2A'*Xc_vector_A;W1B'*Xc_vector_B];
B2com=[W1A'*Xc_vector_A;W2A'*Xc_vector_A;W2B'*Xc_vector_B];

% calcuate the vector G and the norm of G
G=(W1com*inv(W2com))*B2com-B1com;
normG=(G'*G)^0.5/(B1com'*B1com)^0.5;



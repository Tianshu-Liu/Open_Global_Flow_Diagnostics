function xtrans = affine2D(xin, Thetaxy, Txy, Sxy)

% affine transformation for 2D coordinates
% xtrans = affine2D(xin, Thetaxy, Txy, Sxy)
% the affine transfomation is of the form below
% xt =  Sx * cos(thetax) * x + Sy * sin(thetay) + Tx
% yt = -Sx * sin(thetax) * x + Sy * cos(thetay) + Ty
% input xin is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% Thetaxy is a 2-element row or column vector of rotation angles of the x- and y-axis in degrees, + for CW
% Txy is a 2-element row or column vector of x, y translations Txy = [Tx; Ty];
% Sxy is a 2-element row or column vector of the x- and y-axis scale factors
% output xtrans is a N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 11, 2006
% primary author: A. W. Burner

thetax = Thetaxy(1) * pi / 180;    % get rotation angle for x-axis in radians
thetay = Thetaxy(2) * pi / 180;    % get rotation angle for y-axis in radians
mP = [cos(thetax) sin(thetay);...  % create psuedo 2 X 2 rotation matrix mP
     -sin(thetax) cos(thetay)];   
S = [Sxy(1)  0;...                 % create 2 X 2 scale matrix for calculation below
      0    Sxy(2)];
T = [Txy(1); Txy(2)];              % create column vector of translation terms (in case Txy passed as a row vector)
Nrows = size(xin,1);               % find number of rows (coordinate pairs) of input array xin
xtrans = [];                       % initialize output array xtrans 
for i=1:Nrows                      % step through rows (coordinate pairs) of input array xin
    xy = xin(i,2:3)';              % create column vector or x, y values from row vector in xin
    xtrans(i,:) = mP * S * xy + T; % create column vector of transformed x, y and store as row in xtrans
end                                % end of loop stepping through the coordinate pairs of input array xin
xtrans = [xin(:,1) xtrans];        % attach target numbers to 1st column of output array xtrans
return



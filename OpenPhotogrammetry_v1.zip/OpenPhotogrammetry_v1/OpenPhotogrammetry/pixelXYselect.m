function XY = pixelXYselect(varargin)

% manual selection of x, y location (using impixel) on current image and storage to file
% use figure; imshow('imageFileName', 'DisplayRange', []) to put image in a figure
% or img = imread('imageFileName'); figure; imshow(img, []) to get workspace variable img and display
% simple call is pixelXYselect without arguments which will start at target
% # 1 and append to file (in current directory) centTemp.txt
% pixelXYselect(101) will start numbering targets at 101
% other arguments are variable and are in pairs
% the 1st argument sets the type of argument and the matching
% paired entry sets its value; for instance 'FileName' for type of 
% argument would be followed by a string (or string variable) representing 
% the file name to be used
% Input argument pairs can be in any order, but label must match case below
% exactly; default values in () below
% 'FileName' = text entry for output file name ('centTemp.txt'}
% 'Nstart' = starting target number (1)
% 'fig' = figure # of image (gcf, current figure or active figure)
% 'FileMode' = 'a' for append; 'w' for write without append ('a')
% 'PrintOut' = 0 for no output to command window; 1 for print output (1)
% XY = output matrix with 1 row per target pair and 3 columns [TargNum X Y]
% 
% Example:
% pixelXYselect('FileName','centb.txt','Nstart',31,'fig',2,'FileMode','a');
% would open file 'centb.txt' for append, start the target numbering at 31,
% and select image locations from figure 2
%

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: March 30, 2009
% primary author: A. W. Burner

% pass argument defaults
fig = gcf;     % default is to get current figure (gcf) number
FileName = 'centTemp.txt'; % file name
Nstart = 1;                % target numbers start with 1 by default 
FileMode = 'a';            % append file mode is default
PrintOut = 0;              % print info to command window if = 1
% end of pass argument defaults

Ncols = size(varargin,2);   % find # columns of variable input argument(s)
if Ncols == 1              % if only one argument then next line to set start of numbering
    eval(['Nstart = ' num2str(varargin{1})]);   % equivilent to 'Nstart = Num' where Num is m=numerical input argument representing starting target #
elseif Ncols > 1                     % if more than 1 argument, parse in pairs
    for i=1:2:size(varargin,2)-1     % parsing of variable input argument pairs (if any)
        if ischar(varargin{i+1})     % if the 2nd entry of an argument pair is a string than use the string below
            eval([varargin{i} ' = ''',varargin{i+1},'''' ';']);   % sets each argument to its paired value, like 'FileName' and 'cent.txt'
         else
            eval([varargin{i} ' = ' num2str(varargin{i+1}) ';']); % if not a string then convert to string for eval operation
        end
    end
end

if PrintOut
    disp('left click on targets; Enter after last target')
    disp('recall pixelXYSelect with different Nstarts if numbering is not sequential to end')
    disp('')
end

% select xy pixel locations
figure(fig)    % select figure number
[Xedge Yedge G] = impixel;   % use MATLAB function impixel to record locations in pixels; Grey value G ignored
% end of xy pixel selection

% plot target numbers on selected figure
Nrows = size(Xedge, 1);     % # rows (# location selections)
hold on
for i = 1:Nrows   % step through each target #
    h = text(Xedge(i), Yedge(i), num2str(i + Nstart - 1));   % plot numbers at selected locations
    set(h,'HorizontalAlignment', 'center');                % center numbers at selected locations
    set(h,'Color',[1 0 0]);     % use red numbers
end
hold off
% end of plotting

% write [target numbers, Xpixel, Ypixel] to file
fid = fopen(FileName,[FileMode 't']);   % open file in text mode for either write ('w') or default append ('a') 
for i = 1:Nrows   % step through target numbers
    fprintf(fid,'%5d %5d %5d',i + Nstart - 1, Xedge(i), Yedge(i));  % write to file [targNum xpix ypix]
    fprintf(fid,'\n');    % linefeed
end
fclose(fid);    % close file
% end of file output

if PrintOut  % printout of file info
    if FileMode == 'a'; txt = 'appended'; end
    if FileMode == 'w'; txt = 'written (not appended)'; end
    fprintf(1,'Centroids %s to file: %s\n\n',txt, FileName)   % print file name to screen
end
% XY matrix creation
num = Nstart : Nstart + Nrows - 1;    % set target numbers sequentially from Nstart to Nstart +(Ntargs - 1)
XY = [num' Xedge Yedge];              % build up Nrows X 3 ouput array that is returned by function

centFromFile = load(FileName);    % load data from designated file (default is 'centTemp.txt')
if PrintOut  % printout of info regarding data within file
    NrowsFile = size(centFromFile,1); % get # rows (# target locations)
    if NrowsFile > Nrows              % test to see if file already had targets when location selection began
        fprintf(1,'%g xy centroid pairs total in file:%s\n', NrowsFile, FileName);  % print alerting message to screen
        fprintf(1,'%g only xy centroid pairs were just selected on current figure\n', Nrows);
        fprintf(1,'file:%s may need editing (and renaming)\n', FileName);
    elseif NrowsFile == Nrows         % test to see if only the currently selected locations are in the file
        fprintf(1,'same number of xy centroid pairs in file:%s as just selected\n', FileName);  % print if so
        fprintf(1,'edit/rename file:%s as needed\n', FileName);
    end
end
return
% end of function

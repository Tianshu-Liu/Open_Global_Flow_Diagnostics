function [coef,residual]=RadiomCali_cheby_fun(R12,zeta1,zeta2,NoTerm)    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% radiometric camera calibration based on the Chebysev functions
% to determine the camera response function from two images taken at two different F-numbers
%
% Inputs: 
%       zeta1=m(I)1/m(Imax)1, measured image intensity from image 1 normalized by its max value
%       zeta2=m(I)2/m(Imax)2, measured image intensity from image 2 normalized by its max value
%       R12, a ratio defined as (Imax2/Imax1)*(F2/F1)^2,
%            where Imax1 and Imax2 are the max intensity values in images 1 & 2,
%            and F1 and F2 are the F-numbers of cameras 1 & 2
%       NoTerm, the number of selected terms in the Chebysev functions 
%
% Outputs:
%       coef, the coefficients of a set of the Chebysev functions 
%             [1, x, 2x^2-1, 4x^3-3x, 8x^4-8x^2+1, 16x^5-20x^3+5x]
%       residual, the residual of least squares estimation
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% least squares estimation
A=[];
f=[];
for i=1:length(zeta1)
    x=zeta1(i);
    y=zeta2(i);
        
    base1(1)=1;
    base1(2)=x;
    base1(3)=2*x^2-1;
    base1(4)=4*x^3-3*x;
    base1(5)=8*x^4-8*x^2+1;
    base1(6)=16*x^5-20*x^3+5*x;
    
    base2(1)=1;
    base2(2)=y;
    base2(3)=2*y^2-1;
    base2(4)=4*y^3-3*y;
    base2(5)=8*y^4-8*y^2+1;
    base2(6)=16*y^5-20*y^3+5*y;
    
    Aadd=base1(1:NoTerm)-R12*base2(1:NoTerm); % NoTerm is the number of terms used
    fadd=0;
    A=[A;Aadd];
    f=[f;fadd];
end

A=[A;ones(1,NoTerm)];
f=[f;1];

nematrix=A'*A;

if(rcond(nematrix)>1e-22)
   coef=inv(nematrix)*(A'*f);
   else
   [U,S,V]=svd(nematrix);
   sv=diag(S);
   for i=1:length(sv)
      if sv(i)>max(max(sv))*1e-15
         rsv(i)=1/sv(i);
      else rsv(i)=0;
      end
   end
   S1=diag(rsv);
   coef=V*S1*(U'*(A'*f));
end

zCal=A*coef;
v=zCal-f;
r=length(zeta1)-NoTerm;
residual=(v'*v/r)^0.5;


function imgOut = roiPolySelect(img, rejectFlag)

% select by mouse polygon region of interest (roi) on an image; rest of image = 0
% imgOut = roiPolySelect(img) or imgOut = roiSelect(img, 'reject') 
% input argument img can be a character string or character string variable representing a
% valid image file; img can also be an image already loaded into the workspace
% optional input argument rejectFlag is a character string = 'reject' to
% obtain an output image with the polygon roi set to 0 and the rest of the image
% to remain as is; any string other than 'reject' will be ignored
% output argument imgOut is an image (same size and class as imput image)
% with polygon roi data from img superimposed on a background of 0 (or if rejectFlag
% set to 'reject' img Out will be original image with polygon roi set to 0)

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: January 16, 2007
% primary author: A. W. Burner

if ischar(img) && exist(img, 'file')  % test to see if img is a file name
    NameStr = ['file: ' img];  % create string for figure label
    img = imread(img);
elseif ischar(img) && ~exist(img, 'file')  % test to see if img is a file name
    imgOut = [];       % create empty dummy output argument roi
    fprintf(1, '%s file not found\n', img)
    fprintf(1, 'function roiPolySelect exited\n')
    return    % exit function if file does not exist
else
    NameStr = ['workspace variable: ' inputname(1)];  % create string for figure label
end
figure('NumberTitle', 'off', 'Name', NameStr);  % put label at top of figure without figure number
title('select vertices of polgon with left mouse; press Enter to exit')
hold on
BW = roipoly(img);   % invoke roipoly from image processing toolbox
if nargin == 2 && strcmp(rejectFlag, 'reject')   % test for 'reject' flag as 2nd argument
    BW = ~BW;                                    % if 'reject' flag present then complement binary image BW
end                                              % which creates a mask to eliminate poly selection rather than keeping
% size(img)
% size(BW)
if length(size(img)) > 2    % test for color image since immultiply function below requires matching deminsions
    for i= 1:3
        BWcol(:,:,i) = BW;  % pad array to 3 dimensions to match color image
    end
    BW = BWcol;             % set binary mask BW to padded 3-dimensional array BWcol
end
imgOut = immultiply(img, BW); % invoke function immultiply from image proessing toolbox to remove unwanted portion of image (set gray = 0)
figure;
imshow(imgOut)         % display output image
title('output image')  % figure title display

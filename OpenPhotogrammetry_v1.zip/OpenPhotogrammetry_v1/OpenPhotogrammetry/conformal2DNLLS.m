function Parameter = conformal2DNLLS(xin, xtrans, Start)

% non-linear least squares (NLLS) to determine conformal transformation coefficients and
% estimates of their standard deviations for 2D coordinates
% Parameter = conformal2DNLLS(xin, xtrans, Start)
% the conformal transfomation is of the form below
% xt =  s * cos(theta) * x + s * sin(theta) + Tx
% yt = -s * sin(theta) * x + s * cos(theta) + Ty
% input xin is an N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% input xtrans is an N X 3 array [pt1 x1 y1; pt2 x2 y2; ...ptN xN yN];
% Start is an input structure with the following fields
% Start.theta - start value for theta (degrees)
% Start.thetaTol - tolerance for theta within NLLS; for all tolerances [] indicates no tolerance,
% or free to vary, 0 indicates treat the parameter as a constant (do not solve for parameter), and a finite value
% sets a hard clip range of parameter +- tolerance for variation in non-linear least squares
% Start.Tx; Start.TxTol tranlation in x-direction and tolerance
% Start.Ty; Start.TyTol tranlation in y-direction and tolerance
% Start.s; Start.sTol scale and tolerance
% ouput is the structure Parameter with the following fields
% Parameter.theta - rotation angle in degrees, + for CW
% Parameter.Tx - x translation of transformation Tx
% Parameter.Ty - y translation of transformation Ty
% Parameter.s- scale
% Parameter.thetastd - estimated standard deviation from NLLS
% Parameter.Txstd - estimated standard deviation from NLLS
% Parameter.Tystd - estimated standard deviation from NLLS
% Parameter.sstd - estimated standard deviation from NLLS
% Parameter.So - scalar containing least squares standard deviation of unit weight
% note that a routine within the function converts output angles to lowest
% angles within a range of +- 180 deg, thus 190 deg found from
% NLLS would be outputted as -170 deg

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: March 16, 2011
% primary author: A. W. Burner

% next if seqment tests for all Start.parameterTol = 0 which indicates do
% not solve for any parameters; if so, exits function after setting all output
% values to input values with 0 standard deviation, also prints to Command
% Window that no parameters were solved for
if ~Start.thetaTol & ~Start.TxTol & ~Start.TyTol & ~Start.sTol % test for all Start.parameterTol = 0
    Parameter.theta = Start.theta;        % set output values to input values (and 0 standard deviation)
    Parameter.Tx = Start.Tx;        % set output values to input values (and 0 standard deviation)
    Parameter.Ty = Start.Ty;        % set output values to input values (and 0 standard deviation)
    Parameter.s = Start.s;        % set output values to input values (and 0 standard deviation)
    [Parameter.thetastd Parameter.Txstd Parameter.Tystd Parameter.sstd Parameter.So] = deal(0);  % set all std's to 0
    fprintf(1,'No parameters solved for since all Start.parameterTol = 0\n') % print to Command Window
    return                          % exit function
end                                 % end of if segment

commonNum = intersect(xin(:,1), xtrans(:,1));  % find target numbers common to both xin and xtrans
xinIndex = [];     % initialize index for xin array
xtransIndex  = []; % initialize index for xtrans array
for i=1:length(commonNum)  % step through common set of target numbers found above
    xinIndex    = [xinIndex;     find(xin(:,1)    == commonNum(i))];  % create index of xin containing common target numbers
    xtransIndex = [xtransIndex;  find(xtrans(:,1) == commonNum(i))];  % create index of xtrans containing common target numbers
end
xin    = xin(xinIndex, :);       % redefine xin with common target numbers only
xtrans = xtrans(xtransIndex, :); % redefine xtrans(:,1) with common target numbers only

Start.theta = Start.theta * pi / 180;       % convert from degrees to radians
Start.thetaTol = Start.thetaTol * pi / 180; % convert from degrees to radians
theta = Start.theta; % put start value in local variable theta
Tx = Start.Tx;       % put start value in local variable Tx
Ty = Start.Ty;       % put start value in local variable Ty
s = Start.s;         % put start value in local variable s
[solve4theta solve4Tx solve4Ty solve4s] = deal(1); % solve for 4 parameters (= 1)unless Start.parameterTol = 0
if Start.sTol          % test for tolerance > 0 and not []
    sTol = Start.sTol; % put tolerance in local variable
elseif ~Start.sTol     % test for tolerance = 0 
    solve4s = 0;       % do not solve for s
end                    % end of s tolerance if segment
if Start.thetaTol      % test for tolerance > 0 and not []
    thetaTol = Start.thetaTol; % put tolerance in local variable
elseif ~Start.thetaTol         % test for tolerance = 0 
    solve4theta = 0;           % do not solve for theta
end                            % end of theta tolerance if segment
if Start.TxTol           % test for tolerance > 0 and not []
    TxTol = Start.TxTol; % put tolerance in local variable
elseif ~Start.TxTol      % test for tolerance = 0 
    solve4Tx = 0;        % do not solve for Tx
end                      % end of Tx tolerance if segment
if Start.TyTol           % test for tolerance > 0 and not []
    TyTol = Start.TyTol; % put tolerance in local variable
elseif ~Start.TyTol      % test for tolerance = 0 
    solve4Ty = 0;        % do not solve for Ty
end                      % end of Ty tolerance if segment

Nrows = size(xin, 1);  % find number of rows (number of target point numbers) of the redefined xin (and xtrans)
for iterations=1:20    % iterate NLLS 20 times
    A = [];   % initialize the array A that represents the right hand side of the conformal transformation
    L = [];   % initialize the column vector L which represents the left hand side of the conformal transformation
    for i = 1: Nrows      % step through each coordinate pair of the redefined xin (and xtrans)
        x = xin(i,2);     % create x as a scalar containing the x-value of a coordinate pair from xin
        y = xin(i,3);     % create y as a scalar containing the y-value of a coordinate pair from xin
        xt = xtrans(i,2); % create xt as a scalar containing the x-value of a coordinate pair from xtrans
        yt = xtrans(i,3); % create yt as a scalar containing the y-value of a coordinate pair from xtrans
        j = 2*i - 1;      % j is intermediate index 1:2:2 * Nrows - 1 since there will 2 equations for each coordinate pair (each i)
                          % for (i = 1) (j = 1, 2); (i = 2) (j = 3, 4); (i = 3) (j = 5, 6)...
        L(j)   = xt - s * x * cos(theta) - s * y * sin(theta) - Tx;      % populate L matrix (left hand side of trans) for x-equation
        L(j+1) = yt + s * x * sin(theta) - s * y * cos(theta) - Ty;      % populate L matrix (left hand side of trans) for y-equation
        k = 0;   % set k = 0; k is index for column of A matrix
        if solve4theta; k = k + 1; A(j,k) = -s * x * sin(theta) + s * y * cos(theta); end % populate A matrix (right hand side of trans), deltheta term
        if solve4Tx; k = k + 1; A(j,k) = 1; end % j index is for the x-equation of the transformation, delTx term
        if solve4Ty; k = k + 1; A(j,k) = 0; end % delTy term (0 since not in xt-equation)
        if solve4s; k = k + 1; A(j,k) = x * cos(theta) + y * sin(theta); end % dels term
        k = 0;   % set k = 0; k is index for column of A matrix
        if solve4theta; k = k + 1; A(j+1,k) = -s * x * cos(theta) - s * y * sin(theta); end % deltheta term for y-equation (j+1 index)
        if solve4Tx; k = k + 1; A(j+1,k) = 0; end % delTx term (0 since not in yt-equation)
        if solve4Ty; k = k + 1; A(j+1,k) = 1; end % delTy term
        if solve4s; k = k + 1; A(j+1,k) = -x * sin(theta) + y * cos(theta); end % dels term
    end                   % end of loop stepping through coordinate pairs
    L = L';               % make L a column vector for matrix math next line
    X = A\L;              % MATLAB least squares solution; X is column vector of solutions for deltheta, delTx, delTy, dels
    k = 0;                % k is used for indices in the NLLS solution vector X
    if solve4theta; k = k + 1; theta = theta + X(k); end % add deltheta (usually X(1)) to get updated value for theta before continuing iterations
    if solve4Tx; k = k + 1; Tx = Tx + X(k); end          % add delTx (usually X(2)) to get updated value for Tx before continuing iterations
    if solve4Ty; k = k + 1; Ty = Ty + X(k); end          % add delTy (usually X(3)) to get updated value for Ty before continuing iterations
    if solve4s; k = k + 1; s = s + X(k); end             % add dels (usually X(4)) to get updated value for s before continuing iterations

    if Start.sTol    % test for tolerance > 0
        if s > Start.s + sTol; s = Start.s + sTol;         % hard clip parameter to +- tolerance
        elseif s < Start.s - sTol; s = Start.s - sTol; end % hard clip parameter to +- tolerance
    end              % end of tolerance if segment for s
    if Start.thetaTol % test for tolerance > 0
        if theta > Start.theta + thetaTol; theta = Start.theta + thetaTol;         % hard clip parameter to +- tolerance
        elseif theta < Start.theta - thetaTol; theta = Start.theta - thetaTol; end % hard clip parameter to +- tolerance
    end              % end of tolerance if segment fro theta
    if Start.TxTol % test for tolerance > 0
        if Tx > Start.Tx + TxTol; Tx = Start.Tx + TxTol;          % hard clip parameter to +- tolerance
        elseif Tx < Start.Tx - TxTol; Tx = Start.Tx - TxTol; end  % hard clip parameter to +- tolerance
    end              % end of tolerance if segment for Tx
    if Start.TyTol % test for tolerance > 0
        if Ty > Start.Ty + TyTol; Ty = Start.Ty + TyTol;          % hard clip parameter to +- tolerance
        elseif Ty < Start.Ty - TyTol; Ty = Start.Ty - TyTol; end  % hard clip parameter to +- tolerance
    end               % end of tolerance if segment for Ty
end        % end of NLLS iterations loop
df = (size(A, 1) - length(X)); % compute degrees of freedom = number of equations - number of unknowns
V = A * X  - L;                % compute residuals
So = sqrt(V' * V / df);        % compute standard deviation of unit weight
covar = inv(A' * A);           % compute covariance matrix
stdX = So * sqrt(diag(covar)); % standard deviation estimates = square root of diagonals of covariance times So
k = 0;   % k is index for stdX containing standard deviations [correlated with X indices, if X(3) is associated with Ty then stdX(3) is the standard deviation of Ty]
thetastd = 0; Txstd = 0; Tystd = 0; sstd = 0;      % set all std's to 0 for cases where a parameter is not solved for
if solve4theta; k = k + 1; thetastd = stdX(k); end % put standard deviation in common name variable
if solve4Tx; k = k + 1; Txstd = stdX(k); end       % put standard deviation in common name variable
if solve4Ty; k = k + 1; Tystd = stdX(k); end       % put standard deviation in common name variable
if solve4s; k = k + 1; sstd = stdX(k); end         % put standard deviation in common name variable

if solve4theta   % only use this routine if solving for theta
    if abs(theta) > pi                 % routine to get theta in lowest form (pi >= theta >= -pi)
        ratio = theta / (2 * pi);      % get # of 2pi's in angle
        fraction = ratio - fix(ratio); % isolate fractional portion
        if abs(fraction) > .5          % test for greater than pi
            theta = fraction * 2 * pi -sign(fraction) * 2 * pi; % for example set -181 -> +179 if > 180
        else
            theta = fraction * 2 * pi;  % reset theta to lowest form if less or = pi (180)
        end
    end                                 
end                                    % end of theta lowest form routine

Parameter.theta = theta * 180 / pi;       % populate ouput structure Parameter     
Parameter.thetastd = thetastd * 180 / pi;
Parameter.Tx = Tx;
Parameter.Txstd = Txstd;
Parameter.Ty = Ty;
Parameter.Tystd = Tystd;
Parameter.s = s;
Parameter.sstd = sstd;
Parameter.So = So;
return                               % end of function

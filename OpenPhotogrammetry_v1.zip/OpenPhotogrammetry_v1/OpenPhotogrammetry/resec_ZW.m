function [exterior]=resec_ZW(xyimag,xyzobj,camformat,c)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% closed-form space resection function developed by Zeng and Wang (1992)
% for estimate of the camera exterior orientation parameters (omega,phi,kappa,Xc,Yc,Zc)
% based on three known targets when c is given and (xp,yp,Sh/Sv,K1,K2,P1,P2) are set at zero.
%
% Inputs:
%       (1) 'xyzobj', the object space coordinates of three known targets in inches, which is a three-colunm file (X,Y,Z). 
%                     Numbering of the three targets follows the counter-clockwise fashion.
%       (2) 'xyimag', the corresponding image centroids in pixels, which is a two-colunm file (x,y).
%                     Numbering of the three targets follows the counter-clockwise fashion.
%       (3) 'camformat', the camera format, a one-colunm file
%           [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%           such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       (4) 'c', the principal distance (approximately focal length) in mm 
%
%  Outputs:
%       'exterior', sets of the camera exterior orientation parameters in two columns,
%                   where one column is a set of the parameters.
%                   For example, typical values of the orientation parameters:
%                   Omega: -56 deg.
%                   Phi: -9 deg.
%                   Kappa: -80 deg.
%                   Xc: -2 in
%                   Yc: 56 in
%                   Zc: 36 in
%
%  Remarks:
%        This closed-form resection function typically gives two sets (two solutions) of the exterior orientation parameters.
%        To determine the correct set, additional information is needed. For example, when an additional known target is given,
%        we have two groups of three known targets.  Then, we run 'resec_ZW.m' for the two groups and obtain four sets of 
%        the exterior orientation parameters. If one set of the exterior orientation parameters is repeated in two runs, it is 
%        the correct one that should remain invariant for different groups of targets.  
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% three known targets in the object space
X1=xyzobj(1,1);
Y1=xyzobj(1,2);
Z1=xyzobj(1,3);

X2=xyzobj(2,1);
Y2=xyzobj(2,2);
Z2=xyzobj(2,3);

X3=xyzobj(3,1);
Y3=xyzobj(3,2);
Z3=xyzobj(3,3);


% camera format
x_range=camformat(1);
y_range=camformat(2);
Sv=camformat(4);
Sh=camformat(3);

% convert pixels to mm in the image coordinates
xim=(xyimag(:,1)-x_range/2)*Sh;
yim=-(xyimag(:,2)-y_range/2)*Sv;


% calculate L1, L2 and L3
L3=((X1-X2)^2+(Y1-Y2)^2+(Z1-Z2)^2)^0.5;
L1=((X2-X3)^2+(Y2-Y3)^2+(Z2-Z3)^2)^0.5;
L2=((X3-X1)^2+(Y3-Y1)^2+(Z3-Z1)^2)^0.5;

% position vectors on the image plane [Note: Zeng and Wang's coordinate system is (m1,m2,-m3)] 
r1=[xim(1);yim(1);c];
r2=[xim(2);yim(2);c];
r3=[xim(3);yim(3);c];

% calculate Aij
A11=r1'*r1/c^2;
A12=r1'*r2/c^2;
A13=r1'*r3/c^2;
A21=r2'*r1/c^2;
A22=r2'*r2/c^2;
A23=r2'*r3/c^2;
A31=r3'*r1/c^2;
A32=r3'*r2/c^2;
A33=r3'*r3/c^2;

% calculate the coefficient in the algebraic equations for R1, R2 and R3 
D12=2*A12/(A11*A22)^0.5;
D23=2*A23/(A22*A33)^0.5;
D31=2*A31/(A33*A11)^0.5;

% re-name D12, D23, D31
D1=D12;
E1=D23;
F1=D31;

% calculate the coefficients for the fourth-order algebraic equation
K12=(L1/L2)^2;
K32=(L3/L2)^2;

N1=(1-K12)^2+K32^2-2*(1-K12)*K32-K32*E1^2+4*K32*(1-K12);
N2=K32*F1*(-2-2*K32+4*K12+E1^2)+K12*(E1*D1+2*F1-2*K12*F1)+E1*D1*(K32-1);
N3=K32*(K32*F1^2-F1*D1*E1-4*K12+2*K32-E1^2-2*K12*F1^2)+K12*(K12*F1^2+2*K12-F1*E1*D1-D1^2)+D1^2-2+E1^2;
N4=K32*(2*F1-2*K32*F1+E1*D1+4*K12*F1)+K12*(E1*D1-2*K12*F1+F1*D1^2-2*F1)-D1*E1;
N5=K32*(K32-2-2*K12)+K12*(K12-D1^2+2)+1;

M2=N2/N1;
M3=N3/N1;
M4=N4/N1;
M5=N5/N1;

% solve the 4th-order equation for n
C=[1;M2;M3;M4;M5];
n=roots(C);

% calculate R1, R3 and possible value for R2 (multiple solutions)
k=1;
i=1;
R_group=[];
while k<=length(n)
    if isreal(n(k))==1
        p=L2/(n(k)^2-F1*n(k)+1)^0.5;
        R1(i)=p;
        R3(i)=n(k)*p;
        R2A1(i)=(D1*R1(i)+(D1^2*R1(i)^2-4*(R1(i)^2-L3^2))^0.5)/2;
        R2A2(i)=(D1*R1(i)-(D1^2*R1(i)^2-4*(R1(i)^2-L3^2))^0.5)/2;
        R2B1(i)=(E1*R3(i)+(E1^2*R3(i)^2-4*(R3(i)^2-L1^2))^0.5)/2;
        R2B2(i)=(E1*R3(i)-(E1^2*R3(i)^2-4*(R3(i)^2-L1^2))^0.5)/2;
        
        R_group_add=[R1(i);R3(i);R2A1(i);R2A2(i);R2B1(i);R2B2(i)]; 
        R_group=[R_group R_group_add];
        i=i+1;
    end
    k=k+1;
end


% find R2 that satifies both the two algebraic equations
for k=1:length(R_group(1,:))
    for i=3:length(R_group(:,k))
        for j=3:length(R_group(:,k))
            if (i~=j)&(abs(R_group(i,k)-R_group(j,k))<0.001)
                R2(k)=R_group(i,k);
            end
        end
    end
end

% constitute the possible groups of (R1, R2, R3)
R_group_new=[];
for i=1:length(R_group(1,:))
    R2_added=[R_group(1,i);R2(i);R_group(2,i)];
    R_group_new=[R_group_new R2_added];
end


% calculate the possible groups of (Xc, Yc, Zc), typically four groups
XYZc=[];
for i=1:length(R_group_new(1,:))
    R1=R_group_new(1,i);
    R2=R_group_new(2,i);
    R3=R_group_new(3,i);

    g1=(R1^2-R2^2+(X2^2+Y2^2+Z2^2)-(X1^2+Y1^2+Z1^2))/2;
    g2=(R2^2-R3^2+(X3^2+Y3^2+Z3^2)-(X2^2+Y2^2+Z2^2))/2;

    dX21=X2-X1;
    dY21=Y2-Y1;
    dX32=X3-X2;
    dY32=Y3-Y2;
    dZ21=Z2-Z1;
    dZ32=Z3-Z2;

    delta=dX21*dY32-dX32*dY21;
    hx1=(g1*dY32-g2*dY21)/delta;
    hx2=(dZ21*dY32-dZ32*dY21)/delta;
    hy1=(g2*dX21-g1*dX32)/delta;    
    hy2=(dZ32*dX21-dZ21*dX32)/delta;

    A(1)=hx2^2+hy2^2+1;
    A(2)=2*X1*hx2+2*Y1*hy2-2*Z1-2*hx1*hx2-2*hy1*hy2;
    A(3)=-R1^2+(X1^2+Y1^2+Z1^2)-2*X1*hx1-2*Y1*hy1+hx1^2+hy1^2;

    Zc=roots(A);

    for i=1:2
        c1=g1-dZ21*Zc(i);
        c2=g2-dZ32*Zc(i);
        deltax=c1*dY32-c2*dY21;
        deltay=c2*dX21-c1*dX32;
        Xc(i)=deltax/delta;
        Yc(i)=deltay/delta;
    end

    XYZc_add=[[Xc(1);Yc(1);Zc(1)] [Xc(2);Yc(2);Zc(2)]]; 
    XYZc=[XYZc XYZc_add];
end

% Since numbering of the three targets follows the counter-clockwise fashion,
% the number T should positive. Thus, we eliminate two groups
XYZc_new=[];
for i=1:length(XYZc(1,:))
    Xc=XYZc(1,i);
    Yc=XYZc(2,i);
    Zc=XYZc(3,i);
    B=[[Xc-X1 Yc-Y1 Zc-Z1];[X2-X1 Y2-Y1 Z2-Z1];[X3-X1 Y3-Y1 Z3-Z1]];
    T(i)=det(B);
    if T(i)>0
        XYZc_new=[XYZc_new XYZc(:,i)];
    end
end

% calculate the possible Euler rotational angles (omega,phi,kappa) for given groups of (Xc, Yc, Zc)
% Two sets of the exterior orientation parameters are obtained here. 
exterior=[];
for n=1:length(XYZc_new(1,:))
    Xc=XYZc_new(1,n);
    Yc=XYZc_new(2,n);
    Zc=XYZc_new(3,n);

    R1=((X1-Xc)^2+(Y1-Yc)^2+(Z1-Zc)^2)^0.5;
    R2=((X2-Xc)^2+(Y2-Yc)^2+(Z2-Zc)^2)^0.5;
    R3=((X3-Xc)^2+(Y3-Yc)^2+(Z3-Zc)^2)^0.5;

    C=[[X1-Xc Y1-Yc Z1-Zc]; [X2-Xc Y2-Yc Z2-Zc]; [X3-Xc Y3-Yc Z3-Zc]];
    D3=-[R1/A11^0.5; R2/A22^0.5; R3/A33^0.5];
    m3=inv(C)*D3;

    D2=[(yim(1)/c)*R1/A11^0.5; (yim(2)/c)*R2/A22^0.5; (yim(3)/c)*R3/A33^0.5];
    m2=inv(C)*D2;

    D1=[(xim(1)/c)*R1/A11^0.5; (xim(2)/c)*R2/A22^0.5; (xim(3)/c)*R3/A33^0.5];
    m1=inv(C)*D1;

    m31=m3(1);
    m32=m3(2);
    m33=m3(3);
    m21=m2(1);
    m22=m2(2);
    m23=m2(3);
    m11=m1(1);
    m12=m1(2);
    m13=m1(3);
    
    % recovered rotational matrix
    M=[[m11 m12 m13]; [m21 m22 m23]; [m31 m32 m33]];
    
    % calculate the Euler rotational angles
    phi=asin(m31);
    omega=atan2(-m32,m33);
    kappa=asin(-m21/cos(phi));
    
    % combine the exterior orientation parameters
    exterior_add=[[omega;phi;kappa]*180/pi;[Xc;Yc;Zc;]];
    exterior=[exterior exterior_add];
end





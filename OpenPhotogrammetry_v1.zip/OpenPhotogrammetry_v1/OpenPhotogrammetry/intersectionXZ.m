function [XYZ] = intersectionXZ(cam)

% multi-camera photogrammetric spatial intersection to determine 3D [X Z]
% with Y input
% [XYZ] = intersection(cam)
% coordinates given camera parameters and image coordinates from 2 or more
% cameras (or views); missing or extra target point numbers for any camera
% are accomodated; no practical limit on number of cameras (or views)
% input argument is a structure array cam(N) where N is the number of
% cameras; the fields of the input strucrure array cam are
% cam(N).c
% cam(N).xp
% cam(N).yp
% cam(N).m  3 X 3 roation matrix (from rotationMatrix function)
% cam(N).Xc
% cam(N).Yc
% cam(N).Zc
% cam(N).xymm
% cam(N).xymm is an M X 4 numeric array containing [pntNum x y Y] for each
% image coordinate for each camera (or view) where M is the number of image
% coordinates for a particular camera.  M and the actual point numbers used
% can vary from camera to camera.  Results are returned for any point
% number that is seen by at least 2 cameras
% XYZ is the output numeric P X 8 array where P is the number of points
% that are seen by at least 2 cameras.  The first column is the point
% number, columns 2 to 4 are X Y Z order (with Y echoed from input), columns 5 to 7 are the values of
% the standard deviation found in the linear least squares reduction in Xstd
% 0 Zstd order (O for Y since not solved for).  Column eight records the number of cameras that were
% used in the solution for that point.

% Developed at NASA Langley Research Center
% Version date: December 09, 2010
% primary author: A. W. Burner

Ncams = size(cam,2);  % columns of cam indicates number of cameras
camxy = [];           % initialize camxy used for xymm image coordinates below
for i = 1:Ncams       % step through each camera structure for xymm data
    Nrows = size(cam(i).xymm,1);                    % number of rows of xymm (image coordinates) for each camera
    camxy = [camxy; cam(i).xymm i * ones(Nrows,1)]; % create 5 column appended array with [pnt x y Y camNum]
end
% camxy
camxySorted = sortrows(camxy, 1); % make array sorted using the 1st column in ascending order
Nimg = size(camxySorted,1);       % total number of image coordinates (sum of all cameras)

i = 1;      % index for stepping through all the coordinates in camxySorted
indOut = 1; % index for output array XYZ
while i <= Nimg % execute this loop until i > Nimg
    k = find(camxySorted(:,1) == camxySorted(i,1)); % index for all points that equal the current point
    if length(k) > 1  % if 2 or more coordinates found with the same point number, do this calculation
        A = [];       % initialize the right hand side matrix A
        B = [];       % initialize the left hand side matrix B       
        for j = 1: length(k) % step through the set of common point numbers
            ind = k(j);      % index for camxySorted for each common point number
            camNum = camxySorted(ind,5); % get camera number for this point
            xmm = camxySorted(ind,2);    % get xmm data for this point
            ymm = camxySorted(ind,3);    % get ymm data for this point
            Y   = camxySorted(ind,4);    % get Y input value for this point from 4th column
            x  = xmm - cam(camNum).xp;   % x for calculations below
            y  = ymm - cam(camNum).yp;   % y for calculations below
            c  = cam(camNum).c;          % get camera constant for this point
            m  = cam(camNum).m;          % get rotation matrix m for this point
            Xc = cam(camNum).Xc;         % get Xc for this point
            Yc = cam(camNum).Yc;         % get Yc for this point
            Zc = cam(camNum).Zc;         % get Zc for this point
            a1 = x * m(3,1) + c * m(1,1); % compute a coefficients for this point
            a2 = x * m(3,2) + c * m(1,2); % compute a coefficients for this point
            a3 = x * m(3,3) + c * m(1,3); % compute a coefficients for this point
            a4 = y * m(3,1) + c * m(2,1); % compute a coefficients for this point
            a5 = y * m(3,2) + c * m(2,2); % compute a coefficients for this point
            a6 = y * m(3,3) + c * m(2,3); % compute a coefficients for this point
            A = [A; a1 a3;...          % create A matrix by appending each point of the matching set
                    a4 a6];
            B  = [B; a1 * Xc + a2 *Yc + a3 * Zc - a2 * Y;... % create B matrix by appending each point of the matching set
                     a4 * Xc + a5 *Yc + a6 * Zc - a5 * Y];
        end
        % Elements of Photogrammetry 2nd ed. Wolf p 571...
        xz = A\B;                     % MATLAB linear least squares solution for X, Z with Y as input
        pnt = camxySorted(i,1);       % point number to be put in column 1 of ouput array XYZ
        XYZ(indOut, 1) = pnt;         % point number put in column 1 of ouput array XYZ
        XYZ(indOut, 2) = xz(1);       % X put in column 2 of ouput array XYZ
        XYZ(indOut, 3) = Y;           % Y put in column 3 of ouput array XYZ (from input, not computed)
        XYZ(indOut, 4) = xz(2);       % Z put in column 4 of ouput array XYZ
        df = size(A,1) - size(xz,1);  % degrees of freedom df is r in Wolf (number or equations - number of unknowns)
        V = A * xz - B;               % compute residuals V (B is L in Wolf)
        So = sqrt((V' * V) / df);     % compute standard deviation of unit weight So
        covariance = inv(A' * A);     % compute convariance matrix
        sx = So * sqrt(diag(covariance)); % compute standard deviations of X, Y, Z
        XYZ(indOut, 5) = sx(1);     % Xstd put in column 5 of ouput array XYZ
        XYZ(indOut, 6) = 0;         % 0 put in column 6 of ouput array XYZ since Y not computed
        XYZ(indOut, 7) = sx(2);     % Zstd put in column 7 of ouput array XYZ
        XYZ(indOut, 8) = length(k); % put number of cameras used in solution in column 8 of XYZ
        indOut = indOut + 1;        % increment indOut in preparation for next solution set
        i = i + length(k);          % increase i to skip over matching point numbers just found
    else                            % if no point number match then
        i = i + 1;                  % go to next image coordinate
    end                             % end of X Z solution loop
end                                 % end of main while loop  
return                              % end of function




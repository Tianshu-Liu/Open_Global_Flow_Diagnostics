function [dxp,exterior]=resecA(interior,exterior,format,xyimagd,xyimagu,xyzobj)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% resection for exterior orientation given interior orientation
% The Newton-Raphson method is used here. This is the same as 
% 'resec.m', but it also outputs the exterior orientation parameters besides dxp.
%
% Inputs: (1) exterior, the initially estimated exterior orientation parameters, (omega,phi,kappa,Xc,Yc,Zc)
%         (2) interior, the interior orientation parameters, (c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%         (3) format, the camera format file,
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%         (4) xyimagd, distorted image coordinates, in pixels
%         (5) xyimagu, undistorted image coordinates, in pixels
%         (6) xyzobj, the object space coordinates, in inches
%
% Outputs: (1) dxp=std(xp), the standard deviation of the calculated xp over all the targets in the image plane
%          (2) exterior, the outputed exterior orientation parameters
% Note: this program is used as a subroutine in 'camcal_fun.m'
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or aburner@cox.net to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Newton-Raphson iteration
h=0.001*ones(6,1);
eps=0.000002;
[dx,xxp]=lleast(exterior,interior,format,xyimagd,xyimagu,xyzobj);
var=norm(dx);
kk=1;
if var>=eps
  while norm(var)>eps
       [dx0,xxp]=lleast(exterior,interior,format,xyimagd,xyimagu,xyzobj);
       [dx2,xxp]=lleast(exterior+h,interior,format,xyimagd,xyimagu,xyzobj);
       [dx1,xxp]=lleast(exterior-h,interior,format,xyimagd,xyimagu,xyzobj);
       itera=(2*dx0.*h)./(dx2-dx1);
       exterior=exterior-itera;
      [dx,xxp]=lleast(exterior,interior,format,xyimagd,xyimagu,xyzobj);
      var=norm(dx);
      kk=kk+1;
      if kk>300
        break;
     end
  end
end

dxp=std(xxp);





function fid = saveCamStruct(fileName, camStructure)

% utility to save structure cam
% saveCamStruct(fileName, camStructure)
% fileName of file to save cam structure (string 'fileName' or variable fileName)
% camStructure is structure containing c, xp, yp, m, Xc, Yc, Zc
% rest of structure ignored

% Developed by Western Michigan University for NASA Langley Research Center
% Email tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: September 15, 2006
% primary author: A. W. Burner

fid = fopen(fileName, 'wt');   % open file for write in text mode
if fid > -1
    fprintf(fid,'c  = %8.5f\n',camStructure.c);   % write fields to file
    fprintf(fid,'xp = %8.5f\n',camStructure.xp);
    fprintf(fid,'yp = %8.5f\n',camStructure.yp);
    fprintf(fid,'m  = %20.16f\n',camStructure.m); % order m11, m21, m31, m21, m22, m23, m31, m32, m33
    fprintf(fid,'Xc = %15.5f\n',camStructure.Xc);
    fprintf(fid,'Yc = %15.5f\n',camStructure.Yc);
    fprintf(fid,'Zc = %15.5f\n',camStructure.Zc);
    fclose(fid);
else
    fprintf(1,'%s not found, function saveCamStruct exited\n', fileName)
end
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a utility program (script) for deterimination of the camera orientation 
% parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1), where the DLT and optimization algorithm are used.
%
% Inputs:(1) xyzobj.dat, the object space coordinates of a number of known targets in inches, which is a three-colunm file. 
%        (2) xyimag.dat, the corresponding image centroids in pixels, which is a two-colunm file.
%        (3) 'camformat', the camera format, a one-colunm file
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       
% Outputs: Camera orientation parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1), 
%           where K2, P1 and P2 are set at zero
%   For example, typical values of the orientation parameters:
%   Omega: -56 deg.
%   Phi: -9 deg.
%   Kappa: -80 deg.
%   Xc: -2 in
%   Yc: 56 in
%   Zc: 36 in
%   c: 28 mm
%   xp: 0.2 mm
%   yp: 0.08 mm
%   Sh/Sv: 0.923
%   K1 (mm^-2): 0.0005
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;


% load the object space and image coordinate files and camera format file 
xyzobj=load('xyzobj.dat');
%xyimag=load('xyimag.dat');
camformat=load('camformat.dat');

 orien(1)= -56;  % deg.
 orien(2)= -9; % deg.
 orien(3)= -80; % deg.
 orien(4)= -2; % in
 orien(5)= 56; % in
 orien(6)= 36; % in
 orien(7)= 28; % mm
 orien(8)= 0.2; % mm
 orien(9)= 0.08; % mm
 orien(10)= 0.9231;
 orien(11)= 0.0005;
 orien(12)=0;
 orien(13)=0;
 orien(14)=0;

 orien=orien';
 
 
 [xyimag]=XYZ2xy(orien,xyzobj,camformat);
 
 
 
 
% give the initial approximation of the orientation parameters using the DLT
[approrien]=dlt(camformat,xyimag,xyzobj);

exter=approrien(1:6);
inter=approrien(7:11);
inter(6)=0.00;
inter(7)=0.00;
inter(8)=0.00;

approrien=[exter;inter];


corr_no=1; % select the number of iterations for lens distortion correction 
% optimization and distortion corrections
[orien_cal]=camcal_fun(camformat,approrien,xyimag,xyzobj,corr_no);




% save orientation.dat orien -ascii;
% save xyimag.dat xyimag -ascii;


     
     
     



clear all
close all

%% select targets for tracking

NumTargs=10;
imag=imread('g1.tif');
[xc_ini,yc_ini]=clicking_target_fun(imag,NumTargs,10);


%% track tarhets and calculate centroids

skip=1;
minframe=1;    %Tunnel start occurs at (around) this frame number
maxframe=100;    %Tunnel un-start occurs at (around) this frame number

for i=minframe:skip:maxframe
    imagefile1=strcat('g',num2str(i),'.tif');  
    I =imread(imagefile1);

    for j=1:NoTargs
        row_p=round(yc_ini(j));
        col_p=round(xc_ini(j));

        [xc1_shifted,yc1_shifted]=locating_target1_fun(I,row_p,col_p,bk_size_0);

        xc(i,j)=xc1_shifted;
        yc(i,j)=yc1_shifted;
    end
    
    xc_ini=xc(i,:);
    yc_ini=yc(i,:);
    

    % superimpose the calculated centroids on targets    
    figure(100);
    imshow(I);
    hold on;
    plot(round(xc(i,:)),round(yc(i,:)),'+r');
    hold off;
    
    i
end
    

    
 file_name_xc=strcat('xc',num2str(k),'.dat');
 file_name_yc=strcat('yc',num2str(k),'.dat');
    
%dlmwrite(file_name_xc,xc);
%dlmwrite(file_name_yc,yc);

    




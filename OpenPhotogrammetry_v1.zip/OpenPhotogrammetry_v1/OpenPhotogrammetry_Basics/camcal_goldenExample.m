%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a utility program (script) for deterimination of the camera orientation 
% parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1),
% where the DLT and the golden section optimization 'exe' programs are called.
% The 'exe' programs 'simulator.exe' and 'calibrator.exe' are from the C-codes.
% This program gives more accurate calculation than 'camcal_user.m' that
% calls a Matlab optimization function.
%
% Inputs:(1) xyzobj.dat, the object space coordinates of a number of known targets in inches, which is a three-colunm file. 
%        (2) xyimag.dat, the corresponding image centroids in pixels, which is a two-colunm file.
%        (3) 'camformat', the camera format, a one-colunm file
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%        Note: 'simulator.exe' is a DLT program that inputs 'xyzobj.dat', 'xyimag.dat'
%             and 'cam_format.dat'.  
%              'calibrator.exe' is a golden section optimization program
%              that inputs 'Interior_input.dat' defining ranges of the
%              interior orientation parameters for searching
%              besides 'xyzobj.dat', 'xyimag.dat', and 'cam_format.dat'.  
%
% Outputs: Camera orientation parameters: (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2)
%          The obtained camera orientation parameters are saved to a file 
%          'orientation.dat' in the local directory. 
%
%   For example, typical values of the orientation parameters:
%   Omega: -56 deg.
%   Phi: -9 deg.
%   Kappa: -80 deg.
%   Xc: -2 in
%   Yc: 56 in
%   Zc: 36 in
%   c: 28 mm
%   xp: 0.2 mm
%   yp: 0.08 mm
%   Sh/Sv: 0.923
%   K1 (mm^-2): 0.0005
%   K2 (mm^-4): 0.00004
%   P1 (mm^-1): 0.0001
%   P2 (mm^-1): 0.00002
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load the object space and image coordinate files and camera format file 
xyzobj=load('xyzobj.dat');
xyimag=load('xyimag.dat');
camformat=load('cam_format.dat')

save xyzobj.dat xyzobj -ascii;
save xyimag.dat xyimag -ascii;
save cam_format.dat camformat -ascii;

% give the initial approximation of the orientation parameters using the DLT
!simulator.exe &

% input the ranges for the interior orientation and lens distortion parameters
interior_range=[26 29;              % range for c
                0.1 0.22;           % range for xp
                0.0 0.1;            % range for yp
                0.9 1.0;            % range for Sh/Sv
                0.000  0.0006;      % range for K1
                0.000 0.0005;       % range for K2
                -0.000 0.0005;      % range for P1
                -0.000 0.0005];     % range for P2
save Interior_input.dat interior_range -ascii;

% Call 'calibrator.exe' for optimization based on Golden Section Method
% Need input the number for iterations, for example: 40
% Need input the lens distortion correction index
% For example:
% 0: Zeroth-order correction
% 1: First-order correction
% 2: Second-order correction

!calibrator.exe &























     
     
     
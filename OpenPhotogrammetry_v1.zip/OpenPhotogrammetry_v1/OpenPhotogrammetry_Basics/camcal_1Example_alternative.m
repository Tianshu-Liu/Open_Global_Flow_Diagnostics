%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a utility program (script) for deterimination of the camera orientation 
% parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2), where the DLT and optimization function
% 'camcal_fun_1.m' are used.
%
% Inputs:(1) xyzobj.dat, the object space coordinates of a number of known targets in inches, which is a three-colunm file. 
%        (2) xyimag.dat, the corresponding image centroids in pixels, which is a two-colunm file.
%        (3) 'camformat', the camera format, a one-colunm file
%             [No. of horizontal pixels,No. of vertical pixels,horizontal pixel spacing,vertical pixel spacing]
%             such as [640;480;0.012;0.013] in (pixels,pixels,mm/pixel,mm/pixel)
%       
% Outputs: Camera orientation parameters (omega,phi,kappa,Xc,Yc,Zc,c,xp,yp,Sh/Sv,K1,K2,P1,P2), 
%           
%   For example, typical values of the orientation parameters:
%   Omega: -56 deg.
%   Phi: -9 deg.
%   Kappa: -80 deg.
%   Xc: -2 in
%   Yc: 56 in
%   Zc: 36 in
%   c: 28 mm
%   xp: 0.2 mm
%   yp: 0.08 mm
%   Sh/Sv: 0.923
%   K1 (mm^-2): 0.0005
%
% Developed by Western Michigan University for NASA Langley Research Center
% Email: tianshu.liu@wmich.edu or awburner@widomaker.com to report bugs or suggest improvements
% Version date: August 28, 2006
% Primary author: Tianshu Liu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;
close all;


% load the object space and image coordinate files and camera format file 
xyzobj=load('xyzobj.dat');
xyimag=load('xyimag.dat');
camformat=load('cam_format.dat');



save xyzobj.dat xyzobj -ascii;
save xyimag.dat xyimag -ascii;
save cam_format.dat camformat -ascii;

% give the initial approximation of the orientation parameters using the DLT
!simulator.exe &

exter=load('exterior_input.dat');
interior_range=load('Interior_input.dat');

inter(1)=(interior_range(1,1)+interior_range(1,2))/2;
inter(2)=0.00;
inter(3)=0.00;
inter(4)=camformat(3)/camformat(4);
inter(5)=0.00;
inter(6)=0.00;
inter(7)=0.00;
inter(8)=0.00;

inter=inter';

approrien=[exter;inter];



% give the initial approximation of the orientation parameters using the DLT
% [approrien]=dlt(camformat,xyimag,xyzobj);

% plot initial results
xyplot(camformat,approrien,xyimag,xyzobj,1);


% initial estimation
ex_orien_0=approrien(1:6); % for right tip camerain the aircraft coordinate system
in_orien1_0=[approrien(7);0;0;camformat(3)/camformat(4);0];
in_orien2_0=[0;0;0];

% optimization for the camera orientation parameters
[orien]=camcal_fun_1(xyimag,xyzobj,camformat,ex_orien_0,in_orien1_0,in_orien2_0);

% plot the results
xyplot(camformat,orien,xyimag,xyzobj,2);

% save orientation.dat orien -ascii;

     
     
     
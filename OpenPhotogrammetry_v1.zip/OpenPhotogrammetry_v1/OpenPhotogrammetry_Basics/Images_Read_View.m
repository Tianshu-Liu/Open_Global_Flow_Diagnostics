
%Code to read appropriate frames from the multi-tif files from PCO-camera, 
%apply 2-D filter, find Temperature, and trace temperature in time for a given point 

clear all
close all

imagefile=strcat('L1B_dryout00920.tif');
Im1 =imread(imagefile);
Im1=double(Im1);


figure(100);
    %imagesc(Im2);
imshow(uint8(Im1));
colormap('gray')
colorbar
axis image;


% imshow(uint8(Im1));
% % select a region for optical flow calculation
% xy=ginput(2);
% x1=floor(min(xy(:,1)));
% x2=floor(max(xy(:,1)));
% y1=floor(min(xy(:,2)));
% y2=floor(max(xy(:,2)));



skip=1;
minframe=1;    %Tunnel start occurs at (around) this frame number
maxframe=900;    %Tunnel un-start occurs at (around) this frame number


% Flow-on case with heating
k=1;
for i=minframe:skip:maxframe
    if i<10
        imagefile=strcat('L1B_dryout0000',num2str(i),'.tif');
    elseif (i>=10) && (i<100)
        imagefile=strcat('L1B_dryout000',num2str(i),'.tif');
    elseif (i>=100) && (i<1000)
        imagefile=strcat('L1B_dryout00',num2str(i),'.tif');
    else
        imagefile=strcat('L1B_dryout0',num2str(i),'.tif');   
    end
            
    
    X =imread(imagefile);
    % Im2=X(y1:y2,x1:x2); 
    Im2=X;
    
    g=double(Im2);
    
    g=200*(g/max(max(g)));
    
    figure(200);
    %imagesc(Im2);
    imshow(uint8(g));
    colormap('gray')
    colorbar
    axis image;
    
    
    file_name=strcat('g',num2str(i),'.dat');
    %dlmwrite(file_name,g);
    
    
    k=k+1;
    i
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Velocity and Pressure calculation from experimental data 
%  (like hawkmoth flight data)
%  
% 02/06/2023
% by Zemin Cai
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clc;
clear all;
addpath(GetAbsolutePath('CoreFuncs'));
addpath(GetAbsolutePath('..\Data'));      
addpath(GetAbsolutePath('..\Results'));

%%
Start_idx = 700;
End_idx = 701;
Subimg_width = 65;
Subimg_height = 86;
ux_structure = [];
uy_structure = [];
p_structure = [];

for idx = Start_idx:(End_idx-1)
    sprintf('Now, processing the %dth image', idx);
    FileName_Frame1 = ['MothBody_' sprintf('%03d', idx) '.jpg'];
    FileName_Frame2 = ['MothBody_' sprintf('%03d', idx+1) '.jpg'];
    Im1 = imread(FileName_Frame1);
    Im2 = imread(FileName_Frame2);
    
    imshow(uint8(Im1));
    xy=ginput(1);
    x1=floor(min(xy(:,1)));
    y1=floor(min(xy(:,2)));
    x2 = x1 + Subimg_width - 1;
    y2 = y1 + Subimg_height -1;
    I1=double(Im1(y1:y2,x1:x2));
    I2=double(Im2(y1:y2,x1:x2));
    
    I1_original=I1;
    I2_original=I2;
    
    Im1=double(I1);
    Im2=double(I2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Velocity field calculation
    sprintf('\tCalculating velocity field...')
    lambda_1=20; 
    lambda_2=2000; % Lagrange multiplier
    
    [ux0,uy0,vor,ux_horn,uy_horn,error1]=OpticalFlowPhysics_fun(Im1,Im2,lambda_1,lambda_2);
    Im1=uint8(Im1);
    Im2=uint8(Im2);
    ux_corr=ux0;
    uy_corr=uy0;
    No_iteration=1; 
    k=1;
    while k<=No_iteration
        [Im1_shift,uxI,uyI]=shift_image_fun_refine(ux_corr,uy_corr,Im1,Im2,5);
      
        mask_size=2;
        std=1;
        H1=fspecial('gaussian',mask_size,std);
        I1=imfilter(Im1_shift,H1);
        I2=imfilter(Im2,H1);
        I1=double(I1);
        I2=double(I2);
        
        N=30; % size for averaging
        h=ones(N,N)/(N*N);
        I12F=filter2(h,I1)-filter2(h,I2);
        I2=I2+I12F;

        [dux,duy,vor,dux_horn,duy_horn,error2]=OpticalFlowPhysics_fun(I1,I2,lambda_1,lambda_2);
        ux_corr=uxI+dux;
        uy_corr=uyI+duy;
        k=k+1;
    end
    
    ux=ux_corr;
    uy=uy_corr;
    ux_structure = cat(3, ux_structure, ux);
    uy_structure = cat(3, uy_structure, uy);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Pressure calculation
    sprintf('\tCalculating pressure field...')
    StandardAtmos_p = 1.01e5;
    [height, width] = size(ux);
    factor_x = width/6;
    factor_y = height/6;
    a = 1;
    P = zeros(height, width);
    P(:, 1) = StandardAtmos_p;
    P(1, :) = StandardAtmos_p;
    P(height, :) = StandardAtmos_p;
    P(:, width) = StandardAtmos_p;
    
    N = 1;
    C_rot=1;
    u_x_small = imresize(ux, N);
    u_y_small = imresize(uy, N);
    [height_small, width_small] = size(u_x_small);
    factor_x_small = width_small/6;
    factor_y_small = height_small/6;               % pixels/unit-length
    
    mx_small = 0.25.*ones(height_small, width_small);
    my_small = sqrt(15)/4.*ones(height_small, width_small);
    alpha = 128;
    A = mx_small.^2 + alpha;
    B = mx_small.*my_small;
    C = my_small.^2 + alpha;
    h = 1;
    [phi_x_small, phi_y_small] = phi_vec_finite_diff_Hiemenz(u_x_small,u_y_small,a,C_rot,factor_x_small,factor_y_small);
    phi_m_small = mx_small.*phi_x_small + my_small.*phi_y_small;
    degree = 90;
    gamma=degree*pi/180;
    theta=atan(0.5*tan(gamma));
    a=(sin(theta))^(1/2);
    P_D = zeros(height_small, width_small);
    P_D(:, 1) = StandardAtmos_p;
    P_D(1, :) = StandardAtmos_p;
    P_D(height_small, :) = StandardAtmos_p;
    P_D(:, width_small) = StandardAtmos_p;
    
    disp(sprintf('Now, creating the coeffcient matrix'));
    E = CoeffMatrix(height_small, width_small, A, B, C, h);
    size(E)
    
    disp(sprintf('Now, creating the right hand side vector'));
    T = RHS_Vec(P_D, mx_small, my_small, alpha, phi_m_small, h);
    
    disp(sprintf('Now, solving the linear equations system'));
    tic
    sol = linsolve(E, T);
    toc
    
    % merging
    for j = 1:1:(height_small-2)
        for i = 1:1:(width_small-2)
            P_D(j+1, i+1)= sol((i-1)*(height_small-2)+j);
        end
    end
    p_D = P_D - a^(-2)*0.5.*(u_x_small.^2 + u_y_small.^2);
    P_D_full = imresize(P_D, [height, width]);
    p_D_full = imresize(p_D, [height, width]);
    p_structure = cat(3, p_structure, p_D_full);
    
    % save results
    filename = sprintf('MothBody_Velocity_Pressure_%d_%d.mat', idx, idx+1);
    path = ['../Results/' filename];
    save(path, 'p_structure', 'ux_structure', 'uy_structure');
end
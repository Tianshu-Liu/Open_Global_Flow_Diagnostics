
%% This Matlab program extracts a skin friction from a surface scalar field obtained in sublimation and
%% dye visualizations by using the optical flow method 
%% when the mass flux flux field is given for modeling the source term. 
%% This program gives a relative or normalized skin friction field, showing the skin friction 
%% topology.  

clear all;
close all;

%% Load scalar visualization and mass files or Images
%% case 1: sublimation visualization image in shock-BL interaction 
% I_off=imread('shock_BL_interaction_masked.tif');
% I_off=double(I_off(:,:,1));
% I_off=max(max(I_off))*ones(size(I_off));
% I_on =imread('shock_BL_interaction_masked.tif');
% I_on=double(I_on(:,:,1));
% IR=I_on./I_off;
% I1=IR;
% I1=I1(44:209,57:261);
% epsilon=1*ones(size(I1));
% f1=-I1+epsilon;

%% case 2: dye visualization on delta wing in water flow
I_off=imread('delta_avg_AOA20.jpg');
I_off=double(I_off(:,:,1));
I_off=max(max(I_off))*ones(size(I_off));
I_on =imread('delta_avg_AOA20.jpg');
I_on=double(I_on(:,:,1));
IR=I_on./I_off;
I1=IR;
epsilon=1*ones(size(I1));
f1=I1-epsilon;


%% pre-processing of images 
%% scale factor for downsampling
scale_im=1;
%% Gaussian filter size
size_filter=2;
%% generate downsampled and fileterd images
[I2,f2] = pre_processing_a(I1,f1,scale_im,size_filter);
Is=I2;
f=f2;

%% set relevant parameters
%% scaling factor
factor=1;
%% Lagrange multiplier for solving the optical flow equation
lambda=1*10^(-2); % 

%% modleing the source term 
f=factor*f; 

%% optical flow computation for extracting the skin friction components tor_x and tor_y
[Ix,Iy]=gradient(Is);
[tor_x,tor_y]=Optical_Flow_generic(Ix,Iy,f,lambda);

tor_mag=(tor_x.^2+tor_y.^2).^0.5;

%% plots
Plots_1


% dlmwrite('tor_x_50C_impinging_jet.dat',tor_x);
% dlmwrite('tor_y_50C_imoinging_jet.dat',tor_y);











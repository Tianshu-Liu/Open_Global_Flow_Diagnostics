
%% This Matlab program extracts a skin friction from a surface temperature field
%% by using the optical flow method when the heat flux flux field is given for modeling the source term. 
%% This program gives a relative or normalized skin friction field, showing the skin friction 
%% topology.  

clear all;
close all;

%% Load surface temperature and heat flux files or Images
I1=load('dT_50C_impinging_jet.dat');
q1=load('q_50C_impinging_jet.dat');

% I1=load('T_cylinder_300K.dat');
% q1=load('q_cylinder_300K.dat');


%% pre-processing of images 
%% scale factor for downsampling
scale_im=1;
%% Gaussian filter size
size_filter=10;
%% generate downsampled and fileterd images
[I2,q2] = pre_processing_a(I1,q1,scale_im,size_filter);
Is=I2;
q=q2;

%% set relevant parameters
%% scaling factor
factor=1;
%% Lagrange multiplier for solving the optical flow equation
 lambda=5*10^(-3); % impinging jet
% lambda=20;  % heated cylinder
%% modleing the source term 
f=factor*q; 

%% optical flow computation for extracting the skin friction components tor_x and tor_y
[Ix,Iy]=gradient(Is);
[tor_x,tor_y]=Optical_Flow_generic(Ix,Iy,f,lambda);

tor_mag=(tor_x.^2+tor_y.^2).^0.5;

%% plots
Plots_1


% dlmwrite('tor_x_50C_impinging_jet.dat',tor_x);
% dlmwrite('tor_y_50C_imoinging_jet.dat',tor_y);










